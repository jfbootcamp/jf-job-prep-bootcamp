package com.security.hometalk.config;

import com.security.hometalk.user.CustomUserDetails;
import com.security.hometalk.user.User;
import com.security.hometalk.user.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.security.autoconfigure.web.servlet.PathRequest;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.web.SecurityFilterChain;

@Configuration  // Spring 설정 클래스로 등록함
@EnableWebSecurity  // Spring Security의 웹 보안 기능을 활성화하고, SecurityFilterChain 설정을 적용함
@RequiredArgsConstructor
public class SpringSecurityConfig {
    private final UserService userService;

    @Bean  // HttpSecurity는 보안 규칙을 설정하는 빌더
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
                .httpBasic(AbstractHttpConfigurer::disable) // HTTP Basic 인증 비활성화, 대신 직접 만든 /login 페이지 사용
                .csrf(Customizer.withDefaults()) // 사용자 몰래 다른 사이트에서 요청을 위조해 보내는 공격 보호는 유지 --> CSRF 필터를 추가/설정
                .rememberMe(Customizer.withDefaults()) // 로그인 폼의 remember-me 체크박스가 사용할 기본 자동 로그인 기능 켬
                .authorizeHttpRequests(authorize -> authorize
                        .requestMatchers(PathRequest.toStaticResources().atCommonLocations()).permitAll()
                        .requestMatchers("/", "/home", "/signup", "/login").permitAll()
                        .anyRequest().authenticated()  // 위에 명시하지 않은 나머지 요청은 모두 로그인한 사용자만 접근가능
                )
                /* Spring Security가 기본으로 제공하는 로그인 화면 대신
                *  우리가 직접 만든 로그인 페이지와 처리 방식을 등록함.
                *  Spring Security 내부 필터가 직접 처리함 */
                .formLogin(formLogin ->
                    // GET /login -> login.html을 보여줄 커스텀 로그인 페이지 경로 지정
                    formLogin.loginPage("/login")
                            .defaultSuccessUrl("/", true)
                            .permitAll()
                )
                .logout(logout -> logout
                        .logoutUrl("/logout")
                        .logoutSuccessUrl("/")
                );
        return http.build();  // SecurityFilterChain 객체가 생성됨
    }

    @Bean // username을 받아 UserDetails를 반환.
    public UserDetailsService userDetailsService() {

        return username -> {
          User user = userService.findByUsername(username);
          if (user == null) {
              throw new UsernameNotFoundException(username);
          }
          // DB에서 조회한 User를 CustomUserDetails로 감싸 Spring Security 로그인 검증을 넘김
          return new CustomUserDetails(user);
        };
    }


}
