package com.security.hometalk.config;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.security.web.csrf.CsrfToken;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
/*
*   쿠키 : 브라우저가 서버에 요청할 때 자동으로 함께 보내는 저장공간
*   브라우저-서버 간 요청 위조 방지를 위해 그 쿠키에 CSRF 토큰을 담아두고,
*   매 요청마다 토큰이 쿠키에 빠지지 않도록 꺼내 담아주는 역할
*
* */
public class CsrfCookieFilter extends OncePerRequestFilter { // 하나의 HTTP 요청당 딱 한 번만
    @Override                                                // doFilterInternal() 이 실행됨을 보장함
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws ServletException, IOException {

        CsrfToken csrfToken = (CsrfToken) request.getAttribute(CsrfToken.class.getName());
        if (csrfToken != null) {
            csrfToken.getToken();       // 토큰 값 접근으로 쿠키 랜더링
        }
        filterChain.doFilter(request,response);  // 다음 필터로 요청 전달
    }
}
