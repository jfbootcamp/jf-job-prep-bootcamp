package com.security.hometalk.note;

import com.security.hometalk.user.CustomUserDetails;
import com.security.hometalk.user.User;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;

@Controller
@RequiredArgsConstructor
@RequestMapping("/note")
public class NoteController {
    private final NoteService noteService;

    @GetMapping
    public String getNote(Authentication authentication, Model model) {
        User user = currentUser(authentication);
        List<NoteResponse> notes = noteService.findByUser(user);
        model.addAttribute("notes", notes);
        return "note/index";
    }

    private User currentUser(Authentication authentication) {
        // 인증 객체의 principal은 CustomUserDetails이므로 내부의 도메인 User를 꺼내 사용함
        return ((CustomUserDetails)authentication.getPrincipal()).getUser();
    }


}
