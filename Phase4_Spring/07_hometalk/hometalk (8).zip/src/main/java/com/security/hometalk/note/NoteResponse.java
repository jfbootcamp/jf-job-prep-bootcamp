package com.security.hometalk.note;

import lombok.Getter;

import java.time.LocalDateTime;

@Getter
public class NoteResponse {
    private final Long id;
    private final String title;
    private final String content;
    private final String username;
    private final LocalDateTime createdAt;

    public NoteResponse(Long id, String title, String content, String username, LocalDateTime createdAt) {
        this.id = id;
        this.title = title;
        this.content = content;
        this.username = username;
        this.createdAt = createdAt;
    }

    public static NoteResponse from(Note note) {
        String username = note.getUser() != null ? note.getUser().getUsername() : null;
        return new NoteResponse(note.getId(), note.getTitle(),
                                note.getContent(), username, note.getCreatedAt());
    }
}
