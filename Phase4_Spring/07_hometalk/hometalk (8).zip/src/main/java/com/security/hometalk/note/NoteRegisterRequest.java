package com.security.hometalk.note;

import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class NoteRegisterRequest {
    @NotBlank
    private String title;
    @NotBlank
    private String content;
}
