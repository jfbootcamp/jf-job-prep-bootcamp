package com.security.hometalk.config;

import com.security.hometalk.user.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.web.SecurityFilterChain;

@Configuration  // Spring 설정 클래스로 등록함
@EnableWebSecurity  // Spring Security의 웹 보안 기능을 활성화하고, SecurityFilterChain 설정을 적용함
@RequiredArgsConstructor
public class SpringSecurityConfig {
    private final UserService userService;

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http.httpBasic(AbstractHttpConfigurer::disable);
        return http.build();
    }
    
}
