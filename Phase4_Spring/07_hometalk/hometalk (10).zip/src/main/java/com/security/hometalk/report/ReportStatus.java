package com.security.hometalk.report;

public enum ReportStatus {

    PRIVATE("비공개", "badge-private"),
    PENDING("승인 요청", "badge-pending"),
    APPROVED("승인", "bdage-approved"),
    REJECTED("반려", "bdage-rejected");

    private final String displayname;
    private final String badgeClass; // 상태별 배지 CSS 클래스명

    ReportStatus(String displayname, String badgeClass) {
        this.displayname = displayname;
        this.badgeClass = badgeClass;
    }

    public String getDisplayname() {
        return displayname;
    }

    public String getBadgeClass() {
        return badgeClass;
    }
}
