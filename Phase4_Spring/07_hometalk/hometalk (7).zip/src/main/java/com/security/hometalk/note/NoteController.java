package com.security.hometalk.note;

public class NoteController {
}
