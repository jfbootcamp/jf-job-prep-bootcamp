package com.security.hometalk.note;

import com.security.hometalk.user.User;
import com.security.hometalk.user.UserNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
@RequiredArgsConstructor
public class NoteService {
    private final NoteRepository noteRepository;

    /*노트조회
    *   - 유저는 본인의 노트만 조회할 수 있음
    *   - 어드민은 모든 노트를 조회할 수 있음
    * */
    public List<Note> findByUser(User user){
        if (user == null){
            // 노트 목록은 로그인한 사용자를 기준으로 조회함
            throw new UserNotFoundException();
        }
        if (user.isAdmin()){
            return noteRepository.findAllByOrderByIdDesc(); // 관리자는 전체 노트를 작성자 정보까지 함께 조회
        }
        return noteRepository.findByUserOrderByIdDesc(user);
    }
}
