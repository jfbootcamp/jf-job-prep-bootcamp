package com.security.hometalk.note;

import com.security.hometalk.user.User;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface NoteRepository extends JpaRepository<Note, Long> {
    /* Note.user는 Lazy 로딩이므로, 트랜잭션 종료 후 화면에서 접근하면
      LazyInitializationException 이 발생할 수 있음 => Note 엔티티의 user 필드를
      함께 조회해 추가 조회가 필요 없게 함  */
    @EntityGraph(attributePaths = "user")
    List<Note> findAllByOrderByIdDesc();

    List<Note> findByUserOrderByIdDesc(User user);
}
