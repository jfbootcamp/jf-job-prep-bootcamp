package com.security.hometalk.user;

import lombok.RequiredArgsConstructor;
import org.jspecify.annotations.Nullable;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import java.util.Collection;
import java.util.List;

@RequiredArgsConstructor
public class CustomUserDetails implements UserDetails {

    private final User user;  // 로그인 후 컨트롤러에서 실제 도메인 User가 필요할 때
                              // 다시 꺼내 쓰기 위해 보관함

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return List.of(new SimpleGrantedAuthority(user.getAuthority()));
    }           // user.getAuthority() : "ROLE_USER" 같은 문자열을 반환
                // SimpleGrantedAuthority : 이 문자열을 Spring Security 권한 객체로 바꿈.

    @Override
    public @Nullable String getPassword() {
        // 로그인 검증시 Spring Security가 비교할 암호화된 비밀번호를 User 엔티티에서 꺼내 반환함
        return user.getPassword();
    }

    @Override
    public String getUsername() {
        // 로그인 검증 시 Spring Security가 식별자로 사용할 username을 User 엔티티에서 꺼내 반환함
        return user.getUsername();
    }
}
