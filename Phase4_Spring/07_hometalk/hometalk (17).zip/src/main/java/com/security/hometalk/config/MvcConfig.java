package com.security.hometalk.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.ViewControllerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration  // Spring MVC 화면 연결 규칙을 추가하기 위한 설정 클래스
public class MvcConfig implements WebMvcConfigurer {

    @Override
    public void addViewControllers(ViewControllerRegistry registry) {
        // /home 요청은 홈 화면 템플릿인 templates/index.html로 랜더링함
        registry.addViewController("/home").setViewName("index");
        // 루트(/) 요청도 같은 홈 화면으로 연결함
        registry.addViewController("/").setViewName("index");
        registry.addViewController("/login").setViewName("login");
    }
}
