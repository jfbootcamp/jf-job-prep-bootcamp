package com.security.hometalk.user;

import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class UserService {
    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    /* 일반 사용자 등록 */
    public User signup(String username, String password) {
        if (userRepository.findByUsername(username) != null) {
            throw new AlreadyRegisteredUserException();
        }
        return userRepository.save(
                new User(username, passwordEncoder.encode(password), "ROLE_USER"));
    }

    /*관리자 권한을 가지는 사용자(관리자) 등록 */
    public User signupAdmin(String username, String password) {
       if (userRepository.findByUsername(username) != null) {
           throw new AlreadyRegisteredUserException();
       }
       return userRepository.save(
                new User(username, passwordEncoder.encode(password), "ROLE_ADMIN"));
    }

    public User findByUsername(String username) {
        return userRepository.findByUsername(username);
    }
}
