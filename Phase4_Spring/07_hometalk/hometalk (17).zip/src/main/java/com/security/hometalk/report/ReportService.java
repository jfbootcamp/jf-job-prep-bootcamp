package com.security.hometalk.report;

import com.security.hometalk.user.User;
import com.security.hometalk.user.UserNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
@RequiredArgsConstructor
public class ReportService {
    private final ReportRepository reportRepository;

    /* 사용자 본인의 업무보고 목록 조회
    * */
    @Transactional(readOnly = true)
    public List<ReportResponse> findByUser(User user){
        if (user == null){
            // 업무보고 목록은 로그인한 사용자를 기준으로 조회함
            throw new UserNotFoundException();
        }
        return reportRepository.findByUserOrderByIdDesc(user)     // 본인 업무보고만 조회
                .stream()
                .map(ReportResponse::from)   //  report Entity -> ReportResponse 변환
                .toList();
    }

    /*관리자용 : 승인 요청(PENDING) 상태의 보고서 목록 조회
    * 관리자는 사용자가 명시적으로 제출한 보고서만 열람할 수 있음 */
    @Transactional(readOnly = true)
    public List<ReportResponse> findPendingReports(){
        return reportRepository.findByStatusOrderByIdDesc(ReportStatus.PENDING)
                .stream()
                .map(ReportResponse::from).toList();
    }

    /*업무 보고 저장 (초기 상태 : PRIVATE)*/
    public Report saveReport(User user, String title, String content) {
        if (user == null){
            throw new UserNotFoundException();
        }
        return reportRepository.save(new Report(title, content, user));
    }

    /*업무 보고 삭제
    * return true:  삭제 성공, false: (본인 소유가 아니거나 존재하지 않음)*/
    public boolean deleteReport(User user, Long reportId){
        if (user == null){
            throw new UserNotFoundException();
        }
        Report report = reportRepository.findByIdAndUser(reportId, user);
        if (report == null){
            return false;
        }
        reportRepository.delete(report);
        return true;
    }

    /*승인 요청 : PRIVATE -> PENDING*/
    public void submitReport(User user, Long reportId) {
        if (user == null){
            throw new UserNotFoundException();
        }
        Report report = reportRepository.findByIdAndUser(reportId, user);
        if (report != null){
            report.submit();
        }
    }

    /*관리자 승인 : PENDING -> APPROVED*/
    public void approveReport(Long reportId) {
        reportRepository.findById(reportId).ifPresent(Report::approve);
    }
    /*관리자 반려 : PENDING -> REJECTED*/
    public void rejectReport(Long reportId) {
        reportRepository.findById(reportId).ifPresent(Report::reject);
    }
}
