package com.security.hometalk.announcement;

import jakarta.validation.constraints.NotBlank;

public class AnnouncementRegisterRequest {
    @NotBlank
    private String content;
    @NotBlank
    private String title;
}
