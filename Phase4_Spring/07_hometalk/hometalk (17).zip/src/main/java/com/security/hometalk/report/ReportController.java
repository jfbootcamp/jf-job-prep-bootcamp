package com.security.hometalk.report;

import com.security.hometalk.user.CustomUserDetails;
import com.security.hometalk.user.User;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

@Controller
@RequiredArgsConstructor
@RequestMapping("/report")
public class ReportController {
    private final ReportService reportService;

    @GetMapping
    public String getReport(Authentication authentication, Model model) {
        User user = currentUser(authentication);
        List<ReportResponse> reports = reportService.findByUser(user);  // 본인 보고 목록 조회
        model.addAttribute("reports", reports);  // 뷰에 보고 목록 전달
        return "report/index";
    }

    private User currentUser(Authentication authentication) {
        // 인증 객체의 principal은 CustomUserDetails이므로 내부의 도메인 User를 꺼내 사용함
        return ((CustomUserDetails)authentication.getPrincipal()).getUser();
    }

    @PostMapping
    public String saveReport(Authentication authentication,
                             @Valid @ModelAttribute ReportRegisterRequest request,
                             BindingResult bindingResult,
                             Model model,
                             RedirectAttributes redirectAttributes
                             )
    {
        User user = currentUser(authentication);
        if (bindingResult.hasErrors()) {
            model.addAttribute("reports", reportService.findByUser(user));
            model.addAttribute("toastType", "error");
            model.addAttribute("toastMessage", "제목과 내용을 모두 입력해 주세요.");
            return "report/index";
        }
        reportService.saveReport(user, request.getTitle(), request.getContent());
        redirectAttributes.addFlashAttribute("toastType", "success");
        redirectAttributes.addFlashAttribute("toastMessage", "업무 보고가 등록되었습니다.");
        return "redirect:/report";
    }

    @PostMapping("/{id}/submit")
    public String submitReport(Authentication authentication,
                               @PathVariable Long id,
                               RedirectAttributes redirectAttributes)
    {
        User user = currentUser(authentication);
        reportService.submitReport(user, id);
        redirectAttributes.addFlashAttribute("toastType", "success");
        redirectAttributes.addFlashAttribute("toastMessage", "승인 요청이 완료되었습니다.");
        return "redirect:/report";
    }

    @DeleteMapping
    public String deleteReport(Authentication authentication,
                               @RequestParam Long id,
                               RedirectAttributes redirectAttributes)
    {
        User user = currentUser(authentication);
        boolean deleted = reportService.deleteReport(user, id);
        if (deleted) {
            redirectAttributes.addFlashAttribute("toastType", "success");
            redirectAttributes.addFlashAttribute("toastMessage", "업무 보고가 삭제되었습니다.");
        } else {
            redirectAttributes.addFlashAttribute("toastType", "error");
            redirectAttributes.addFlashAttribute("toastMessage", "삭제할 수 없는 보고서입니다.");
        }
        return "redirect:/report";
    }


}
