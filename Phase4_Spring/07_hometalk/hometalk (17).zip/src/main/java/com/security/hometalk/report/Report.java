package com.security.hometalk.report;

import com.security.hometalk.user.User;
import jakarta.persistence.*;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.time.LocalDateTime;

@Entity
@Table(name = "report")
@Getter
@NoArgsConstructor(access = AccessLevel.PROTECTED)
@EntityListeners(AuditingEntityListener.class)  // 저장/수정 시점에 JPA Auditing 이벤트를 받아 생성일과 수정일을 자동 기록함
public class Report {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String title;
    private String content;
    @CreatedDate
    private LocalDateTime createdAt;
    @LastModifiedDate
    private LocalDateTime updatedAt;
    @Enumerated(EnumType.STRING)
    private ReportStatus status;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "USER_ID")
    private User user;

    public Report(String title, String content, User user) {
        this.title = title;
        this.content = content;
        this.user = user;
        this.status = ReportStatus.PRIVATE; // 최초 작성 시 비공개 상태
    }

    // PRIVATE 상태일 때만 승인 요청 가능
    public void submit() {
        if (this.status == ReportStatus.PRIVATE) {
            this.status = ReportStatus.PENDING;
        }
    }

    public void approve() {
        this.status = ReportStatus.APPROVED;
    }
    public void reject() {
        this.status = ReportStatus.REJECTED;
    }
}
