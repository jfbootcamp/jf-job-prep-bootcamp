package com.security.hometalk.report;

import com.security.hometalk.user.User;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ReportRepository extends JpaRepository<Report, Long> {
    /* report.user는 Lazy 로딩이므로, 트랜잭션 종료 후 화면에서 접근하면
      LazyInitializationException 이 발생할 수 있음 => report 엔티티의 user 필드를
      함께 조회해 추가 조회가 필요 없게 함  */
    /* 관리자 화면에서 승인 요청한 보고서 목록을 User를 함께 조회 */
    @EntityGraph(attributePaths = "user")
    List<Report> findByStatusOrderByIdDesc(ReportStatus status);

    // 특정 사용자의 업무보고 목록을 최신순으로 조회 (내 보고 내역 화면)
    // SELECT r FROM Report r WHERE r.user = :user OREDER BY r.id DESC
    List<Report> findByUserOrderByIdDesc(User user);

    /*보고서 보고 ID와 작성자가 일치하는지 보고서 단건 조회하기  (본인이 보고한 것만 접근 허용)*/
    Report findByIdAndUser(Long id, User user);
}
