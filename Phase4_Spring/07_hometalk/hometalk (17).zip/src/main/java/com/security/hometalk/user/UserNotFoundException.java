package com.security.hometalk.user;

/* 사용자를 찾을 수 없을 때 발생하는 예외임  */
public class UserNotFoundException extends RuntimeException {
    public UserNotFoundException() {
        super("사용자를 찾을 수 없습니다.");
    }
}
