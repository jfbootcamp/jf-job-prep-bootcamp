package com.security.hometalk.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.factory.PasswordEncoderFactories;
import org.springframework.security.crypto.password.PasswordEncoder;

@Configuration      // PasswordEncoder Bean을 등록하기 위한 Spring 설정 클래스
public class PasswordEncoderConfig {

    @Bean  // UserService와 Spring Security가 PasswordEncoder를 DI 사용하게 함
    public PasswordEncoder passwordEncoder() {
        // DelegatingPasswordEncoder는 기본 인코딩 방식으로 BCrypt 사용함.
        return PasswordEncoderFactories.createDelegatingPasswordEncoder();
    }
}
