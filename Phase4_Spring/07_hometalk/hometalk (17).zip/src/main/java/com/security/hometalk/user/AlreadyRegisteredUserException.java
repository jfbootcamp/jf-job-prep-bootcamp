package com.security.hometalk.user;

/* 이미 가입된 사용자명으로 회원 가입을 시도했을 때 발생하는 예외임 */
public class AlreadyRegisteredUserException extends RuntimeException {
    /* 여러 화면에서 공통으로 처리할 시스템 예외가 아니라 ,
    * 회원 가입 중복 검사라는 구체적인 업무 예외임 */
    public AlreadyRegisteredUserException() {
        super("이미 등록된 유저입니다.");
    }
}
