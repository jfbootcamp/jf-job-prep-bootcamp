package com.security.hometalk.config;

import com.security.hometalk.announcement.AnnouncementService;
import com.security.hometalk.report.ReportService;
import com.security.hometalk.user.User;
import com.security.hometalk.user.UserService;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

@Configuration
@RequiredArgsConstructor
@Profile("!test")  // test 프로파일에서는 실행하지 않음
@ConditionalOnProperty(prefix = "app.data.init", name = "enabled", havingValue = "true")
public class InitializeDefaultConfig {
    private static final Logger logger = LoggerFactory.getLogger(InitializeDefaultConfig.class);
    private final UserService userService;
    private final ReportService reportService;
    private final AnnouncementService announcementService;

    @Bean
    public CommandLineRunner initCommandLineRunner() {      // 앱 시작시 자동 실행
        return args -> {
            initializeDefaultUser();
            initializeDefaultAdmin();
        };
    }

    private void initializeDefaultAdmin() {
        if (userService.findByUsername("admin") != null) {
            logger.info("admin 계정 이미 존재 - skip");
            return;
        }

        logger.info("admin 계정 생성 중....");
        userService.signupAdmin("admin", "admin");

        announcementService.saveAnnouncement("HomeTalk에 오신 것을 환영합니다.",
                "스프링 시큐리티 실습을 위한 첫 번째 공지입니다.");
        announcementService.saveAnnouncement(
                "실습 체크리스트",
                "1. 회원가입\n2. 로그인\n3. 권한별 페이지 확인\n4. 로그아웃"
        );
        logger.info("admin 계정 + 공지 2건 생성 완료");

    }

    private void initializeDefaultUser() {
        if (userService.findByUsername("user") != null) {   // 이미 존재하면 중복 삽입 방지
            return;
        }

        User user = userService.signup("user", "user");
        reportService.saveReport(user, "첫 번째 업무 보고", "비공개 상태로 작성된 보고서입니다. 승인 요청 버튼을 눌러 관리자에게 제출할 수 있습니다.");
        reportService.saveReport(user, "스프링 시큐리티 테스트", "user/user 계정으로 로그인해 보세요.");
    }
}
