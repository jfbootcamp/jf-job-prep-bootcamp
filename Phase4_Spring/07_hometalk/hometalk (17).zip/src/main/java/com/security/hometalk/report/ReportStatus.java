package com.security.hometalk.report;

public enum ReportStatus {

    PRIVATE("비공개", "badge-private"),
    PENDING("승인 요청", "badge-pending"),
    APPROVED("승인", "badge-approved"),
    REJECTED("반려", "badge-rejected");

    private final String displayName;
    private final String badgeClass; // 상태별 배지 CSS 클래스명

    ReportStatus(String displayName, String badgeClass) {
        this.displayName = displayName;
        this.badgeClass = badgeClass;
    }

    public String getDisplayName() {
        return displayName;
    }

    public String getBadgeClass() {
        return badgeClass;
    }
}
