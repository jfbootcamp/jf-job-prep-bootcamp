package com.security.hometalk.user;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequiredArgsConstructor
@RequestMapping("/signup")
public class SignUpController {
    private final UserService userService;

    @GetMapping
    public String signup() {
        return "signup";
    }

    @PostMapping
    public String signup(
            @Valid @ModelAttribute UserRegisterDto userDto,
            BindingResult bindingResult,
            Model model,
            RedirectAttributes redirectAttributes
    ) {
        if (bindingResult.hasErrors()) {
            model.addAttribute("toastType", "error");
            model.addAttribute("toastMessage", "아이디와 비밀번호를 모두 입력해 주세요.");
            return "signup";
        }

        try {
            userService.signup(userDto.getUsername(), userDto.getPassword());
        } catch (AlreadyRegisteredUserException e) {
            model.addAttribute("toastType", "error");
            model.addAttribute("toastMessage", "이미 가입된 사용자입니다.");
            return "signup";
        }

        redirectAttributes.addFlashAttribute("toastType", "success");
        redirectAttributes.addFlashAttribute("toastMessage",
                "회원가입이 완료되었습니다. 로그인에 주세요.");
        return "redirect:/login";
    }
}
