package com.security.hometalk.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;

@Configuration      // JPA Auditing 기능을 켜기 위한 Spring 설정 클래스
@EnableJpaAuditing  // @CreatedDate, @LastModifiedDate 같은 Auditing 어노테이션이 동작하도록 활성화함
public class JpaAuditorConfig {
    // 별도 Bean이 없어도 @EnableJpaAuditing만으로 생성일/수정일 자동 기록 기능을 사용할수 있음
}
