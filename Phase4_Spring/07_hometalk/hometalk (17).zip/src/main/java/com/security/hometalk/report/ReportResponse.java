package com.security.hometalk.report;

import lombok.Getter;

import java.time.LocalDateTime;

@Getter
public class ReportResponse {
    private final Long id;
    private final String title;
    private final String content;
    private final String username;
    ReportStatus status;        // 승인 처리 상태
    private final LocalDateTime createdAt;

    public ReportResponse(Long id, String title, String content,
                          String username,ReportStatus status,
                          LocalDateTime createdAt) {
        this.id = id;
        this.title = title;
        this.content = content;
        this.username = username;
        this.createdAt = createdAt;
        this.status = status;
    }

    public static ReportResponse from(Report report) {
        String username = report.getUser() != null ? report.getUser().getUsername() : null;
        return new ReportResponse(report.getId(), report.getTitle(),
                                report.getContent(), username,
                                report.getStatus(),
                                report.getCreatedAt());
    }
}
