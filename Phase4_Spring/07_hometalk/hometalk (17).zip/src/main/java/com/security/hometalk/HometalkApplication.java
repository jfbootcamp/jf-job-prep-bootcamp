package com.security.hometalk;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HometalkApplication {

	public static void main(String[] args) {
		SpringApplication.run(HometalkApplication.class, args);
	}

}
