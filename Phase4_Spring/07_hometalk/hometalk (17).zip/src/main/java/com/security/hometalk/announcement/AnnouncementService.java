package com.security.hometalk.announcement;

import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
@RequiredArgsConstructor
public class AnnouncementService {
    private final AnnouncementRepository announcementRepository;

    // 모든 공지 사항 조회
    @Transactional(readOnly = true)
    public List<Announcement> findAll() {   //Sort.by(정렬방향,정렬기준필드)
        return announcementRepository.findAll(Sort.by(Sort.Direction.DESC, "id"));
    }

    // 공지 사항 저장
    public Announcement saveAnnouncement(String title, String content) {
        return announcementRepository.save(new Announcement(title, content)); //Announcement 객체를 생성해 DB INSERT
    }

    // 공지 사항 삭제
    public void deleteAnnouncement(Long id) {
        // id로 조회 후 존재할 때만 삭제, 없는 id로 요청해도 예외 없이 무시
        announcementRepository.findById(id).ifPresent(announcementRepository::delete);
    }
}
