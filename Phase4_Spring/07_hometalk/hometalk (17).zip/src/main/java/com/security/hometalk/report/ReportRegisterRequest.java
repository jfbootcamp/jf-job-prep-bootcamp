package com.security.hometalk.report;

import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ReportRegisterRequest {
    @NotBlank
    private String title;
    @NotBlank
    private String content;
}
