package com.security.hometalk.admin;

import com.security.hometalk.report.ReportService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequiredArgsConstructor
@RequestMapping("/admin")
public class AdminController {
    private final ReportService reportService;

    @GetMapping
    public String getPendingReports(Model model) {
        model.addAttribute("reports", reportService.findPendingReports());
        return "admin/index";
    }
}
