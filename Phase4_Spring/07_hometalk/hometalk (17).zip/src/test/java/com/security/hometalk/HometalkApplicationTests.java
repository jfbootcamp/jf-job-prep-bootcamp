package com.security.hometalk;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HometalkApplicationTests {

	@Test
	void contextLoads() {
	}

}
