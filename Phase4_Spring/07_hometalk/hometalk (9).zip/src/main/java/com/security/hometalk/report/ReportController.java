package com.security.hometalk.report;

import com.security.hometalk.user.CustomUserDetails;
import com.security.hometalk.user.User;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;

@Controller
@RequiredArgsConstructor
@RequestMapping("/report")
public class ReportController {
    private final ReportService reportService;

    @GetMapping
    public String getreport(Authentication authentication, Model model) {
        User user = currentUser(authentication);
        List<ReportResponse> reports = reportService.findByUser(user);
        model.addAttribute("reports", reports);
        return "report/index";
    }

    private User currentUser(Authentication authentication) {
        // 인증 객체의 principal은 CustomUserDetails이므로 내부의 도메인 User를 꺼내 사용함
        return ((CustomUserDetails)authentication.getPrincipal()).getUser();
    }


}
