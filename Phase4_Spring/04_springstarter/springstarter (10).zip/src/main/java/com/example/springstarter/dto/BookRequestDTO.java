package com.example.springstarter.dto;

public class BookRequestDTO {
}
