package com.example.springstarter.controller;

import com.example.springstarter.dto.BookRequestDTO;
import com.example.springstarter.dto.BookViewDTO;
import com.example.springstarter.entity.Book;
import com.example.springstarter.service.BookService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import jakarta.validation.Valid;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@Controller
@AllArgsConstructor
@RequestMapping("/books")
public class BookController {
    private BookService bookService;

    @GetMapping
    public String showBookList(Model model) {
        List<Book> books = bookService.getAll();
        model.addAttribute("books", books);
        return "list";
    }

    @GetMapping("/{id}")
    public String showBookDetail(@PathVariable Long id, Model model) {
        /*
            Optional: 못 찾으면 null 대신 빈 Optional이 반환됨
            null을 직접 다루면 NullPointerException이 발생하기 쉬운데,
            Optional을 사용하면 값의 존재 여부를 명시적으로 처리하도록 강제할 수 있음.

            isPresent() 패턴 (비추천 - Optional의 의미가 퇴색됨)
                - Optional을 쓰면서 결국  if ~else로 풀어서 Optional 도입 취지에 맞지 않음
                - get()을 직접 호출하는 것은 안티패턴으로 간주됨

            orElseThrow() 패턴 (권장 - 함수형 API 활용)
                - 한 줄로 "없으면 예외"라는 의도가 명확


         */
        Book book = bookService.getById(id)
                .orElseThrow(() -> new IllegalArgumentException("Invaild Book Id:" + id));

        model.addAttribute("book", book);

        //평균 평점 계산 BookService에 위임
        String averageRating = bookService.getFormattedAvgRating(id);
        model.addAttribute("averageRating", averageRating);

        return "detail";
    }

    @Operation(
            summary = "도서 등록",
            description = "새 도서 정보를 JSON으로 받아 DB에 저장하고, 생성된 도서 정보를" +
                    "201 Created로 반환합니다.\n\n"
                    + "- 요청 body는 `application/json` 형식이어야 한다. \n"
                    + "- `@Valid` 유효성 검사 실패시 GlobalExceptionHandler가 400 Bad Request로 응답합니다.\n"
                    + "- 응답 body에는 생성된 도서의 id, subject, price, author, page, createdAt이 포함됩니다."
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "도서 등록 성공"),
            @ApiResponse(responseCode = "400", description = "유효성 검사 실패")
    })
    @PostMapping(consumes = "application/json",
                produces = "application/json")
    @ResponseBody
    public ResponseEntity<BookViewDTO> addBook(
            @Valid @RequestBody BookRequestDTO bookRequestDTO) {

        Book book = new Book();
        book.setSubject(bookRequestDTO.getSubject());
        book.setPrice(bookRequestDTO.getPrice());
        book.setAuthor(bookRequestDTO.getAuthor());
        book.setPage(bookRequestDTO.getPage());

        book = bookService.save(book);      // DB 저장 후 생성된 ID가 반영된 엔티티로 할당

        BookViewDTO bookViewDTO = new BookViewDTO(book.getId(), book.getSubject(),
                book.getPrice(), book.getAuthor(), book.getPage(), book.getCreatedAt());
        return ResponseEntity.status(HttpStatus.CREATED).body(bookViewDTO);
                // HTTP 상태코드 201(Created) 설정 + body에 bookViewDTO 담아 반환
                // --> @ResponseBody가 JSON으로 직렬화하여 최종 응답
    }
}
















