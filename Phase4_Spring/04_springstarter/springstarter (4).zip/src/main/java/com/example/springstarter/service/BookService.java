package com.example.springstarter.service;

import com.example.springstarter.entity.Book;
import com.example.springstarter.repository.BookRepository;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
@AllArgsConstructor
public class BookService {
    private final BookRepository bookRepository;

    public List<Book> getAll() {
        return bookRepository.findAll();
    }

    public Book save(Book book) {
        if (book.getId() == null) {
            book.setCreatedAt(LocalDateTime.now());
        }
        return bookRepository.save(book);       // insert, update
    }

}














