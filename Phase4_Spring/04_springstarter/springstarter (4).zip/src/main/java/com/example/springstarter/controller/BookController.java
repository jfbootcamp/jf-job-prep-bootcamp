package com.example.springstarter.controller;

import com.example.springstarter.entity.Book;
import com.example.springstarter.service.BookService;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@Controller
@AllArgsConstructor
public class BookController {
    private BookService bookService;

    @GetMapping("/")
    public String list(Model model) {
        List<Book> books = bookService.getAll();
        model.addAttribute("books", books);
        return "list";
    }
}
















