package com.example.springstarter.controller;

import com.example.springstarter.entity.Book;
import com.example.springstarter.service.BookService;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;
import java.util.Optional;

@Controller
@AllArgsConstructor
@RequestMapping("/books")
public class BookController {
    private BookService bookService;

    @GetMapping
    public String list(Model model) {
        List<Book> books = bookService.getAll();
        model.addAttribute("books", books);
        return "list";
    }

    @GetMapping("/{id}")
    public String getDetails(@PathVariable Long id, Model model) {
        /*
            Optional: 못 찾으면 null 대신 빈 Optional이 반환됨
            null을 직접 다루면 NullPointerException이 발생하기 쉬운데,
            Optional을 사용하면 값의 존재 여부를 명시적으로 처리하도록 강제할 수 있음.

            isPresent() 패턴 (비추천 - Optional의 의미가 퇴색됨)
                - Optional을 쓰면서 결국  if ~else로 풀어서 Optional 도입 취지에 맞지 않음
                - get()을 직접 호출하는 것은 안티패턴으로 간주됨

            orElseThrow() 패턴 (권장 - 함수형 API 활용)
                - 한 줄로 "없으면 예외"라는 의도가 명확


         */
        Book book = bookService.getById(id)
                .orElseThrow(() -> new IllegalArgumentException("Invaild Book Id:" + id));

        model.addAttribute("book", book);

        //평균 평점 계산 BookService에 위임
        String averageRating = bookService.getFormattedAvgRating(id);
        model.addAttribute("averageRating", averageRating);

        return "detail";
    }
}
















