package com.example.springstarter.service;

public class BookImageService {
}
