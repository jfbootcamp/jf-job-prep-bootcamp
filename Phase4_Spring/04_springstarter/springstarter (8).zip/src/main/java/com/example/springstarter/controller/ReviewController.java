package com.example.springstarter.controller;

import com.example.springstarter.entity.Book;
import com.example.springstarter.entity.Review;
import com.example.springstarter.service.BookService;
import com.example.springstarter.service.ReviewService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.time.LocalDateTime;

/*
    * 리뷰 삭제/등록

        /book/{bookId}/reviews/{reviewId}
        ------------- -------------------
        책 리소스          리뷰 리소스

    * HTML <form>은 method="GET"과 method="POST" 만 지원함
        - <form method="DELETE"> <---- 브라우저가 무시하고 POST으로 보냄

 */

@Controller
@RequiredArgsConstructor
@RequestMapping("/books/{bookId}/reviews")
public class ReviewController {
    private final BookService bookService;
    private final ReviewService reviewService;

    //리뷰 삭제
    @PostMapping("/{reviewId}/delete")
    public String deleteReview(@PathVariable Long bookId, @PathVariable Long reviewId) {
        reviewService.deleteReviewById(reviewId);
        return "redirect:/books/" + bookId + "?deleted=true";
    }

    /*
        리뷰 등록
        [요청 흐름]
        detail.html 리뷰 작성 폼 -> POST /books/{bookId}/reviews
        [처리 순서]
         1) bookId로 어떤 책의 리뷰인지 찾음 (없으면 예외)
         2) review 객체에 book과 생성시간을 세팅
         3) DB에 저장
         4) redirect + ?registered=true -> detail.html의 JS가 "등록 완료" alert 표시
     */
    @PostMapping
    public String reviewRegister(@PathVariable Long bookId, Review review) {
        Book book = bookService.getById(bookId)
                .orElseThrow(() -> new IllegalArgumentException("Invalid Book Id: " + bookId));
        review.setBook(book);
        review.setCreatedAt(LocalDateTime.now());
        reviewService.save(review);
        return "redirect:/books/" +book.getId()+ "?registered=true";
    }
}
