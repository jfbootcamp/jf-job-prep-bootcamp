package com.example.springstarter.service;

import com.example.springstarter.entity.Book;
import com.example.springstarter.entity.Review;
import com.example.springstarter.repository.BookRepository;
import com.example.springstarter.repository.ReviewRepository;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor        // 생성자 의존성 주입
public class ReviewService {

    private final BookRepository bookRepository;
    private final ReviewRepository reviewRepository;

    public List<Book> getAll() {
        return bookRepository.findAll();      // select * from book;
    }

    public Optional<Book> getById(Long id) {
        return bookRepository.findById(id);    // select * from book where id=3;
    }


    public Review save(Review review) {
        return reviewRepository.save(review);
    }

    // 리뷰 데이터 존재 여부 확인 (초기 데이터 삽입 시 사용)
    public long count() {
        return reviewRepository.count();
    }

    /*
        기본 메서드 (save, deleteById) --> @Transactional 내장 (안 붙여도 됨
        커스텀 메서드 @Modifying + @Query  --> @Transactional 필수 (직접 붙여야 함)
     */
    @Transactional
    public void deleteReviewById(Long review_id) {
        reviewRepository.deleteReviewDirectly(review_id);
    }
}
