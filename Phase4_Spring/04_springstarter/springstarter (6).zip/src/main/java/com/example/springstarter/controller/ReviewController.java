package com.example.springstarter.controller;

import com.example.springstarter.service.ReviewService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

/*
    * 리뷰 삭제/등록

        /book/{bookId}/reviews/{reviewId}
        ------------- -------------------
        책 리소스          리뷰 리소스

    * HTML <form>은 method="GET"과 method="POST" 만 지원함
        - <form method="DELETE"> <---- 브라우저가 무시하고 POST으로 보냄

 */

@Controller
@RequiredArgsConstructor
@RequestMapping("/books/{bookId}/reviews")
public class ReviewController {

    private final ReviewService reviewService;

    //리뷰 삭제
    @PostMapping("/{reviewId}/delete")
    public String deleteReview(@PathVariable Long bookId, @PathVariable Long reviewId) {
        reviewService.deleteReviewById(reviewId);
        return "redirect:/books/" + bookId;
    }
}
