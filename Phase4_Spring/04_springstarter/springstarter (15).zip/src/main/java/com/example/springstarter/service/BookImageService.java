package com.example.springstarter.service;

import com.example.springstarter.entity.Book;
import com.example.springstarter.repository.BookImageRepository;
import com.example.springstarter.util.ImageUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.RandomStringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

@Slf4j
@Service
@RequiredArgsConstructor
public class BookImageService {
    private static final long MAX_FILE_SIZE = 5 * 1024 * 1024; // 5MB 
    private static final int MAX_IMAGE_COUNT = 10;      // 도서당 최대 이미지 수 
    private final BookImageRepository bookImageRepository;

    /*
        이미지 파일 저장 핵심 비즈니스 로직
        컨트롤러는 요청/응답 처리만, 서비스는 검증,디스크 저장,썸내일 생성, DB 기록 일괄 담당
     */
    @Transactional(rollbackFor = Exception.class) // checked Exception 포함 모든 예외 발생 시 DB 트랜잭션 롤백
    public void saveImage(MultipartFile file, Book book, int type, String uploadPath)  throws  Exception {
        // 검증 단계 (작업 전 사전 차단)
        // ① 빈 파일(isEmpty) 체크 - 크기가 0인 파일은 이후 처리 (의미 없으므로 즉시 차단)
        if (file.isEmpty()) {
            throw new IllegalArgumentException("빈 파일은 업로드할 수 없습니다: " + file.getOriginalFilename());
        }

        String contentType = file.getContentType();  // 업로드된 파일의 MIME 타입 추출 --> 다음 검증에 사용
        // ② MIME 타입 검증 -- image/png, jpg, jpeg 만 허용
        if (contentType == null) {
            log.warn("contentType 확인 불가 - 파일명: {}", file.getOriginalFilename());
            throw new IllegalArgumentException("파일 형식을 확인 할수 없습니다: " + file.getOriginalFilename());
        }

        // ② MIME 타입 검증
        if (!contentType.equals("image/png")
            && !contentType.equals("image/jpeg")
            && !contentType.equals("image/jpg")) {
            throw new IllegalArgumentException("허용되지 않는 파일 형식입니다(png/jpg/jpeg만 허용): " + file.getOriginalFilename());
        }

        // ③ 파일 크기 검증 (최대 5MB) : MAX_FILE_SIZE 초과시 디스크 저장 없이 즉시 차단
        // 개별 파일 크기는 여기서 별도 검증
        if (file.getSize() > MAX_FILE_SIZE) {
            log.warn("파일 크기 초과 - 파일명: {}, 크기: {}bytes (최대 {}bytes)",
                    file.getOriginalFilename(), file.getSize(), MAX_FILE_SIZE);
            throw new IllegalArgumentException("파일 크기가 허용 한도를 초과했습니다 (최대 5MB) " + file.getOriginalFilename());
        }

        // ④ 도서당 이미지 수 제한 (최대 10장) - MAX_IMAGE_COUNT 초과시 차단
        // 제한이 없으면 하나의 도서에 무제한 업로드가 가능하며 디스크 고갈 위험이 있음
        long imageCount = bookImageRepository.countByBook(book);
        if (imageCount >= MAX_IMAGE_COUNT) {
            throw new IllegalArgumentException("이미지는 도서당 최대 " + MAX_IMAGE_COUNT + "장까지 업로드 가능합니다. (현재: "
                            + imageCount + "장)");
        }

        // ⑤ 안전한 파일명 생성 - RandomStringUtils 10자리 + 확장자만 추출
        // 검증 통과 + 비즈니스 로직 실행

        String originalFileName = file.getOriginalFilename();  // 원본 파일명 -> DB 메타데이터로(표시용)만 사용. 실제 저장경로에는 사용하지 않음
        String generatedString =
                RandomStringUtils.random(MAX_IMAGE_COUNT, true, true); // 파일명 중복 방지용 10자리 랜덤 문자열 (영문자+숫자 혼합)

        // 원본 파일명 전체 대신 확장자만 추출하여 실제 저장 파일에 사용
        // -> 확장자만 추출하고 나머지는 랜던 문자열로 대처하여 공격자가 경로를 제어할 없도록 차단
        String extension = (originalFileName != null && originalFileName.contains("."))
                ? originalFileName.substring(originalFileName.lastIndexOf("."))
                : "";

        // ⑥ 도서별 디렉토리 생성 + 절대 경로 반환 (ImageUtil.makePath())
        // type에 따라 안전한 저장 파일명 결정
        String safeFileName = (type == 1)
                ? "thumb_" + generatedString + extension
                : generatedString + extension;
        // 도서별 전용 디렉토리 생성 및 절대 경로 반환
        String absoluteFilePath =
                ImageUtil.makePath(uploadPath, safeFileName, book.getId());
        Path path = Paths.get(absoluteFilePath);

        // 디스크에 파일 저장 (step1)
        if (type != 1) {
            // type2,3: 원본 파일 그대로 저장 (동일 경로 파일 존재 시 덮어쓰기)
            Files.copy(file.getInputStream(), path,
                            StandardCopyOption.REPLACE_EXISTING);
        } else {
            // type1: Scalr로 300px 기준 리사이즈 후 썸네일 저장 (ImageIO.write 사용)
            //
        }

    }
}
