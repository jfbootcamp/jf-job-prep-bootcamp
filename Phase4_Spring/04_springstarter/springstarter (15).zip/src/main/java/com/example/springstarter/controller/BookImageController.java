package com.example.springstarter.controller;

import com.example.springstarter.entity.Book;
import com.example.springstarter.exception.BookNotFoundException;
import com.example.springstarter.service.BookImageService;
import com.example.springstarter.service.BookService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

/*
    BookImageController
        - 도서 이미지 CRUD 전담
        - 이미지 관련 엔드포인트를 분리하여 SRP 준수
        - 담당 엔드포인트
            - POST      /books/{bookId}/images?type={1|2|3}   --> 이미지 업로드
            - GET       /books/{image_id}/imageSrc            --> 이미지 파일 조회
            - DELETE    /books/{image_id}/delete              --> 이미지 삭제

 */
@Tag(name = "book-image-controller", description = "도서 이미지 업로드, 조회, 삭제 API")
@Slf4j
@Controller
@RequiredArgsConstructor
@RequestMapping("/books")
public class BookImageController {

    private final BookService bookService;
    private final BookImageService bookImageService;

    @Value("${upload.path}")     //application.yaml의 upload.path 값을 주입(파일 업로드 저장 경로)
    private String uploadPath;

    // 파일(이미지) 업로드 REST API
    @Operation(
            summary = "도서 이미지 업로드",
            description = "특정 도서에 이미지 파일을 한 장 이상 업로드합니다.\n\n"
                    + "- `type` 파라미터로 이미지 처리 방식을 지정합니다.\n"
                    + " - `type=1` : 썸네일 - Scalr로 300px 리사이즈 후 저장, 파일명에 `thumb_` 접두사 추가 \n"
                    + " - `type=2` : 표지 이미지  - 원본 그대로 저장 (향후 용도 구분용)\n"
                    + " - `type=3` : 상세 이미지  - 원본 그대로 저장 (향후 용도 구분용)\n"
                    + "- 파일별로 검증(MIME 타입,5MB 크기 제한)을 수행하며, 일부 파일이 실패해도 "
                    + "나머지는 계속 처리합니다.\n"
                    + "- 응답 JSON의 `SUCCESS`키에 성공 파일명 목록, `ERRORS`키에 실패 파일명 목록이 반환됩니다."
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200",
                    description = "업로드 처리 완료 - SUCCESS/ERRORS 파일명 목록 JSON 반환"),
            @ApiResponse(responseCode = "404",
                    description = "해당 bookId의 도서가 DB에 존재하지 않음")
    })
    @ResponseBody
    @PostMapping(value = "{bookId}/images",
            consumes = "multipart/form-data")
    public ResponseEntity<?> uploadImages(@RequestPart MultipartFile[] files,
                                          @PathVariable Long bookId,
                                          @RequestParam int type) {

        // 이미지 저장 전 해당 bookId의 도서가 DB에 실제 존재하는지 먼저 검증
        // DB에 없으면 orElseThrow()가 BookNotFoundException 발생 -> GlobalExceptionHandler --> 404
        Book book = bookService.findById(bookId)
                .orElseThrow(() -> new BookNotFoundException(bookId));

        List<String> successImageName = new ArrayList<>();  // 업로드 성공한 파일명을 수집
        List<String> errorImageName = new ArrayList<>();  // 업로드 실패한 파일명을 수집

        // MultipartFile[] 배열을 List로 변환 후 스트림으로 파일을 하나씩 순회
        Arrays.asList(files).stream().forEach(file -> {
            try {
                bookImageService.saveImage(file, book, type, uploadPath); // 검증 + 디스크 저장 + DB 기록 + 실패 시 디스크 롤백까지 Service 일괄 처리
                successImageName.add(file.getOriginalFilename());   // 모든 처리 성공 -> SUCCESS 수집
            } catch (Exception e) {
                log.error("이미지 처리 실패 - 파일명: {}, 원인 {}", file.getOriginalFilename(), e.getMessage(), e);
                errorImageName.add(file.getOriginalFilename());
            }
        });

        // 모든 파일 처리가 끝난 후 -> 성공/실패 결과를 하나의 Map으로 묶어 응답 구성
        HashMap<String, List<String>> result = new HashMap<>();
        result.put("SUCCESS", successImageName); //업로드 성공한 파일명 목록을 "SUCCESS" 키로 담음
        result.put("ERROR", errorImageName);    //업로드 실패한 파일명 목록을 "ERROR"키로 담음 (빈 리스트면 전체 성공)

        // Map을 List에 담음 (이유: 향후 여러 결과 목록을 배열 행태로 확장할 수 있는 구조가 됨)
        List<HashMap<String, List<String>>> response = new ArrayList<>();
        response.add(result);   // result를 List에 담아 반환하면 JSON 배열 ( [{...}] )
        // -> 클라이언트는 항상 배열로 파싱 가능하여 응답 구조가 일관됨
        return ResponseEntity.ok(response); // 200 ok + 성공/실패 파일명 목록 JSON 배열로 최종 응답
    }

}
