package com.example.springstarter.controller;

import com.example.springstarter.entity.Book;
import com.example.springstarter.service.BookService;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.List;
import java.util.Optional;

@Controller
@AllArgsConstructor
public class BookController {
    private BookService bookService;

    @GetMapping("/")
    public String list(Model model) {
        List<Book> books = bookService.getAll();
        model.addAttribute("books", books);
        return "list";
    }

    @GetMapping("/detail/{id}")
    public String getDetails(@PathVariable Long id, Model model) {
        /*
            Optional: 못 찾으면 null 대신 빈 Optional이 반환됨
            null을 직접 다루면 NullPointerException이 발생하기 쉬운데,
            Optional을 사용하면 값의 존재 여부를 명시적으로 처리하도록 강제할 수 있음.
         */
        Optional<Book> bookOptional = bookService.getById(id);
        if (bookOptional.isPresent()) {         // 조회된 Book이 존재하는 경우
            Book book = bookOptional.get();     // 리뷰정보도 담아져 있음
            model.addAttribute("book", book);

            return "detail";
        } else {
            return "redirect:/";
        }
    }
}
















