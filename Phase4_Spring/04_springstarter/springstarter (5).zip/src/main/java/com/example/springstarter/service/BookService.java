package com.example.springstarter.service;

import com.example.springstarter.entity.Book;
import com.example.springstarter.repository.BookRepository;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
@AllArgsConstructor
public class BookService {
    private final BookRepository bookRepository;

    public List<Book> getAll() {
        return bookRepository.findAll();
    }

    public Optional<Book> getById(Long id) {
        return bookRepository.findById(id);         // select * from book where id=1
    }

    public Book save(Book book) {
        /*
            JPA의 save()는 id 유무로 INSERT / UPDATE를 자동 구분함
            id == null -> 새 책 등록 (INSERT) -> 등록일시를 현재 시간으로 설정
            id != null -> 기존 책 수정 (UPDATE) -> 등록일시를 건드리지 않음 (최초 등록일 유지)
            이 체크 없이 항상 setCreatedAt(now())를 하면 수정할 때마다 등록일시가 현재 시간으로 덮어쓰워지는
            문제가 발생함
         */
        if (book.getId() == null) {
            book.setCreatedAt(LocalDateTime.now());
        }
        return bookRepository.save(book);       // insert, update
    }

}














