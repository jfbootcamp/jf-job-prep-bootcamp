package com.example.springstarter.controller;

/*
    React 전용 JSON API 컨트롤러
        - BookController (@Controller)  -> Thymeleaf HTML 반환
        - BookApiController (@RestController) -> JSON 반환
            - /api/books    -> JSON (React fetch 대상)
 */

import com.example.springstarter.dto.BookViewDTO;
import com.example.springstarter.exception.BookNotFoundException;
import com.example.springstarter.service.BookImageService;
import com.example.springstarter.service.BookService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping("/api/books")
public class BookApiController {
    private final BookService bookService;
    private final BookImageService bookImageService;

    // 전체 도서 목록 조회
    @GetMapping
    public ResponseEntity<List<BookViewDTO>> getBookList() {
        List<BookViewDTO> books = bookService.getAll()
                .stream()
                .map(book -> new BookViewDTO(
                        book.getId(),
                        book.getSubject(),
                        book.getPrice(),
                        book.getAuthor(),
                        book.getPage(),
                        book.getCreatedAt()
                ))
                .collect(Collectors.toList());
        return ResponseEntity.ok(books);    // 200 ok + body : List<BookViewDTO> -> JSON 배열
    }

    // 특정 도서의 이미지 ID 목록 조회 -> React 미리보기(previewList) 구성용
    @GetMapping("/{bookId}/images")
    public ResponseEntity<List<Map<String,Long>>> getBookImages(@PathVariable Long bookId) {
        //bookId 존재 여부 먼저 검증
        bookService.findById(bookId)
                .orElseThrow(() -> new BookNotFoundException(bookId));

        List<Map<String, Long>> imageIds = bookImageService.findByBookId(bookId)
                .stream()
                .map(img -> Map.of("imageId", img.getId()))
                .collect(Collectors.toList());
        return ResponseEntity.ok(imageIds);
    }
}
