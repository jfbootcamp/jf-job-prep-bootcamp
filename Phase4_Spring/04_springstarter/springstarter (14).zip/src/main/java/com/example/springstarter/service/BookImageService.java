package com.example.springstarter.service;

import com.example.springstarter.entity.Book;
import com.example.springstarter.repository.BookImageRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

@Slf4j
@Service
@RequiredArgsConstructor
public class BookImageService {
    private static final long MAX_FILE_SIZE = 5 * 1024 * 1024; // 5MB 
    private static final int MAX_IMAGE_COUNT = 10;      // 도서당 최대 이미지 수 
    private final BookImageRepository bookImageRepository;

    /*
        이미지 파일 저장 핵심 비즈니스 로직
        컨트롤러는 요청/응답 처리만, 서비스는 검증,디스크 저장,썸내일 생성, DB 기록 일괄 담당
     */
    @Transactional(rollbackFor = Exception.class) // checked Exception 포함 모든 예외 발생 시 DB 트랜잭션 롤백
    public void saveImage(MultipartFile file, Book book, int type, String uploadPath)  throws  Exception {
        // 검증 단계 (작업 전 사전 차단)
        // ① 빈 파일(isEmpty) 체크
        


    }
}
