package com.example.springstarter.util;

public class ImageUtil {
}
