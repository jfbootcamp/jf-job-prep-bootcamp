package com.example.springstarter.controller;

import com.example.springstarter.dto.BookRequestDTO;
import com.example.springstarter.dto.BookViewDTO;
import com.example.springstarter.entity.Book;
import com.example.springstarter.exception.BookNotFoundException;
import com.example.springstarter.service.BookImageService;
import com.example.springstarter.service.BookService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import jakarta.validation.Valid;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.*;

@Slf4j
@Controller
@AllArgsConstructor
@RequestMapping("/books")
public class BookController {
    private BookService bookService;

    private final BookImageService bookImageService;

    @Value("${upload.path}")     //application.yaml의 upload.path 값을 주입(파일 업로드 저장 경로)
    private String uploadPath;



    // 전체 도서 목록 조회
    @Operation(
            summary = "도서 목록 조회",
            description = "DB에서 전체 도서 목록을 조회하여 list.html 뷰로 랜더링한다.\n\n"
                    + "- JSON API가 아닌 서버사이드 랜더링(SSR)방식으로, Thymleaf 템플릿에"
                    + " 데이터를 바인딩하여 HTML을 반환합니다.\n"
                    + "- 조회된 Book 리스트는 Model에 'books'키로 담겨 템플릿의 `${books}`로 접근합니다."
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "도서 목록 HTML 페이지 반환 성공")
    })
    @GetMapping
    public String showBookList(Model model) {
        List<Book> books = bookService.getAll();
        model.addAttribute("books", books);
        return "list";
    }

    @GetMapping("/{id}")
    public String showBookDetail(@PathVariable Long id, Model model) {
        /*
            Optional: 못 찾으면 null 대신 빈 Optional이 반환됨
            null을 직접 다루면 NullPointerException이 발생하기 쉬운데,
            Optional을 사용하면 값의 존재 여부를 명시적으로 처리하도록 강제할 수 있음.

            isPresent() 패턴 (비추천 - Optional의 의미가 퇴색됨)
                - Optional을 쓰면서 결국  if ~else로 풀어서 Optional 도입 취지에 맞지 않음
                - get()을 직접 호출하는 것은 안티패턴으로 간주됨

            orElseThrow() 패턴 (권장 - 함수형 API 활용)
                - 한 줄로 "없으면 예외"라는 의도가 명확


         */
        Book book = bookService.getById(id)
                .orElseThrow(() -> new IllegalArgumentException("Invaild Book Id:" + id));

        model.addAttribute("book", book);

        //평균 평점 계산 BookService에 위임
        String averageRating = bookService.getFormattedAvgRating(id);
        model.addAttribute("averageRating", averageRating);

        return "detail";
    }

    @Operation(
            summary = "도서 등록",
            description = "새 도서 정보를 JSON으로 받아 DB에 저장하고, 생성된 도서 정보를" +
                    "201 Created로 반환합니다.\n\n"
                    + "- 요청 body는 `application/json` 형식이어야 한다. \n"
                    + "- `@Valid` 유효성 검사 실패시 GlobalExceptionHandler가 400 Bad Request로 응답합니다.\n"
                    + "- 응답 body에는 생성된 도서의 id, subject, price, author, page, createdAt이 포함됩니다."
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "도서 등록 성공"),
            @ApiResponse(responseCode = "400", description = "유효성 검사 실패")
    })
    @PostMapping(consumes = "application/json",
                produces = "application/json")
    @ResponseBody
    public ResponseEntity<BookViewDTO> addBook(
            @Valid @RequestBody BookRequestDTO bookRequestDTO) {

        Book book = new Book();
        book.setSubject(bookRequestDTO.getSubject());
        book.setPrice(bookRequestDTO.getPrice());
        book.setAuthor(bookRequestDTO.getAuthor());
        book.setPage(bookRequestDTO.getPage());

        book = bookService.save(book);      // DB 저장 후 생성된 ID가 반영된 엔티티로 할당

        BookViewDTO bookViewDTO = new BookViewDTO(book.getId(), book.getSubject(),
                book.getPrice(), book.getAuthor(), book.getPage(), book.getCreatedAt());
        return ResponseEntity.status(HttpStatus.CREATED).body(bookViewDTO);
                // HTTP 상태코드 201(Created) 설정 + body에 bookViewDTO 담아 반환
                // --> @ResponseBody가 JSON으로 직렬화하여 최종 응답
    }


    // 파일(이미지) 업로드 REST API
    @Operation(
            summary = "도서 이미지 업로드",
            description = "특정 도서에 이미지 파일을 한 장 이상 업로드합니다.\n\n"
                + "- `type` 파라미터로 이미지 처리 방식을 지정합니다.\n"
                + " - `type=1` : 썸네일 - Scalr로 300px 리사이즈 후 저장, 파일명에 `thumb_` 접두사 추가 \n"
                + " - `type=2` : 표지 이미지  - 원본 그대로 저장 (향후 용도 구분용)\n"
                + " - `type=3` : 상세 이미지  - 원본 그대로 저장 (향후 용도 구분용)\n"
                + "- 파일별로 검증(MIME 타입,5MB 크기 제한)을 수행하며, 일부 파일이 실패해도 "
                + "나머지는 계속 처리합니다.\n"
                + "- 응답 JSON의 `SUCCESS`키에 성공 파일명 목록, `ERRORS`키에 실패 파일명 목록이 반환됩니다."
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200",
                    description = "업로드 처리 완료 - SUCCESS/ERRORS 파일명 목록 JSON 반환"),
            @ApiResponse(responseCode = "404",
                    description = "해당 bookId의 도서가 DB에 존재하지 않음")
    })
    @ResponseBody
    @PostMapping(value = "{bookId}/images",
                consumes = "multipart/form-data")
    public ResponseEntity<?> uploadImages(@RequestPart MultipartFile[] files,
                                          @PathVariable Long bookId,
                                          @RequestParam int type) {

        // 이미지 저장 전 해당 bookId의 도서가 DB에 실제 존재하는지 먼저 검증
        // DB에 없으면 orElseThrow()가 BookNotFoundException 발생 -> GlobalExceptionHandler --> 404
        Book book = bookService.findById(bookId)
                .orElseThrow(() -> new BookNotFoundException(bookId));

        List<String> successImageName = new ArrayList<>();  // 업로드 성공한 파일명을 수집
        List<String> errorImageName = new ArrayList<>();  // 업로드 실패한 파일명을 수집

        // MultipartFile[] 배열을 List로 변환 후 스트림으로 파일을 하나씩 순회
        Arrays.asList(files).stream().forEach(file -> {
            try {
                bookImageService.saveImage(file, book, type, uploadPath); // 검증 + 디스크 저장 + DB 기록 + 실패 시 디스크 롤백까지 Service 일괄 처리
                successImageName.add(file.getOriginalFilename());   // 모든 처리 성공 -> SUCCESS 수집
            } catch (Exception e) {
                log.error("이미지 처리 실패 - 파일명: {}, 원인 {}", file.getOriginalFilename(), e.getMessage(), e);
                errorImageName.add(file.getOriginalFilename());
            }
        });

        // 모든 파일 처리가 끝난 후 -> 성공/실패 결과를 하나의 Map으로 묶어 응답 구성
        HashMap<String, List<String>> result = new HashMap<>();
        result.put("SUCCESS", successImageName); //업로드 성공한 파일명 목록을 "SUCCESS" 키로 담음
        result.put("ERROR", errorImageName);    //업로드 실패한 파일명 목록을 "ERROR"키로 담음 (빈 리스트면 전체 성공)

        // Map을 List에 담음 (이유: 향후 여러 결과 목록을 배열 행태로 확장할 수 있는 구조가 됨)
        List<HashMap<String, List<String>>> response = new ArrayList<>();
        response.add(result);   // result를 List에 담아 반환하면 JSON 배열 ( [{...}] )
                                // -> 클라이언트는 항상 배열로 파싱 가능하여 응답 구조가 일관됨
        return ResponseEntity.ok(response); // 200 ok + 성공/실패 파일명 목록 JSON 배열로 최종 응답
    }
}
















