package com.example.springstarter.service;

import com.example.springstarter.dto.BookImageResourceDTO;
import com.example.springstarter.entity.Book;
import com.example.springstarter.entity.BookImage;
import com.example.springstarter.exception.BookImageNotFoundException;
import com.example.springstarter.repository.BookImageRepository;
import com.example.springstarter.util.ImageUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.RandomStringUtils;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

@Slf4j
@Service
@RequiredArgsConstructor
public class BookImageService {
    private static final long MAX_FILE_SIZE = 5 * 1024 * 1024; // 5MB 
    private static final int MAX_IMAGE_COUNT = 10;      // 도서당 최대 이미지 수 
    private final BookImageRepository bookImageRepository;

    /*
        이미지 파일 저장 핵심 비즈니스 로직
        컨트롤러는 요청/응답 처리만, 서비스는 검증,디스크 저장,썸내일 생성, DB 기록 일괄 담당
     */
    @Transactional(rollbackFor = Exception.class) // checked Exception 포함 모든 예외 발생 시 DB 트랜잭션 롤백
    public void saveImage(MultipartFile file, Book book, int type, String uploadPath)  throws  Exception {
        // 검증 단계 (작업 전 사전 차단)
        // ① 빈 파일(isEmpty) 체크 - 크기가 0인 파일은 이후 처리 (의미 없으므로 즉시 차단)
        if (file.isEmpty()) {
            throw new IllegalArgumentException("빈 파일은 업로드할 수 없습니다: " + file.getOriginalFilename());
        }

        String contentType = file.getContentType();  // 업로드된 파일의 MIME 타입 추출 --> 다음 검증에 사용
        // ② MIME 타입 검증 -- image/png, jpg, jpeg 만 허용
        if (contentType == null) {
            log.warn("contentType 확인 불가 - 파일명: {}", file.getOriginalFilename());
            throw new IllegalArgumentException("파일 형식을 확인 할수 없습니다: " + file.getOriginalFilename());
        }

        // ② MIME 타입 검증
        if (!contentType.equals("image/png")
            && !contentType.equals("image/jpeg")
            && !contentType.equals("image/jpg")) {
            throw new IllegalArgumentException("허용되지 않는 파일 형식입니다(png/jpg/jpeg만 허용): " + file.getOriginalFilename());
        }

        // ③ 파일 크기 검증 (최대 5MB) : MAX_FILE_SIZE 초과시 디스크 저장 없이 즉시 차단
        // 개별 파일 크기는 여기서 별도 검증
        if (file.getSize() > MAX_FILE_SIZE) {
            log.warn("파일 크기 초과 - 파일명: {}, 크기: {}bytes (최대 {}bytes)",
                    file.getOriginalFilename(), file.getSize(), MAX_FILE_SIZE);
            throw new IllegalArgumentException("파일 크기가 허용 한도를 초과했습니다 (최대 5MB) " + file.getOriginalFilename());
        }

        // ④ 도서당 이미지 수 제한 (최대 10장) - MAX_IMAGE_COUNT 초과시 차단
        // 제한이 없으면 하나의 도서에 무제한 업로드가 가능하며 디스크 고갈 위험이 있음
        long imageCount = bookImageRepository.countByBook(book);
        if (imageCount >= MAX_IMAGE_COUNT) {
            throw new IllegalArgumentException("이미지는 도서당 최대 " + MAX_IMAGE_COUNT + "장까지 업로드 가능합니다. (현재: "
                            + imageCount + "장)");
        }

        // ⑤ 안전한 파일명 생성 - RandomStringUtils 10자리 + 확장자만 추출
        // 검증 통과 + 비즈니스 로직 실행

        String originalFileName = file.getOriginalFilename();  // 원본 파일명 -> DB 메타데이터로(표시용)만 사용. 실제 저장경로에는 사용하지 않음
        String generatedString =
                RandomStringUtils.random(MAX_IMAGE_COUNT, true, true); // 파일명 중복 방지용 10자리 랜덤 문자열 (영문자+숫자 혼합)

        // 원본 파일명 전체 대신 확장자만 추출하여 실제 저장 파일에 사용
        // -> 확장자만 추출하고 나머지는 랜던 문자열로 대처하여 공격자가 경로를 제어할 없도록 차단
        String extension = (originalFileName != null && originalFileName.contains("."))
                ? originalFileName.substring(originalFileName.lastIndexOf("."))
                : "";

        // ⑥ 도서별 디렉토리 생성 + 절대 경로 반환 (ImageUtil.makePath())
        // type에 따라 안전한 저장 파일명 결정
        String safeFileName = (type == 1)
                ? "thumb_" + generatedString + extension
                : generatedString + extension;
        // 도서별 전용 디렉토리 생성 및 절대 경로 반환
        String absoluteFilePath =
                ImageUtil.makePath(uploadPath, safeFileName, book.getId());
        Path path = Paths.get(absoluteFilePath);

        // 디스크에 파일 저장 (step1)
        if (type != 1) {
            // type2,3: 원본 파일 그대로 저장 (동일 경로 파일 존재 시 덮어쓰기)
            Files.copy(file.getInputStream(), path,
                            StandardCopyOption.REPLACE_EXISTING);
        } else {
            // type1: Scalr로 300px 기준 리사이즈 후 썸네일 저장 (ImageIO.write 사용)
            BufferedImage thumbnail = ImageUtil.getThumbnail(file, 300); // 원본을 300px로 리사이즈 -> 메모리 상태
            String format = file.getContentType().split("/")[1];  // "image/png" -> "png" 추출
            ImageIO.write(thumbnail, format, path.toFile());  // 메모리의 썸네일을 디스크에 최종 저장
        }

        // DB에 메타데이터 저장 (step2)
        // 디스크 저장 성공 후 저장 실패 시 -> 디스크 파일 즉시 삭제하여 디스크-DB 불일치(고아 파일) 방지
        try {
            BookImage bookImage = new BookImage();
            bookImage.setOriginalName(originalFileName);  // 사용자에게 보여줄 이름
            bookImage.setFileName(safeFileName);    // 실제 저장 파일명 저장
            bookImage.setBook(book);   // Book 엔티티와 연관관계 설정 (어느 도서의 이미지인지 특정)
            bookImage.setType(type);   // 이미지 용도 구분값 저장 (1: 썸네일, 2,3: 일반 이미지)
            bookImageRepository.save(bookImage);        // DB 최종 저장
        } catch (Exception e) {
            Files.deleteIfExists(path);  // DB 저장 실패 -> 디스크 파일 롤백하여 고아 파일 방지
            throw e;                     // 예외 전파
        }

    }

    /* 이미지 파일 서빙 핵심 비즈니스 로직
    *   - 컨트롤러는 요청/응답 처리만, 서비스는 DB 조회, 파일 읽기, MediaType 결정 일괄 담당
    * */
    public BookImageResourceDTO getImageResource(Long imageId, String uploadPath) throws IOException {
        // DB에서 이미지 메타데이터 조회
        BookImage bookImage = bookImageRepository.findById(imageId)
                .orElseThrow(() -> new BookImageNotFoundException(imageId));

        // 도서별 전용 디렉토리에서 실제 파일 경로 조회
        Path imagePath = ImageUtil.getFileAsResource(uploadPath,
                bookImage.getBook().getId(), bookImage.getFileName());

        // 파일 경로의 이미지를 바이트 배열로 읽기 --> HTTP 응답 body에 직접 실음
        byte[] imageBytes = Files.readAllBytes(imagePath);

        // 파일 확장자 기반으로 HTTP Content-Type(MediaType) 결정 --> 브라우저가 이미지를 올바르게 랜더링하도록
        MediaType mediaType = resolveMediaType(bookImage.getFileName());

        // 바이트 배열 +  mediaType를 DTO로 묶어 반환
        return new BookImageResourceDTO(imageBytes, mediaType);
    }

    // 파일명의 확장자를 추출하여 적절한 HTTP Content-Type(MediaType)으로 변환
    // 브라우저는 Content-Type이 없거나 틀리면 이미지 랜더링하지 못하고 다운로드로 처리할 수 있음
    private MediaType resolveMediaType(String fileName) {
        String extension = "";
        int lastDotIndex = fileName.lastIndexOf('.');
        if (lastDotIndex > 0 && lastDotIndex < fileName.length() - 1) {
            extension = fileName.substring(lastDotIndex + 1).toLowerCase(); // 확장자 소문자 통일
        }
        return switch(extension) {
            case "png"          -> MediaType.IMAGE_PNG;  // .png -> image/png
            case "jpg", "jpeg"  -> MediaType.IMAGE_JPEG; // .jpg / .jpeg -> image/jpeg
            case "gif"          -> MediaType.IMAGE_GIF;  // .git -> image/gif
            default             -> MediaType.APPLICATION_OCTET_STREAM; // 알수 없는 확장자 -> application/octat-stream (브라우저가 다운로드 처리)
        };

    }

}
