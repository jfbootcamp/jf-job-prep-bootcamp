package com.example.springstarter.util;

import org.imgscalr.Scalr;
import org.springframework.web.multipart.MultipartFile;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class ImageUtil {

    // 도서 ID 기반 업로드 디렉토리를 생성하고 파일의 최종 절대 경로를 반환
    public static String makePath(String uploadPath, String fileName, Long book_id) throws IOException {
        String path = uploadPath+book_id;   // 업로드 기본 경로 + bookId 조합 -> 도서별 전용 디렉토리 경로 생성 (예: /uploads/2)
        Files.createDirectories(Paths.get(path));  // 해당 경로의 디렉토리가 없으면 자동 생성 (이미 존재하면 무시)
        return new File(path).getAbsolutePath() + "\\" + fileName;  // 디렉토리 절대 경로 + 파일명 조합 -> 최종 파일 저장 위치 반환 (예: /uploads/2/abc.jpg)
    }

    // 업로드된 원본 이미지를 지정한 width 기준으로 리사이즈하여 썸네일 BufferedImage 반환
    public static BufferedImage getThumbnail(MultipartFile originFile, Integer width) throws IOException {
        BufferedImage img =  // MultipartFile의 바이트 스트림을 읽어 Java가 처리할수 있는 BufferedImage 객체로 변환
                ImageIO.read(originFile.getInputStream());
        BufferedImage thumbImg = Scalr.resize(img,   // 원본 이미지를 Scalr 라이브러리로 리사이즈
                    Scalr.Method.AUTOMATIC,  // 품질과 속도를 자동으로 최적 선택
                    Scalr.Mode.AUTOMATIC,    // 가로/세로 비율을 유지하며 width 기준으로 자동 축소
                    width,                   // 리사이즈 기준 너비
                    Scalr.OP_ANTIALIAS);     // 안티엘리어싱 적용 -> 축소 시 계단 현상 방지, 이미지 품질 향상
        return thumbImg;
    }

    // 도서 ID와 파일명으로 저장된 이미지 파일의 Path를 반환 (파일이 없으면 IOException 발생)
    public static Path getFileAsResource(String uploadPath, Long book_id, String file_name) throws IOException {
        String location = uploadPath + book_id + "\\" + file_name;  //업로드 기본 경로 + bookId +파일명 조합 -> 실제 파일의 전체 경로 문자열 구성
        File file = new File(location);     //경로 문자열을 File 객체로 변환 (파일 시스템 조작 메서드 사용을 위해)
        if (file.exists()) {
            return Paths.get(file.getAbsolutePath());   // file의 절대 경로를 Path 객체로 반환
        } else {
            throw new IOException("이미지 파일이 디스크에 존재하지 않습니다.: " + location);
        }

    }

}
