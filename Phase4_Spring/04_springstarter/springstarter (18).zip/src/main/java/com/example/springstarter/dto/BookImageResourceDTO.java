package com.example.springstarter.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Getter;
import org.springframework.http.MediaType;

/*
    이미지 서빙용 응답 데이터 전달 객체
        - 서비스가 컨트롤러에 이미지 데이터를 넘길때 사용
            - data : 디스크에서 읽어온 이미지 파일의 바이트 배열 (HTTP 응답 body)
            - mediaType : 파일 확장자 기반으로 결정된 Content-Type (브라우저가 올바르게 이미지를 랜더링하도록)
        - DTO 사용하는 이유
            - 서비스 : 파일 조회 + 바이트 읽기 + MediaType 결정
            - 컨트롤러 : DTO를 받아 ResponseEntity로 포함하여 응답 반환
 */
@Schema(description = "이미지 서빙용 내부 전달 객체 - 서비스가 컨트롤러에 이미지 바이트와 Content-Type을 함께 전달하기 사용")
@Getter
@AllArgsConstructor
public class BookImageResourceDTO {

    @Schema(description = "디스크에서 읽어온 이미지 파일 바이트 배열 -> HTTP 응답 Body 직접 실어 브라우저에 전달",
            type = "string", format = "binary")
    private final byte[] data;

    @Schema(description = "파일 확장자 기반으로 결정된 Content-type (IMAGE_PNG / IMAGE_JPEG / IMAGE_GIF / IMAGE_JPG) -> 브라우저가 이미지를 올라르게 랜더링하도록 응답 헤더에 설정",
            example = "image/jpeg")
    private final MediaType mediaType;

}
