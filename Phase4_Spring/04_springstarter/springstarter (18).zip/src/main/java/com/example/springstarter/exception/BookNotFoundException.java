package com.example.springstarter.exception;

public class BookNotFoundException extends RuntimeException {
    // 예외 발생 시 "존재하지 않는 도서 ID" 메시지를 부모 생성자에 전달
    public BookNotFoundException(Long id) {
        super("존재하지 않는 도서입니다. id: " + id);
    }
}
