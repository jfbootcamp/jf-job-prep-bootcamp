package com.example.springstarter.exception;

import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.util.HashMap;
import java.util.Map;

/*
*   전역 예외 처리 클래스
*   @RestControllerAdvice
*       - 모든 @Controller / @RestController에 자동 적용되는 전역 예외 처리기
*       - 각 컨트롤러에서 try~catch 없이 예외가 발생하면 Spring이 자동으로 이 클래스로 라우팅함
* */
@Slf4j
@RestControllerAdvice
public class GlobalExceptionHandler {

    // @Valid 유효성 검사 실패 시 Spring이 MethodArgumentNotValidException 자동 발생 --> 이 핸들러로 라우팅
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<Map<String, String>>
                handleValidationException(MethodArgumentNotValidException e) {
        Map<String, String> errors = new HashMap<>();
        e.getBindingResult().getFieldErrors().forEach(error
                -> errors.put(error.getField(), error.getDefaultMessage()));
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errors);
            // 400 + 필드별 오류 메시지 JSON
    }

    // 존재하지 않는 도서 ID 조회 시 --> 이 핸들러로 라우팅
    @ExceptionHandler(BookNotFoundException.class)
    public ResponseEntity<Map<String, String>>
              handleBookNotFoundException(BookNotFoundException e) {
        Map<String, String> error = new HashMap<>();
        error.put("message", e.getMessage());
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(error);
        // 404 + 도서 미존재 오류 메시지 JSON
    }

    // 존재하지 않는 이미지 ID 조회 시 BookImageService -> orElseThrow()에서 발생 -> 이 핸들러 라우팅
    @ExceptionHandler(BookImageNotFoundException.class)
    public ResponseEntity<Map<String, String>> handleBookImageNotFoundException(BookImageNotFoundException e) {
        Map<String, String> error = new HashMap<>();
        error.put("message", e.getMessage());
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(error);
            // 404 + 이미지 미존재 오류 메시지 JSON
    }

    // 위 핸들러들에서 잡히지 않은 모든 예외의 최종 처리
    @ExceptionHandler(Exception.class)
    public ResponseEntity<Map<String, String>> handleGeneralException(Exception e) {
        log.error("서버 내부 오류: {}", e.getMessage(), e);
        Map<String, String> error = new HashMap<>();
        error.put("message", "서버 내부 오류가 발생했습니다.");
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(error); // 500 + 공통 오류 메시지 JSON
    }
}
