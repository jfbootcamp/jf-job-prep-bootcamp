package com.example.springstarter.repository;

import com.example.springstarter.entity.Book;
import com.example.springstarter.entity.BookImage;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface BookImageRepository extends JpaRepository<BookImage, Long> {

    // 특정 도서에 등록된 이미지 수 조회 (도서당 최대 이미지 수 제한 검증에 사용)
    // Spring Data JPA 메서드 네이밍 규칙으로 자동 구현
    long countByBook(Book book);  // SELECT COUNT(*) FROM book_image where book_id = ?
}
