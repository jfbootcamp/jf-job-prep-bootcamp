package com.example.springstarter.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.*;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class BookRequestDTO {

    @NotBlank        // 공백 및 빈 문자열 허용 안함
    @Schema(description = "책 제목", example = "랭체인으로 구현하는 AI 서비스 & 에이전트 개발 입문",
            requiredMode = Schema.RequiredMode.REQUIRED)  // Swagger UI 문서에 노출될 필드 설명과 예시값
    private String subject;

    @NotNull        // null 허용 안 함
    private Integer price;

    @NotBlank
    private String author;

    @NotNull
    private Integer page;

}
