package com.example.springstarter.config;

import com.example.springstarter.entity.Book;
import com.example.springstarter.entity.Review;
import com.example.springstarter.service.BookService;
import com.example.springstarter.service.ReviewService;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.List;

/*
     * InitDataConfig - 애플리케이션 시작 시 초기 데이터를 삽입하는 설정 클래스

     * CommandLineRunner
        - Spring Boot가 제공하는 인터페이스
        - 애플리케이션이 완전히 구동된 직후 (모든 Bean 생성 완료 후) 딱 한 번 실행됨
        - 실행 시점
            - Spring Container 초기화 (Bean 생성, 의존성 주입)
            - 내장 톰캣 시작
        - 왜 사용하는가?
            - 개발 / 테스트 환경에서 초기 샘플 데이터를 자동으로 넣어주기 역할
            - data.sql 대신 Java 코드로 초기 데이터를 삽입하면
              Service 계층의 로직(검증, 변환 등)을 그대로 활용할 수 있음.
            - 조건부 삽입 (이미 데이터가 있으면 건너뛰기)도 쉽게 구현 가능

     * 실무에서 활용 예
        - 관리자 계정 초기 생성 (admin 계정이 없으면 자동 생성)
        - 코드 테이블 초기화 (카테고리, 상태값 등 기초 데이터)

 */
@Component // 이 클래스를 Spring Bean으로 등록, Spring이 이 Bean이  CommandLineRunner를 구현한것을 감지 --> 구동 완료후 run() 메서드 호출함
@RequiredArgsConstructor
public class InitDataConfig implements CommandLineRunner {

    private final BookService bookService;
    private final ReviewService reviewService;

    /*
       애플리케이션 구동 완료 직후 자동 실행되는 메서드
         1) DB에서 전체 도서 목록을 조회
         2) 데이터가 하나도 없으면(isEmpty) --> 샘플 2건 삽입
         3) 데이터가 이미 있으면 --> 아무것도 하지 않음 (중복 방지)

     */
    @Override
    public void run(String... args) throws Exception {
        // 1. Book 초기 데이터 삽입 (Book 테이블이 비어있을 때만)
        List<Book> books = bookService.getAll();

        Book book1;
        Book book2;

        if (books.isEmpty()) {
            book1 = new Book();
            book1.setSubject("자바");
            book1.setPrice(30000);
            book1.setAuthor("이순신");
            book1.setPage(600);
            bookService.save(book1);

            book2 = new Book();
            book2.setSubject("파이썬");
            book2.setPrice(37000);
            book2.setAuthor("류성룡");
            book2.setPage(800);
            bookService.save(book2);
        } else {
            book1 = books.get(0);       // 첫 번째 책을 book1에 할당
            // 책이 2권 이상이면 두 번째 책, 아니면 첫 번째 책을 재사용
            book2 = books.size() > 1 ? books.get(1) : books.get(0);
        }

        // 2. Review 초기 데이터 삽입 (Review 테이블이 비어있을 때만)
        // Book과 별도로 체크하여, Book만 있고 Review가 없는 경우에 삽입됨
        if (reviewService.count() == 0) {
            Review review01 = new Review();
            review01.setContent("자세하고 쉽게 되어 있어요");
            review01.setRating(4);
            review01.setCreatedAt(LocalDateTime.now());
            review01.setBook(book1);
            reviewService.save(review01);

            Review review02 = new Review();
            review02.setContent("그림으로 이해하기 쉽게 설명이 잘 되어 있네요");
            review02.setRating(5);
            review02.setCreatedAt(LocalDateTime.now());
            review02.setBook(book2);
            reviewService.save(review02);

            Review review03 = new Review();
            review03.setContent("쉽게 설명이 잘 되어 있네요");
            review03.setRating(5);
            review03.setCreatedAt(LocalDateTime.now());
            review03.setBook(book2);
            reviewService.save(review03);

            Review review04 = new Review();
            review04.setContent("에이전트의 진수를 맛보았습니다. 감사합니다.");
            review04.setRating(5);
            review04.setCreatedAt(LocalDateTime.now());
            review04.setBook(book2);
            reviewService.save(review04);

            Review review05 = new Review();
            review05.setContent("초보자에게는 다소 어렵게 느껴집니다. 잘 보았습니다.");
            review05.setRating(3);
            review05.setCreatedAt(LocalDateTime.now());
            review05.setBook(book2);
            reviewService.save(review05);
        }
    }
}





















