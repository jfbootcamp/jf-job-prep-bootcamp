package com.example.springstarter.controller;

/*
    React 전용 JSON API 컨트롤러
        - BookController (@Controller)  -> Thymeleaf HTML 반환
        - BookApiController (@RestController) -> JSON 반환
            - /api/books    -> JSON (React fetch 대상)
 */

import com.example.springstarter.dto.BookViewDTO;
import com.example.springstarter.service.BookImageService;
import com.example.springstarter.service.BookService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping("/api/books")
public class BookApiController {
    private final BookService bookService;
    private final BookImageService bookImageService;

    // 전체 도서 목록 조회
    @GetMapping
    public ResponseEntity<List<BookViewDTO>> getBookList() {
        List<BookViewDTO> books = bookService.getAll()
                .stream()
                .map(book -> new BookViewDTO(
                        book.getId(),
                        book.getSubject(),
                        book.getPrice(),
                        book.getAuthor(),
                        book.getPage(),
                        book.getCreatedAt()
                ))
                .collect(Collectors.toList());
        return ResponseEntity.ok(books);    // 200 ok + body : List<BookViewDTO> -> JSON 배열
    }
}
