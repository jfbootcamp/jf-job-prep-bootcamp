package com.example.springstarter.exception;

public class BookImageNotFoundException extends RuntimeException {
    public BookImageNotFoundException(Long id) {
        super("존재하지 않는 이미지입니다. id: " + id);
    }
}
