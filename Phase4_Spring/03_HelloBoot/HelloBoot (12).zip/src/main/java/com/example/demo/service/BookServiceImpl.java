package com.example.demo.service;

import com.example.demo.entity.Book;
import com.example.demo.repository.BookRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

/*
    BookServiceImpl - BookServie 인터페이스의 구현체

    JpaRepository가 제공하는 기본 메서드를 활용:
        - findAll()               -> SELECT * FROM book
        - save(entity)            -> INSERT 또는 UPDATE  (id 유무에 따라 자동 판단)
 */
@Service
@RequiredArgsConstructor
public class BookServiceImpl implements BookService{

    private final BookRepository bookRepository;

    @Override
    public List<Book> bookList() {
        return bookRepository.findAll();
    }

    // 도서 등록/수정
    @Override
    public void bookSave(Book book) {
        bookRepository.save(book);
    }

    // 도서 1건 상세 조회
    /*
        findById()는 Optional<Book>를 반환하므로
        .orElse(null)로 값이 없으면 null 반환
     */
    @Override
    public Book bookDetail(Long id) {
        return bookRepository.findById(id).orElse(null);
    }

    @Override
    public void bookDelete(Long id) {
        bookRepository.deleteById(id);
    }
}
