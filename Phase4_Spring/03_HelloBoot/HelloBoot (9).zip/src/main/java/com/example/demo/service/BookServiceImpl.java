package com.example.demo.service;

public class BookServiceImpl implements BookService{
}
