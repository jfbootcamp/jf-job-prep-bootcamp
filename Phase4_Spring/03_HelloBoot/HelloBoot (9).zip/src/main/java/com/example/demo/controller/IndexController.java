package com.example.demo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

/*
    IndexController - 메인 페이지(대시보드) 요청을 처리하는 컨트롤러
        [역할]
            루트 URL(/)로 접속하면 메인 허브 페이지(index.html)를 보여줌
            메인 페이지에서 회원 관리, 도서 관리 등 각 도메인으로 이동할 수 있음
        [URL 설계]
            GET /  --> 메인 페이지 (index.html)

 */
@Controller
public class IndexController {

    @GetMapping("/")
    public String index() {
        return "index";     // --> templates/index.html 랜더링
    }
}
