package com.example.demo.controller;

import com.example.demo.entity.Member;
import com.example.demo.service.HomeServiceImpl;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@Controller
@RequiredArgsConstructor
public class HomeController {

    private final HomeServiceImpl homeService;

    @GetMapping("/home")
    public String home(Model model) {
        return "home";
    }

    @GetMapping("/memberList")
    public String memberList(Model model) {
        List<Member> members = homeService.memberList();
        model.addAttribute("members", members);
        return "memberList";
    }
}
