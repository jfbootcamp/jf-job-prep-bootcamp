package com.example.demo.service;

import com.example.demo.entity.Member;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class HomeServiceImpl implements HomeService{
    @Override
    public List<Member> memberList() {
        return List.of();
    }
}
