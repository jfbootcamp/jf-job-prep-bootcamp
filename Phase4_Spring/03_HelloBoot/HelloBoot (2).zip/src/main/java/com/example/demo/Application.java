package com.example.demo;		// 애플리케이션 기본(루트) 패키지

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Application {	//main() 있는 클래스는 반드시 루트 패키지에 존재함

	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
	}

}
