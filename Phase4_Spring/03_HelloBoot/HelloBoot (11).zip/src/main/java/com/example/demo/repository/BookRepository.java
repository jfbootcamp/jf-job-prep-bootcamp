package com.example.demo.repository;

import com.example.demo.entity.Book;
import org.springframework.data.jpa.repository.JpaRepository;

/*
    BookRepository - Book 엔티티의 데이터 접근 (CRUD)을 담당하는 인터페이스
    JpaRepository<Book, Long>을 상속하면 별도 구현 없이 아래 메서드들이 자동으로 제공함
        - findAll()     : 전체 도서 목록 조회
        - findById(id)  : ID로 도서 1건 조회
        - save(book)    : 도서 저장 (INSERT 또는 UPDATE)
        - deleteById(id) : ID로 도서 삭제
        - count()        : 전체 도서 수 조회


 */
public interface BookRepository extends JpaRepository<Book, Long> {
    // JpaRepository가 기본 CRUD를 모두 제공하므로
    // 추가 메서드가 필요 없으면 비워두면 됨.
}
