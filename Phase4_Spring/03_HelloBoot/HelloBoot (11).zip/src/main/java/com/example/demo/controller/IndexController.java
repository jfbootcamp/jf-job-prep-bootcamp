package com.example.demo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

/*
    메인 페이지 (대시보드 / 허브 페이지)
    GET /

    IndexController - 메인 페이지(대시보드) 요청을 처리하는 컨트롤러
        [역할]
            루트 URL(/)로 접속하면 메인 허브 페이지(index.html)를 보여줌
            메인 페이지에서 회원 관리, 도서 관리 등 각 도메인으로 이동할 수 있음
        [URL 설계]
            GET /  --> 메인 페이지 (index.html)
        [동작 흐름]
            1) 사용자가 브라우저에서 http://localhost:8080/ 접속
            2) DispatcherServlet이 GET "/" 요청을  이 index() 메서드로 라우팅
            3) return "index" --> Thymeleaf ViewResolver 동작 :
                prefix(classpath: /templates/) +"index" + suffix(.html)
                --> templates/index.html 을 찾아 랜더링
            4) index.html 안의 카드(링크)를 클릭하면 각 도메인 페이지로 이동
                - 회원 관리 카드 --> /memeber/list (MemberController)
                - 도서 관리 카드 --> /book/list (BookController)


 */
@Controller
public class IndexController {

    @GetMapping("/")
    public String index() {
        return "index";     // --> templates/index.html 랜더링
    }
}
