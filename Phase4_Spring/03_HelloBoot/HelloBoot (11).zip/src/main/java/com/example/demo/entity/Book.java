package com.example.demo.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.Data;

/*
    Book 엔티티 - 도서 정보를 저장하는 테이블과 매핑되는 클래스
    Hibernate가 이 클래스를 보고 자동으로 'book' 테이블을 생성함
 */
@Entity     // JPA가 이 클래스를 DB 테이블과 매핑하도록 지정
@Data       // Lombok: getter, setter, toString, equals, hashCode 자동 생성
public class Book {

    @Id     // 이 필드가 테이블의 기본키(PK)임을 지정
    @GeneratedValue(strategy = GenerationType.IDENTITY) // MySQL의 AUTO_INCREMENT 사용
    private Long id;
    private String title;
    private String author;
    private String publisher;
    private int price;
    private String isbn;
}
