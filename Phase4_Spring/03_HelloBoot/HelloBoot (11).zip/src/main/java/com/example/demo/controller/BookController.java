package com.example.demo.controller;

import com.example.demo.entity.Book;
import com.example.demo.service.BookServiceImpl;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;

/*
    BookController - 도서 관련 CRUD 요청을 처리하는 컨트롤러

        URL 설계 (RESTful 스타일)
            GET /book/list          -> 도서목록

        public BookController(BookServiceImpl bookService) {
            this.bookService = bookService;
        }
 */
@Controller
@RequestMapping("/book")        // 이 컨트롤러의 모든 URL에 /book 접두사 적용
@RequiredArgsConstructor
public class BookController {

    private final BookServiceImpl bookService;

    /*
        도서 목록 페이지 (Read - 전체 조회)
        GET /book/list
     */
    @GetMapping("/list")
    public String bookList(Model model) {
        List<Book> books = bookService.bookList();
        model.addAttribute("books", books);
        return "book/bookList";     // templates/book/bookList.html
    }

    /*
        도서 등록 폼 (Create - 빈 폼 표시)
        GET /book/form
     */
    @GetMapping("/form")
    public String bookForm(Model model) {
        model.addAttribute("book", new Book());
        return "book/bookForm";     // templates/book/bookForm.html
    }

    /*
        도서 등록 / 수정 처리 (Create & Update)
        POST    /book/save

        PRG 패턴 (Post-Redirect-Get)  : 새로고침시 중복 등록 방지
     */
    @PostMapping("/save")
    public String bookSave(Book book) {
        bookService.bookSave(book);
        return "redirect:/book/list";
    }

    /*
        도서 상세보기 (Read - 1건 조회)
        GET /book/detail/{id}
     */
    @GetMapping("/detail/{id}")
    public String bookDetail(@PathVariable Long id, Model model) {
        Book book = bookService.bookDetail(id);
        model.addAttribute("book", book);
        return "book/bookDetail";       // templates/book/bookDetail.html
    }
}



















