package com.example.demo.service;

import com.example.demo.entity.Book;

import java.util.List;

/*
    BookService - 도서 관련 비즈니스 로직 인터페이스
        CRUD 4가지 기능
            - Create : bookSave()       --> 도서등록
            - Read :  bookList()        --> 전체 목록 조회
                      bookDetail()      --> 도서 1권 상세 조회
            - Update : bookSave()       --> 도서 수정 (등록과 동일 메서드 사용)
            - Delete : bookDelete()     --> 도서 삭제
 */
public interface BookService {
    List<Book> bookList();
    void bookSave(Book book);   // 도서 등록/수정 (id가 없으면 INSERT, 있으면 UPDATE)
    Book bookDetail(Long id);   // 도서 1건 상세 조회 (ID로 검색)
}














