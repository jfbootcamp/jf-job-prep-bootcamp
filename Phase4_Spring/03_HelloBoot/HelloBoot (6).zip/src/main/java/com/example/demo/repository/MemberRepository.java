package com.example.demo.repository;

import com.example.demo.entity.Member;
import org.springframework.data.jpa.repository.JpaRepository;

/*
    MemberRepository - Member 엔티티의 데이터 접근(CRUD)을 담당하는 인터페이스

    JpaRepository<Member, Long>을 상속하면 별도 구현 없이 메서들이 자동으로 제공됨
        - findAll()     : 전체 회원 목록 조회
        - findById(id)  : ID로 회원 1건 조회

 */
public interface MemberRepository extends JpaRepository<Member, Long> {
    // JpaRepository가 기본 CRUD를 모두 제공하므로
    // 추가 메서드가 필요 없으면 비워두면 됨
}
