package com.example.demo.service;

/*
    MemberService - 회원(Member) 관련 비즈니스 로직 인터페이스

    CRUD 4가지 기능
        - Read : memberList() -> 전체 목록 조회
                 memberDetail() -> 회원 1건 상세 조회

    엔티티별로 Service를 분리하면:
        1) 클래스의 책임이 명확해짐 (단일 책임 원칙, SRP)
        2) 팀 프로젝트에서 충돌 없이 각자 담당 기능을 개발 가능
        3) 나중에 회원 관련 비즈니스 로직이 추가되어도 이 파일만 수정
 */

import com.example.demo.entity.Member;

import java.util.List;

public interface MemberService {
    List<Member> memberList();       // 전체 회원 목록 조회
    Member memberDetail(Long id);    // 회원 1건 상세 조회 (ID로 검색)
}
