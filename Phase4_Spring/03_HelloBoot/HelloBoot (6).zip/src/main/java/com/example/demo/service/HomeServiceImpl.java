package com.example.demo.service;

import com.example.demo.entity.Member;
import com.example.demo.repository.HomeRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class HomeServiceImpl implements HomeService{

    private final HomeRepository homeRepository;

    @Override
    public List<Member> memberList() {
        return homeRepository.findAll();
    }
}
