package com.example.demo.controller;

import com.example.demo.entity.Member;
import com.example.demo.service.HomeServiceImpl;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import java.util.List;

/*
    HomeController - 공통 페이지 요청을 처리하는 컨트롤러

    역할 분리 원칙 (Single Responsibility Principle) :
        - HomeController : 공통 페이지 (홈, 메인 등)
        - MemberController : 회원 관련 기능
        - BookController : 도서 관련 기능
        --> 각 컨트롤러가 하나의 도메인(업무 영역)만 담당
 */

@Controller
public class HomeController {

    @GetMapping("/home")
    public String home(Model model) {
        return "home";
    }


}
