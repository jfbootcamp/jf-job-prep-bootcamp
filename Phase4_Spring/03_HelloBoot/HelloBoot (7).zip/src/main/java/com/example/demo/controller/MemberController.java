package com.example.demo.controller;

import com.example.demo.entity.Member;
import com.example.demo.service.HomeServiceImpl;
import com.example.demo.service.MemberServiceImpl;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;

/*
    MemberController - 회원 관련 CRUD 요청을 처리하는 컨트롤러

    * URL 설계 (RESTful 스타일)
        GET     /member/list            --> 회원 목록
        GET     /member/detail/{id}     --> 회원 상세보기
        GET     /member/form            --> 회원 등록 폼
        GET     /member/form/{id}       --> 회원 수정 폼
        POST    /member/save            --> 회원 등록/수정 처리
        GET     /member/delete/{id}     --> 회원 삭제 처리
 */
/*
    회원 목록 페이지
        GET /member/list

        Thymeleaf View Resolver
            - 리턴값 앞뒤에 자동으로 prefix/suffix를 붙여줌
                - prefix:  classpath:/templates/
                - suffix:  .html
                --> templates/ + member/memberList
            - classpath:/
                - Java의 클래스패스 루트를 의미함
                    - src/main/resources 디렉토리가 클래스패스 루트에 해당됨
                - 따라서
                    - classpath:/templates/ = src/main/resources/templates/
 */

@Controller
@RequestMapping("/member")          /* 이 컨트롤러의 모든 URL에 /member 접두사 적용 */
@RequiredArgsConstructor
public class MemberController {
    private final MemberServiceImpl memberService;

    @GetMapping("/list")
    public String memberList(Model model) {
        List<Member> members = memberService.memberList();
        model.addAttribute("members", members);
        return "member/memberList";
    }

    /*
        회원 상세보기 (Read - 1건 조회)
        GET     /member/detail/{id}

        @PathVariable : URL 경로의 {id} 값을 매개변수로 받음
            예) /member/detail/3  --> id = 3

        return "member/memberDetail"
            -> View Resolver ->   templates/member/memberDetail.html 랜더링
     */
    @GetMapping("/detail/{id}")
    public String memberDetail(@PathVariable Long id, Model model) {
        Member member = memberService.memberDetail(id);
        model.addAttribute("member", member);
        return "member/memberDetail";
    }

    /*
        회원 등록 폼 (Create - 빈 폼 표시)
        GET /member/form

        빈 Member 객체를 Model 담아 보냄
        --> Thymeleaf의 th:object에서 폼 바인딩에 사용됨
     */

    @GetMapping("/form")
    public String memberForm(Model model) {
        model.addAttribute("member", new Member());
        return "member/memberForm";
    }
}













