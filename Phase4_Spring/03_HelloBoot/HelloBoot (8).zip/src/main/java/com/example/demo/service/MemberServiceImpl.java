package com.example.demo.service;

import com.example.demo.entity.Member;
import com.example.demo.repository.HomeRepository;
import com.example.demo.repository.MemberRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

/*
    MemberServiceImpl - MemberService 인터페이스의 구현체

    JpaRepository가 제공하는 기본 메서드를 활용
        - findAll()         --> SELECT * FROM member
        - findById(id)      --> SELECT * FROM member WHERE id = ?

 */

@Service
@RequiredArgsConstructor
public class MemberServiceImpl implements MemberService {

    private final MemberRepository memberRepository;

    @Override
    public List<Member> memberList() {          // 전체 회원 목록 조회
        return memberRepository.findAll();
    }

    /*
        회원 1건 상세 조회
            findById(id)는 Optional<Member>을 반환하므로
            .orElse(null)로 값이 없으면 null 반환
     */
    @Override
    public Member memberDetail(Long id) {
        return memberRepository.findById(id).orElse(null);
    }

    /*
        회원 등록/수정
            - entity의 id가 null -> INSERT (신규 등록)
            - entity의 id가 존재 -> UPDATE (기존 데이터 수정)
            즉, 하나의 메서드로 등록과 수정을 모두 처리!
     */
    @Override
    public void memberSave(Member member) {
        memberRepository.save(member);
    }

    // 회원 삭제
    @Override
    public void memberDelete(Long id) {
        memberRepository.deleteById(id);
    }
}
