package com.example.demo.controller;

import com.example.demo.entity.Member;
import com.example.demo.service.HomeServiceImpl;
import com.example.demo.service.MemberServiceImpl;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;

/*
    MemberController - 회원 관련 CRUD 요청을 처리하는 컨트롤러

    * URL 설계 (RESTful 스타일)
        GET     /member/list            --> 회원 목록
        GET     /member/detail/{id}     --> 회원 상세보기
        GET     /member/form            --> 회원 등록 폼
        GET     /member/form/{id}       --> 회원 수정 폼
        POST    /member/save            --> 회원 등록/수정 처리
        GET     /member/delete/{id}     --> 회원 삭제 처리
 */
/*
    회원 목록 페이지
        GET /member/list

        Thymeleaf View Resolver
            - 리턴값 앞뒤에 자동으로 prefix/suffix를 붙여줌
                - prefix:  classpath:/templates/
                - suffix:  .html
                --> templates/ + member/memberList
            - classpath:/
                - Java의 클래스패스 루트를 의미함
                    - src/main/resources 디렉토리가 클래스패스 루트에 해당됨
                - 따라서
                    - classpath:/templates/ = src/main/resources/templates/
 */

@Controller
@RequestMapping("/member")          /* 이 컨트롤러의 모든 URL에 /member 접두사 적용 */
@RequiredArgsConstructor
public class MemberController {
    private final MemberServiceImpl memberService;

    @GetMapping("/list")
    public String memberList(Model model) {
        List<Member> members = memberService.memberList();
        model.addAttribute("members", members);
        return "member/memberList";
    }

    /*
        회원 상세보기 (Read - 1건 조회)
        GET     /member/detail/{id}

        @PathVariable : URL 경로의 {id} 값을 매개변수로 받음
            예) /member/detail/3  --> id = 3

        return "member/memberDetail"
            -> View Resolver ->   templates/member/memberDetail.html 랜더링
     */
    @GetMapping("/detail/{id}")
    public String memberDetail(@PathVariable Long id, Model model) {
        Member member = memberService.memberDetail(id);
        model.addAttribute("member", member);
        return "member/memberDetail";
    }

    /*
        회원 등록 폼 (Create - 빈 폼 표시)
        GET /member/form

        빈 Member 객체를 Model 담아 보냄
        --> Thymeleaf의 th:object에서 폼 바인딩에 사용됨
     */

    @GetMapping("/form")
    public String memberForm(Model model) {
        model.addAttribute("member", new Member());
        return "member/memberForm";
    }

    /*
        회원 수정 폼 (Update - 기존 데이터가 채워진 폼 표시)
        GET  /member/form/{id}

        DB에서 기존 회원 정보를 조회하여 폼에 채워줌
        등록 폼과 동일한 memberDetail.html을 사용 (id 유무로 등록/수정 구분)

        return "member/meberForm"
            --> View Resolver --> templates/member/meberForm.html 랜더링
     */
    @GetMapping("/form/{id}")
    public String memberEditForm(@PathVariable Long id, Model model) {
        Member member = memberService.memberDetail(id);
        model.addAttribute("member", member);
        return "member/memberForm";
    }

    /*
        회원 등록/수정 처리 (Create & Update)
        POST /member/save

        Thymeleaf 폼에서 전송된 Member 객체를 받아 DB에 저장
            - member.id가 null -> INSERT (신규 등록)
            - member.id가 존재 -> UPDATE (기존 데이터 수정)

        return "redirect:/member/list"
            -> "redirect:" 접두사는 View Resolver가 아닌 리다이렉터 처리
            -> 브라우저가 GET /member/list 로 새로운 요청을 보냄
            -> PRG 패턴 (Post-Redirect-Get) : 새로고침 시 중복 등록 방지
     */
    @PostMapping("/save")
    public String memberSave(Member member) {
        memberService.memberSave(member);
        return "redirect:/member/list";
    }

    /*
        회원 삭제 처리 (Delete)
        GET /member/delete/{id}

        삭제 후 목록 페이지로 리다이렉트

        return "redirect:/member/list"
            -> "redirect:" 접두사이므로 View Resolver를 거치지 않고
               브라우저에게 GET /member/list 로 재요청하도록 응답 (302 Redirect)
     */
    @GetMapping("/delete/{id}")
    public String memberDelete(@PathVariable Long id) {
        memberService.memberDelete(id);
        return "redirect:/member/list";
    }
}













