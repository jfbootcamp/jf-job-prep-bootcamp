package com.example.mybatis.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

/*
   @Controller : 이 클래스가 Spring MVC의 "컨트롤러"임을 선언
   브라우저의 요청(URL)을 받아서 처리하는 역할
   Spring이 서버 시작 시 어노테이션을 보고 자동으로 객체를 생성해서 관리함 (= Bean 등록)
 */
@Controller
public class BookController {
    @GetMapping("/")
    public String index(Model model) {
        model.addAttribute("hello", "Hello JSP, Mybatis");
        return "index";
    }
}
