<%@ page contentType="text/html;charset=UTF-8" language="java" %>

<%-- JSTL 태그 라이브러리 선언 --%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>

<%-- contextPath: 애플리케이션의 기본 경로 --%>
<%-- 링크나 form action에서 경로를 쓸 때 ${contextPath}/bookList 처럼 사용 --%>
<%-- 이렇게 하면 서버 배포 경로가 바뀌어도 코드 수정이 필요 없음 --%>
<c:set var="contextPath"  value="${pageContext.request.contextPath}"/>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>JSP Template with Bootstrap and JSTL</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">        <!--외부 스타일시트 연결 -->
</head>
<body>

<div class="container mt-4">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    Single Card
                </div>
            </div>
        </div>
    </div
</div>

</body>
</html>







