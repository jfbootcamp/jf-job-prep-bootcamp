package com.example.mybatis.repository;

import com.example.mybatis.entity.Book;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface BookMapper {

    // 모든 책 목록을 조회하는 메서드
    public List<Book> findAll();

    // 특정 책 1권을 ID로 조회하는 메서드
    public  Book findById(Long id);

    // 파라미터 : Book book --> 수정할 내용이 담긴 객체 (id 포함)
    // 반환타입 : void
    public void update(Book book);

    // [C] insert : 새로운 책을 DB에 저장하는 메서드
    // 파라미터: Book book --> 저장할 책의 정보가 담긴 객체
    // 반환미터: void (저장만 하고 돌려줄 값이 없음)
    public void insert(Book book);

    // [D] deleteById: 특정 책을 삭제하는 메서드
    // 파라미터 : Long id --> 삭제할 책의 고유 번호
    // 반환타입 : void
    public void deleteById(Long id);
}

















