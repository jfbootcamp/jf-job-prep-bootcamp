package com.example.mybatis.config;

import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.SqlSessionTemplate;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;

import javax.sql.DataSource;

/*
    MyBatis 설정 클래스

        - 이 클래스 역할
            - application.yaml에 적어둔 DB 연결 정보(datasource)를 바탕으로
              Mabatis가 실제로 DB와 통신할 수 있도록 "다리"를 놓아주는 설정임.

        -    [application.yaml]   ----->   [MyBatisConfig]  ------> [Mapper]
                                             DataSource(자동)           .java
                                                                        .xml
                                             SqlSessionFactory

                                             SqlSessionTemplate

 */

@Configuration      // Spring에게 "이 클래스는 설정 파일이야"라고 알려주는 어노테이션
@MapperScan(basePackages = "com.example.mybatis.repository") // 이 패키지 안에 있는 Mapper 인터페이스들을 자동으로 찾아서 빈으로 등록함
public class MyBatisConfig {

    @Bean
    public SqlSessionFactory sqlSessionFactory(DataSource dataSource) throws Exception {
        SqlSessionFactoryBean sessionFactory = new SqlSessionFactoryBean();
        // DataSource를 SqlSessionFactory에 셋팅
        // --> Mybatis가 SQL을 실행할 때 이 DataSource에서 DB 커넥션을 가져옴
        sessionFactory.setDataSource(dataSource);

        sessionFactory.setMapperLocations(
                new PathMatchingResourcePatternResolver().getResources("classpath:mapper/*.xml"));

        /*
            MyBatis 설정 : 스테이크 케이스 --> 카멜 케이스 자동 변환
            실무 관계 : DB 컬럼명은 스네이크 케이스(created_at)를 사용하고
                       Java 필드는 카멜 케이스 (createdAt)를 사용함.
         */
        org.apache.ibatis.session.Configuration configuration = new org.apache.ibatis.session.Configuration();
        configuration.setMapUnderscoreToCamelCase(true);
        sessionFactory.setConfiguration(configuration);
        // SqlSessionFactory 객체를 생셩하여 반환함
        return sessionFactory.getObject();
    }

    @Bean
    public SqlSessionTemplate sqlSessionTemplate(SqlSessionFactory sqlSessionFactory) {
        return new SqlSessionTemplate(sqlSessionFactory);
    }

}























