package com.example.mybatis.controller;

import com.example.mybatis.entity.Book;
import com.example.mybatis.service.BookService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.ArrayList;
import java.util.List;

/*
    BookController -- HTTP 요청 처리하는 컨트롤러

        * CRUD URL 설계 (RESTful 스타일)

        작업              HTTP Method         URL                JSP 화면
       -----------------------------------------------------------------------
        목록 조회            GET             /bookLists           bookList.jsp


        * GET vs POST
         GET : 데이터를 "조회"할 때 사용 (브라우저 주소창에 URL 입력, 링크 클릭)
         POST :  데이터를 "변경"할 때 사용 (폼 제출 --> 등록/수정/삭제)

        * 계층 구조
            Controller --> Service --> Mapper --> DB 순서로 호출함
            Controller : 요청 접수 & 응답 (URL 매핑, 파라미터 수신, View 전달)
            Service : 비즈니스 로직 (여러 Mapper 조합, 트랜잭션 관리)
            Mapper : DB 접근 (SQL 실행)
            --> 각 계층이 자기 역할만 하므로 코드가 깔끔하고 유지보수가 쉬움.
 */

/*
   @Controller : 이 클래스가 Spring MVC의 "컨트롤러"임을 선언
   브라우저의 요청(URL)을 받아서 처리하는 역할
   Spring이 서버 시작 시 어노테이션을 보고 자동으로 객체를 생성해서 관리함 (= Bean 등록)

   @RequiredArgsConstructor (Lombok)
        - final로 선언된 필드를 파라미터로 받는 생성자를 자동 생성함
        - public BookController(BookService bookService) { this.bookService = bookService; }
        - 이 생성자를 통해 Spring이 BookService를 자동으로 주입(DI)함
        - 즉, new BookService()를 직접 할 필요가 없음! Spring이 알아서 넣어줌.
 */
@Controller
@RequiredArgsConstructor
public class BookController {

    /*
        의존성 주입(DI)
            - final + @RequiredArgsConstructor = 생성자 주입 방식
            Spring이 시작될 때 BookService 객체(Bean)를 찾아서 여기에 넣어줌
            --> Controller는 Service의 메서드만 호출하면 됨.
                실제 DB 작업은 Service가 Mapper에게 위임함.

        호출 체인
            bookService.bookList()    --->   bookMapper.findAll()    --> SELECT SQL
     */
    private final BookService bookService;

    @GetMapping("/")
    public String index(Model model) {
        model.addAttribute("hello", "Hello JSP, Mybatis");
        return "index";
    }

    // [R] 목록 조회 -- 하드 코딩된 테스트 데이터로 목록 표시
    @GetMapping("/bookList")
    public String bookList(Model model) {
        // DB 없이 직접 데이터를 만들어서 테스트
        Book book1 = new Book(1L, "자바", 30000, "이순신", 600, null);
        Book book2 = new Book(2L, "파이썬", 40000, "김순신", 800, null);
        Book book3 = new Book(3L, "AI", 50000, "박순신", 700, null);

        List<Book> list = new ArrayList<>();
        list.add(book1); list.add(book2); list.add(book3);

        model.addAttribute("list", list);

        return "bookList";      // bookList.jsp를 찾아서 화면에 보여줌
    }

    // DB에서 실제 데이터를 조회하여 목록 표시
    @GetMapping("/bookLists")
    public String bookLists(Model model) {
        List<Book> list = bookService.bookList();
        model.addAttribute("list", list);
        return "bookList";
    }
}










