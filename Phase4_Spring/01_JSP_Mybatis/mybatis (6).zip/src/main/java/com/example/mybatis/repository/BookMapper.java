package com.example.mybatis.repository;

import com.example.mybatis.entity.Book;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface BookMapper {

    // 모든 책 목록을 조회하는 메서드
    public List<Book> findAll();

    // 특정 책 1권을 ID로 조회하는 메서드
    public  Book findById(Long id);

    // 파라미터 : Book book --> 수정할 내용이 담긴 객체 (id 포함)
    // 반환타입 : void
    public void update(Book book);
}

















