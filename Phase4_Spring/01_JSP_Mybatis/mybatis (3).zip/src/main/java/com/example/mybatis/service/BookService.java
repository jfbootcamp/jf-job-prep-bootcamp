package com.example.mybatis.service;

public class BookService {
}
