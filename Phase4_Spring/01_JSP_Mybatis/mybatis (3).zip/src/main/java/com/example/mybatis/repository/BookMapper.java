package com.example.mybatis.repository;

public interface BookMapper {
}
