package com.example.mybatis.controller;

import com.example.mybatis.entity.Book;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.ArrayList;
import java.util.List;

/*
   @Controller : 이 클래스가 Spring MVC의 "컨트롤러"임을 선언
   브라우저의 요청(URL)을 받아서 처리하는 역할
   Spring이 서버 시작 시 어노테이션을 보고 자동으로 객체를 생성해서 관리함 (= Bean 등록)
 */
@Controller
public class BookController {
    @GetMapping("/")
    public String index(Model model) {
        model.addAttribute("hello", "Hello JSP, Mybatis");
        return "index";
    }

    @GetMapping("/bookList")
    public String bookList(Model model) {
        // DB 없이 직접 데이터를 만들어서 테스트
        Book book1 = new Book(1L, "자바", 30000, "이순신", 600, null);
        Book book2 = new Book(2L, "파이썬", 40000, "김순신", 800, null);
        Book book3 = new Book(3L, "AI", 50000, "박순신", 700, null);

        List<Book> list = new ArrayList<>();
        list.add(book1); list.add(book2); list.add(book3);

        model.addAttribute("list", list);

        return "bookList";      // bookList.jsp를 찾아서 화면에 보여줌
    }
}










