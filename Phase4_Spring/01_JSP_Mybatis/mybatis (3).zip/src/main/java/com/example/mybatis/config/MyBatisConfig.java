package com.example.mybatis.config;

import org.springframework.context.annotation.Configuration;

@Configuration      // Spring에게 "이 클래스는 설정 파일이야"라고 알려주는 어노테이션
public class MyBatisConfig {
}
