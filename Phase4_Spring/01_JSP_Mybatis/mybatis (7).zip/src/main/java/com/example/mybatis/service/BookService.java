package com.example.mybatis.service;

import com.example.mybatis.entity.Book;
import com.example.mybatis.repository.BookMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

/*
    비즈니스 로직 계층
        * Service 계층의 역할
            - Controller와 Mapper(DB) 사이에서 "비즈니스 로직"을 처리함
            - Controller -> Service -> Mapper 순서로 호출됨.

        * 왜 Service를 만드는가?
            - 비즈니스 로직을 분리하면 코드가 깔끔해짐
            - 여러 Mapper를 조합해서 복잡한 작업을 할수 있음
                - 예) 책 삭제 시 -> 리뷰도 삭제 -> 제고도 삭제 (여러 DB 작업)
            - 트랜잭션 관리 : @Transactional을 붙이면
              여러 DB 작업이 하나의 단뒤로 처리됨.(하나라도 실패하면 전부 롤백)
            - 단위 테스트가 쉬워짐.

        *  @Service 어노테이션
            - 이 클래스가 서비스 계층임을 Spring에게 알려줌
            - Spring이 Bean으로 등록하여 @Autowired로 주입받을 수 있음

        * @RequiredArgsConstructor (Lombok)
            - final로 선언된 필드를 파라미터로 받는 생성자를 자동 생성해줌
            - public  BookService(BookMapper bookMapper) { this.bookMapper = bookMapper; }
              이 생성자를 통해 Spring이 BookMapper를 자동으로 주입(DI)함.
 */
@Service
@RequiredArgsConstructor
public class BookService {
    // BookMapper를 주입받음(final --> 생성자 주입 방식)
    // Spring이 BookMapper의 프록시 구현체를 자동으로 넣어줌
    private final BookMapper bookMapper;

    // [R] 전체 목록 조회
    // Controller에서 bookService.bookList() 호출 --> Mapper의 findAll() 실행
    public List<Book> bookList() {
        return bookMapper.findAll();
    }

    // [R] 특정 책 1권 조회
    // 상세 페이지, 수정 폼에서 기존 데이터를 불러올 때 사용
    public Book getBook(Long id) {
        return bookMapper.findById(id);
    }

    // [U] 책 정보 수정
    // 수정된 Book 객체를 받아서 DB를 업데이트함
    // Book 객체에는 반드시 id가 포함되어 있어야 함
    public void updateBook(Book book) {
        bookMapper.update(book);
    }

    // [C] 새 글 등록
    // Book 객체를 받아서 DB에 저장함
    // 등록 폼에서 사용자가 입력한 데이터가 Book 객체에 담겨서 옴
    public void createBook(Book book) {
        bookMapper.insert(book);
    }
}


















