<%@ page contentType="text/html;charset=UTF-8" language="java" %>

<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>

<c:set var="contextPath"  value="${pageContext.request.contextPath}"/>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>JSP Template with Bootstrap and JSTL</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
</head>
<body>
<jsp:include page="/WEB-INF/views/includes/navbar.jsp" />

<%-- ==== 메인 컨텐츠 영역 ==== --%>
<div class="container mt-4">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <%-- 카드 헤더: 제목 + 등록 버튼
                        d-flex justify-content-between : 좌우 끝으로 정렬
                    --%>
                    <span>도서 목록</span>
                    <a href="${contextPath}/bookCreate" class="btn btn-primary btn-sm">새 책 등록</a>
                </div>
                <div class="card-body">
                    <%-- Bootstrap의 table 클래스로 테이블 스타일 적용
                         table-bordered : 테두리 있는 테이블
                    --%>
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Title</th>
                                <th>Price</th>
                                <th>Author</th>
                                <th>Pages</th>
                                <th>Created</th>
                                <th>Actions</th>        <%-- 수정/삭제 버튼을 넣을 열 추가 --%>
                            </tr>
                        </thead>
                        <tbody>
                            <c:forEach var="book" items="${list }">
                                <tr>
                                    <td>${book.id}</td>
                                    <td><a href="${contextPath}/bookView/${book.id}">${book.title}</a></td>
                                    <td>${book.price}</td>
                                    <td>${book.author}</td>
                                    <td>${book.page}</td>
                                    <td><fmt:formatDate value="${book.createdAt }" pattern="yyyy-MM-dd"/></td>
                                    <%-- 수정/삭제 버튼 영역 --%>
                                    <td>
                                       <%-- 수정 버튼 : GET 요청으로 수정 폼으로 화면 이동 --%>
                                        <a href="${contextPath}/bookUpdate/${book.id}" class="btn btn-warning btn-sm">수정</a>
                                       <%-- 삭제 버튼 : POST 요청으로 삭제 처리
                                            <form>으로 감싸서 POST 요청을 보냄
                                        --%>
                                       <form action="${contextPath}/bookDelete/${book.id}"
                                            method="post" style="display:inline"
                                            onsubmit="return confirm('정말로 삭제하시겠습니까?')">
                                            <button type="submit" class="btn btn-danger btn-sm">삭제</button>
                                       </form>
                                    </td>
                                </tr>
                            </c:forEach>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<jsp:include page="/WEB-INF/views/includes/footer.jsp" />

<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.min.js"></script>
</body>
</html>

















