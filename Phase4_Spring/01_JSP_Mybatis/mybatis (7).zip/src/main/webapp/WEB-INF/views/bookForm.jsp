<%-- 책 등록 / 수정 공용 폼 페이지

    * 등록과 수정을 하나의 JSP로 처리하는 방법
        - 수정 시: Controller에서 기존 book 객체를 전달함 --> ${book}에 값이 있음
        - 등록 시: Controller에서 book 객체를 전달하지 않음 -->  ${book}이 null
        --> 이 차이를 이용해서 하나의 폼으로 등록/수정을 모두 처리함.
            ${book.id}가 있으면 수정, 없으면 등록으로 분기함.
--%>


<%@ page contentType="text/html;charset=UTF-8" language="java" %>

<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>

<c:set var="contextPath"  value="${pageContext.request.contextPath}"/>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>
         <c:choose>
            <c:when test="${not empty book}">도서 수정</c:when>
            <c:otherwise>도서 등록</c:otherwise>
         </c:choose>
    </title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
</head>
<body>
    <jsp:include page="/WEB-INF/views/includes/navbar.jsp" />

    <div class="container mt-4">
        <div class="row">
            <div class="col-md-8 offset-md-2">
                <div class="card">
                    <div class="card-header">
                        <h5>
                            <c:choose>
                               <c:when test="${not empty book}">도서 수정</c:when>
                               <c:otherwise>도서 등록</c:otherwise>
                            </c:choose>
                        </h5>
                    </div>

                    <div class="card-body">
                        <%--
                            <form> 태그 핵심 속성
                            action : 폼 데이터를 보낼 URL
                                - 등록: /bookCreate (POST)
                                - 수정: /bookUpdate (POST)
                            method="post" <-- 데이터를 HTTP Body에 담아서 보냄
                                - GET : URL에 데이터가 노출됨 (?title=자바&price=30000)
                                - POST : URL에 노출 안 됨 (보안상 안전)
                                - 데이터 변경 작업은 반드시 POST를 사용함.
                        --%>
                         <form action="${contextPath}/${not empty book ? 'bookUpdate' : 'bookCreate'}"
                                method="post">
                             <c:if test="${not empty book}">
                                <input type="hidden" name="id" value="${book.id}">
                             </c:if>

                             <%-- 각 입력 필드
                                name="title" :  Book 클래스의 title 필드와 매핑
                                value="${book.title}" :  수정 시 기존 값을 채워놓음
                                (등록 시에는 ${book}이 null이므로 빈 칸이 됨)
                                required: HTML5 필수 입력 검증 (빈 칸이면 제출 불가)
                             --%>
                            <div class="form-group">
                                <label for="title">제목</label>
                                <input type="text" class="form-control" id="title"
                                    name="title" value="${book.title}"
                                    placeholder="책 제목을 입력하세요" required>
                            </div>

                            <div class="form-group">
                                <label for="price">가격</label>
                                <input type="number" class="form-control" id="price"
                                    name="price" value="${book.price}"
                                    placeholder="가격을 입력하세요" required>
                            </div>

                            <div class="form-group">
                                <label for="author">저자</label>
                                <input type="text" class="form-control" id="author"
                                    name="author" value="${book.author}"
                                    placeholder="저자를 입력하세요" required>
                            </div>

                            <div class="form-group">
                                <label for="page">페이지 수</label>
                                <input type="number" class="form-control" id="page"
                                    name="page" value="${book.page}"
                                    placeholder="페이지 수를 입력하세요" required>
                            </div>

                            <%-- 버튼 영역 --%>
                            <div class="text-right">
                                <a href="${contextPath}/bookLists" class="btn btn-secondary">취소</a>

                                <%-- type ="submit" : 클릭하면 <form>의 action URL로 데이터 전송 --%>
                                <button type="submit" class="btn btn-primary">
                                    <c:choose>
                                        <c:when test="${not empty book}">수정</c:when>
                                        <c:otherwise>등록</c:otherwise>
                                    </c:choose>
                                </button>
                            </div>
                         </form>
                    </div>
                </div>
            </div>
        </div>
    </div>



    <jsp:include page="/WEB-INF/views/includes/footer.jsp" />

    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.min.js"></script>
</body>
</html>












