<%@ page contentType="text/html;charset=UTF-8" language="java" %>

<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>

<c:set var="contextPath"  value="${pageContext.request.contextPath}"/>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>JSP Template with Bootstrap and JSTL</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
</head>
<body>
<jsp:include page="/WEB-INF/views/includes/navbar.jsp" />

<div class="container mt-4">
    <div class="row">
        <div class="col-md-8 offset-md-2">
            <div class="card">
                <div class="card-header>
                    <h5>도서 상세 정보</h5>
                </div>
                <div class="card-body">
                    <%-- 테이블로 상세 정보 표시
                        table-striped : 홀수/짝수 행의 배경색을 다르게 (가독성 향상)
                    --%>
                    <table class="table table-striped">
                        <tr>
                            <th style="width: 30%">ID</th>
                            <td>${book.id}</td>
                        </tr>
                        <tr>
                            <th>제목</th>
                            <td>${book.title}</td>
                        </tr>
                        <tr>
                            <th>가격</th>
                            <td><fmt:formatNumber value="${book.price}" pattern="#,###" />원</td>
                        </tr>
                        <tr>
                            <th>저자</th>
                            <td>${book.author}</td>
                        </tr>
                        <tr>
                            <th>페이지 수</th>
                            <td>${book.page}</td>
                        </tr>
                        <tr>
                            <th>등록일</th>
                            <td><fmt:formatDate value="${book.createdAt}" pattern="yyyy-MM-dd" /></td>
                        </tr>

                    </table>
                </div>

                <%-- 카드 하단: 액션 버튼들 --%>
                <div class="card-footer text-right">
                    <%-- 목록으로 돌아가기 --%>
                    <a href="${contextPath}/bookLists" class="btn btn-secondary">목록</a>
                    <%-- 수정 페이지로 이동 --%>
                    <a href="${contextPath}/bookUpdate/${book.id}" class="btn btn-warning">수정</a>
                    <%-- 삭제: POST 요청으로 처리 --%>
                   <form action="${contextPath}/bookDelete/${book.id}"
                        method="post" style="display:inline"
                        onsubmit="return confirm('정말로 삭제하시겠습니까?')">
                        <button type="submit" class="btn btn-danger">삭제</button>
                   </form>
                </div>
            </div>
        </div>
    <div>
<div>
<jsp:include page="/WEB-INF/views/includes/footer.jsp" />

</body>
</html>











