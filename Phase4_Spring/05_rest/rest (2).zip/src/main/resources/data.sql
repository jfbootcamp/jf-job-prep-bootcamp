-- insert into book (...)
-- select ... where not exists (select 1 from book where subject = 'Java와 AI')

-- select 1
-- : 실제 컬럼 데이터가 필요 없고, "행이 존재하는지 여부"만 확인할 때 사용함
--   조건에 맞는 행이 있으면 숫자 1을 반환 (값 자체는 의미 없음)

insert into book (subject, price, author, page, created_at, updated_at)
select 'Java와 AI', 35000, '이순신', 500, now(), now()
where not exists (select 1 from book where subject = 'Java와 AI');

insert into book (subject, price, author, page, created_at, updated_at)
select 'Spring Boot in Action', 42000, '류성룡', 300, now(), now()
    where not exists (select 1 from book where subject = 'Spring Boot in Action');

insert into book (subject, price, author, page, created_at, updated_at)
select 'Effective Java', 38000, '신사임당', 412, now(), now()
    where not exists (select 1 from book where subject = 'Effective Java');
