package com.example.rest.restcontroller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/*
    JSON 직렬화 테스트 컨트롤러
        - @RestController에서 return할 때
         Jackson이 자동으로 Java 객체를 JSON으로 변환하는 과정을
         확인할수 있는 API
 */
@Slf4j
@RestController
@RequestMapping("/api/lab")
@Tag(name = "JSON Lab", description = "JSON 직렬화 실습 - Jackson 동작 확인하는 랩")
public class JsonController {

    @GetMapping("/step1-string")
    @Operation(summary = "[Step 1] 문자열 반환",
                description = "단순 문자열을 return하면 Jackson이 JSON 문자열로 변환합니다. " +
                            "Response Body에서 쌍따옴표로 감싸진 문자열을 확인하세요.")
    public String step1String() {
        log.info("Step 1: 문자열 반환");
        return "Hello World"; // 이 문자열이 Jaskson을 거쳐 JSON 응답으로 변환됨
        // StringHttpMessageConverter가 처리 - Jackson 관여 안 함
    }
}





















