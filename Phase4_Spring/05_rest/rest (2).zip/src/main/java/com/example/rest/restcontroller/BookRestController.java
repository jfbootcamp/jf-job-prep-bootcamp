package com.example.rest.restcontroller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/*
    Book REST API 컨트롤러

    [REST API 설계 원칙]
    Method              URI                 역할
    ------------------------------------------------
    POST          /api/books        새 책 등록 (Create)
    GET           /api/books        전체 목록 조회 (Read All)
    GET           /api/books/{id}   단건 조회 (Read One)
    PUT           /api/books/{id}   수정 (Update)
    DELETE        /api/books/{id}   삭제 (Delete)

 */
@Slf4j
@RestController
@RequestMapping("/api")
@Tag(name = "Book Controller", description = "책을 관리하는 컨트롤러") // Swagger UI 화면에서 API 그룹 제목과 설명으로 표시됨
public class BookRestController {

    // Swagger UI: GET /api/test
    @GetMapping("/test")        // HTTP GET 메서드 -> Swagger UI에서 파란색 GET 배지
    @Operation(summary = "서버 상태 확인",
                description = "서버가 정상 동작하는지 확인하는 테스트 엔드포인트")
    @Tag(name = "Health Check")
    public ResponseEntity<String> test() {
        return ResponseEntity.ok("Hello REST API Server is running");
    }

}
