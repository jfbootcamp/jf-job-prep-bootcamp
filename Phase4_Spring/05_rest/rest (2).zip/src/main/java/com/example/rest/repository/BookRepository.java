package com.example.rest.repository;

public interface BookRepository {
}
