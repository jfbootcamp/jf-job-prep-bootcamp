package com.example.rest.entity;


import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.print.attribute.standard.MediaSize;
import java.time.LocalDateTime;

@Entity
@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "book")    // 테이블명 명시 -- 클래스명과 테이블명의 매핑을 명확히 드러냄
public class Book {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(name = "subject", length = 200) private String subject; // 컬럼 길이 제약 (기본값은 255)
    @Column(name = "price")
    private int price;
    @Column(name = "author", length = 100)
    private String author;
    @Column(name = "page")
    private int page;
    @Column(name = "created_at", updatable = false)  // INSERT 시에만 값 설정, UPDATE 시 변경 불가
    private LocalDateTime createdAt;
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    @PrePersist     // DB에 INSERT 하기 직전에 실행, 최초 저장(INSERT) 직전에 자동 호출
    public void onCreate() {
        this.createdAt = LocalDateTime.now();
        this.updatedAt = LocalDateTime.now();
    }

    @PreUpdate      // 수정(update) 직전에 자동 호출
    public void onUpdate() {
        this.updatedAt = LocalDateTime.now();
    }
}
