package com.example.rest.entity;


public class Book {
}
