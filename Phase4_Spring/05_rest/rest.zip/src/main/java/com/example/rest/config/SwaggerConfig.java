package com.example.rest.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.servers.Server;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.List;

/*
*   SwaggerConfig - OpenAPI 문서 커스터마이징
*       - 기본 설정만으로도 Swagger UI가 동작하지만,
*         이 설정 클래스를 통해 API 문서의 제목, 설명, 서버 URL 등을 커스터마이징함
*       - API 문서가 프런트엔드 개발자와의 계약서
*           - 정확하고 상세하게 작성해야 함
*
* */
@Configuration  // 이 클래스가 스프링 설정 클래스임을 선언 -> 내부의 @Bean 메서드가 반환하는 객체를 스프링 빈으로 등록
public class SwaggerConfig {

    @Bean
    public OpenAPI customOpenAPI() {
        return new OpenAPI()
                .info(new Info()
                        .title("REST API")
                        .version("1.0.0")
                        .description("""
                                Spring Boot + JPA + Swagger UI 기반 도서 관리 REST API
                                
                                """)
                        .contact(new Contact()
                                .name("교육 담당")
                                .email("hometop@onepass.com")))
                .servers(List.of(
                        new Server()
                                .url("http://localhost:8084")
                                .description("로컬 개발 서버"),
                        new Server()
                                .url("https://dev-api.example.com")
                                .description("개발 서버(DEV)"),
                        new Server()
                                .url("https://api.example.com")
                                .description("운영 서버(PROD)")
                ));
    }
}
