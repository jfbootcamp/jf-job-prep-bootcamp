package com.example.rest.service;

import com.example.rest.dto.BookRequestDTO;
import com.example.rest.entity.Book;
import com.example.rest.exception.ResourceNotFoundException;
import com.example.rest.repository.BookRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
@Transactional(readOnly = true) // 클래스 레벨에 선언하면 모든 메서드에 기본 적용
public class BookService {
    private final BookRepository bookRepository;

    /* ID로 특정 책 조회 */
    public Book findById(Long id) {
        return bookRepository.findById(id)
                //.orElseThrow(() -> new RuntimeException("Book Not Found with id: " + id));
                .orElseThrow(() -> new ResourceNotFoundException("Book", id));

    }

    /* 전체 책 목록 조회 */
    public List<Book> findAll() {
        return bookRepository.findAll();
    }

    /* 새 책 등록
    *   bookRequestDTO - 클라이언트가 보낸 등록 데이터 (DTO)
    *   저장된 Book (id, createdAt 자동 생성됨)
    * */
    @Transactional   // readOnly=false (쓰기 트랜잭션) -- 클래스 레벨의 readOnly=true를 오버라이드
    public Book createBook(BookRequestDTO bookRequestDTO) {
        // DTO -> Entity 변환 (Service 계층에서 변환 -> Controller가 깔끔해짐)
        Book book = new Book();
        book.setSubject(bookRequestDTO.getSubject());
        book.setPage(bookRequestDTO.getPage());
        book.setAuthor(bookRequestDTO.getAuthor());
        book.setPrice(bookRequestDTO.getPrice());
        return bookRepository.save(book);   // INSERT 실행 -> @PrePersist로 createdAt 자동 설정
    }

    /* update
    *   - 기존 책 수정 (전체 필드 업데이트)
    *   - 파라미터 :  수정할 책의 ID
    *   - DTO : 수정 데이터
    *   - return : 수정된 Book
    * */
    @Transactional          // 쓰기 트랜잭션
    public Book updateBook(Long id, BookRequestDTO bookRequestDTO) {
        Book book = findById(id);
        book.setSubject(bookRequestDTO.getSubject());
        book.setPrice(bookRequestDTO.getPrice());
        book.setAuthor(bookRequestDTO.getAuthor());
        book.setPage(bookRequestDTO.getPage());
        return bookRepository.save(book);
    }

    /* 책 삭제 - 삭제할 책의 ID */
    @Transactional   // 쓰기 트랜잭션
    public void deleteBook(Long id) {
        Book book = findById(id);
        bookRepository.delete(book);    // DELETE FROM book WHERE id = ?
    }
}
