package com.example.rest.dto;

import com.example.rest.entity.Book;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import lombok.*;

import java.time.LocalDateTime;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Schema(description = "책 응답 DTO")
@Builder        // .builder().field(value).build() 패턴
public class BookViewDTO {

    @Schema(description = "책 ID (자동 생성)", example = "1")
    private Long id;

    @Schema(description = "책 제목", example = "Java와 AI의 미래")
    private String subject;

    @Schema(description = "가격", example = "35000")
    private int price;

    @Schema(description = "저자", example = "이성계")
    private String author;

    @Schema(description = "페이지 수", example = "500")
    private int page;

    @Schema(description = "등록일시", example = "2026-04-03T10:48:00")
    private LocalDateTime createdAt;

    @Schema(description = "수정일시", example = "2026-04-03T10:49:00")
    private LocalDateTime updatedAt;

    /*
    *       Entity -> DTO 변환 (정적 팩토리 메서드)
    *
    *       데이터 흐름:  DB -> Repository -> Entity(Book) -> from()으로 변환 -> DTO(BookViewDTO) -> Client
    *
    *       Entity는 DB 테이블의 모든 컬럼을 그대로 들고 있음
    *       하지만 클라이언트에게 모든 걸 보열줄 필요는 없고, 보여주면 안 되는 것도 있음.
    *
    *       이 from()이 Entity에서 클라이언트에게 보여줄 필드만 골라서 DTO에 담아줌.
    *       이 메서드가 없으면 Entity가 그대로 클라이언트까지 보내져서 DB구조가 API에
    *       그대로 노출됨.
    *
    * */
    public static BookViewDTO from(Book book) {
        return BookViewDTO.builder()            // @Builder가 생성한 빌더 객체 시작
                .id(book.getId())               // Entity의 id -> DTO의 id
                .subject(book.getSubject())     // Entity의 subject -> DTO의 subject
                .price(book.getPrice())
                .author(book.getAuthor())
                .page(book.getPage())
                .createdAt(book.getCreatedAt())
                .updatedAt(book.getUpdatedAt())
                .build();

    }
}
