package com.example.rest.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

/*
    GlobalExceptionHandler - 전역 예외 처리 (모든 Controller에 자동 적용)

    POST  /api/books        @Valid 검증 실패 -> handleValidation() -> 400
    PUT   /api/books/{id}   @Valid 검증 실패 -> handleValidation() -> 400
    모든 엔드포인트            예측 불가 오류 -> handleGeneral() -> 500


    GET / DELETE에 @Valid 없음
        - @Valid는 요청 본문 검증용
        - GET / DELETE는 요청 본문이 없고 경로의 {id}만 받음 --> @Valid 불필요
 */
@RestControllerAdvice
public class GlobalExceptionHandler {
    // 404 Not Found - 리소스를 찾을 수 없음
    /*
    *   응답 예시
    *   HTTP 404
    *   {
    *       "timestamp": "....", "status": 404,
    *       "error" : "Not Found", "message": "Book (id=1)을 찾을 수 없습니다."
    *   }
    * */

    @ExceptionHandler(ResourceNotFoundException.class)
    public ResponseEntity<Map<String, Object>> handleNotFoundException(ResourceNotFoundException e) {
        return buildErrorResponse(HttpStatus.NOT_FOUND, e.getMessage());
    }

    private ResponseEntity<Map<String, Object>> buildErrorResponse(HttpStatus status, String message) {
        Map<String, Object> body = new HashMap<>();
        body.put("timestamp", LocalDateTime.now());   // 에러 발생 시각 - 디버그,로그 추적에 활용
        body.put("status", status.value());           // 예: 404, 500 (숫자)
        body.put("error", status.getReasonPhrase());  // 예: "Not Found", "Internal Server Error"
        body.put("message", message);                 // 예: "Book (id=1)을(를) 찾을 수 없습니다."
        return ResponseEntity.status(status).body(body);  // HTTTP 상태코드 + JSON 본문 함께 반환
    }
}
