package com.example.rest.exception;
/*
*     ResourceNotFoundException - 리소스를 찾을 수 없을 때 던지는 커스텀 예외
*
*     RuntimeException 상속 시 장점
*       - Service에서 throws 선언 불필요
*       - Controller에서 try-catch 불필요
*       - GlobalExceptionHandler가 알아서 처리 --> 코드 깔끔
*
*     * throw vs throws
*       - throw new ResourceNotFoundException(...) --> 예외를 실제로 던지는 코드
*       - throws ResourceNotFoundException --> 메서드 시그니처에 선언
*
*       RuntimeException이므로 throw new는 자유롭게 사용 가능
*       단, 메서드 시그니처에 throws 선언은 안 해도 됨(Unchecked 장점)
*
*                                   try~catch 강제       사용 시점
*     Checked    Exception          O 컴파일러 강제       파일 I/O, 네트워크
*     Unchecked  Exception          X 강제 안 함         비즈니스 로직 예외
*
* */
public class ResourceNotFoundException extends RuntimeException {
    /* 메시지 직접 전달 생성자 */
    public ResourceNotFoundException(String message) {
        super(message);  // RuntimeException 생성자에 메시지 전달 --> getMessage()로 꺼낼 수 있음
    }

    /* 리소스명 + ID로 메시지 자동 생성 생성자
    *   Service에서 메시지를 직접 조회할 필요없이 리소스명+ID만 넘기면
    *   일관된 형식의 메시지가 자동 생성됨
    * */
    public ResourceNotFoundException(String resourceName, Long id) {
        super(resourceName + "(id=" +id+ ")을(를) 찾을 수 없습니다.");
    }

}
