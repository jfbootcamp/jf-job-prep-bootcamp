package com.example.rest.service;

import com.example.rest.dto.BookRequestDTO;
import com.example.rest.entity.Book;
import com.example.rest.repository.BookRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
@Transactional(readOnly = true) // 클래스 레벨에 선언하면 모든 메서드에 기본 적용
public class BookService {
    private final BookRepository bookRepository;

    public Book findById(Long id) {
        return bookRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException());
    }

    /* 전체 책 목록 조회 */
    public List<Book> findAll() {
        return bookRepository.findAll();
    }

    /* 새 책 등록
    *   bookRequestDTO - 클라이언트가 보낸 등록 데이터 (DTO)
    *   저장된 Book (id, createdAt 자동 생성됨)
    * */
    @Transactional   // readOnly=false (쓰기 트랜잭션) -- 클래스 레벨의 readOnly=true를 오버라이드
    public Book createBook(BookRequestDTO bookRequestDTO) {
        // DTO -> Entity 변환 (Service 계층에서 변환 -> Controller가 깔끔해짐)
        Book book = new Book();
        book.setSubject(bookRequestDTO.getSubject());
        book.setPage(bookRequestDTO.getPage());
        book.setAuthor(bookRequestDTO.getAuthor());
        book.setPage(bookRequestDTO.getPage());
        return bookRepository.save(book);   // INSERT 실행 -> @PrePersist로 createdAt 자동 설정
    }
}
