package com.example.rest.restcontroller;

import com.example.rest.dto.BookRequestDTO;
import com.example.rest.dto.BookViewDTO;
import com.example.rest.entity.Book;
import com.example.rest.service.BookService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/*
    Book REST API 컨트롤러

    [REST API 설계 원칙]
    Method              URI                 역할
    ------------------------------------------------
    POST          /api/books        새 책 등록 (Create)
    GET           /api/books        전체 목록 조회 (Read All)
    GET           /api/books/{id}   단건 조회 (Read One)
    PUT           /api/books/{id}   수정 (Update)
    DELETE        /api/books/{id}   삭제 (Delete)

 */
@Slf4j
@RestController
@RequestMapping("/api")
@RequiredArgsConstructor
@Tag(name = "Book Controller", description = "책을 관리하는 컨트롤러") // Swagger UI 화면에서 API 그룹 제목과 설명으로 표시됨
public class BookRestController {

    private final BookService bookService;

    // Swagger UI: GET /api/test
    @GetMapping("/test")        // HTTP GET 메서드 -> Swagger UI에서 파란색 GET 배지
    @Operation(summary = "서버 상태 확인",
                description = "서버가 정상 동작하는지 확인하는 테스트 엔드포인트")
    @Tag(name = "Health Check")
    public ResponseEntity<String> test() {
        return ResponseEntity.ok("Hello REST API Server is running");
    }

    /*
      Swagger UI: POST  /api/books -- 초록색 POST 배지

      @Valid -> 유효성 검증 (Swagger UI에서 required 필드 표시에 영향)
                검증 실패 시 예외 처리가 됨
      @RequestBody -> Swagger UI에서 "Request Body" 입력 영역이 생성되며
                      BookRequestDTO의 @Schema 정보로 예시 JSON이 자동 채워짐.
                      역할: HTTP 요청 본문(JSON)을 자바 객체로 자동 변환
                           (역직렬화: JSON -> DTO)
    * */

    @PostMapping(value = "/books",
                consumes = "application/json",  // Swagger UI "Request body" 섹션에 JSON 입력 폼 활성화
                produces = "application/json")  // Swagger UI "Response" 섹션에 JSON 응답 스키마 표시
    @Operation(summary = "새 책 등록",
                description = "새로운 책을 등록합니다. id와 createdAt은 서버에서 자동 생성됩니다.")
    @ApiResponses({     // @ApiResponses - 하나의 엔드포인트가 반환할 수 있는 여러 HTTP 상태 코드를 묶어서 선언
        @ApiResponse(responseCode = "201", description = "등록 성공"),
        @ApiResponse(responseCode = "400", description = "유효성 검증 실패")
    })
    public ResponseEntity<BookViewDTO> createBook(
            @Valid @RequestBody BookRequestDTO bookRequestDTO) {
        log.info("[POST] /api/books - 신규 등록: {}", bookRequestDTO);
        Book saved = bookService.createBook(bookRequestDTO);
        return ResponseEntity
                .status(HttpStatus.CREATED)     // 201 created (실무 권장- 200 ok 대신)
                .body(BookViewDTO.from(saved)); // Entity -> DTO 변환
    }
}
