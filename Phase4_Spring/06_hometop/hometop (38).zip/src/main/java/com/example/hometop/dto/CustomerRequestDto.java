package com.example.hometop.dto;

import com.example.hometop.entity.Customer;
import com.example.hometop.enums.RatingType;
import jakarta.validation.constraints.*;
import lombok.*;

/*
*   회원 등록 요청 DTO -- "입력" 역할
*       Client --> CustomerRequestDto --> Service --> Entity --> DB
*
* */
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CustomerRequestDto {
    // @Valid 검증 어노테이션 추가

    @NotBlank(message = "아이디는 필수 입력 항목입니다.")  // null, "", " " 모두 거부
    @Size(min = 4, max = 20, message = "아이디는 4~20자 사이어야 합니다.")
    private String username;

    @NotBlank(message = "비밀번호는 필수 입력 항목입니다.")
    @Size(min = 4, message = "비밀번호는 최소 4자 이상이어야 합니다.")
    private String password;

    @NotBlank(message = "이름은 필수 입력 항목입니다.")
    @Size(max = 50, message = "이름은 최대 50자까지 입력 가능 합니다.")
    private String customerName;

    @NotNull(message = "나이는 필수 입력 항목입니다.")
    @Min(value = 1, message = "나이는 1 이상이어야 합니다.")
    @Max(value = 150, message = "나이는 150 이하어야 합니다.")
    private Integer age;

    @Size(max = 100, message = "직업은 최대 100자까지 입력 가능합니다.")
    private String occupation;

    @Email(message = "이메일 형식이 올바르지 않습니다. (예: user@example.com)")
    private String email;

    @Pattern(regexp = "^01[016789]-\\d{3,4}-\\d{4}$",
            message = "전화번호 형식이 올바르지 않습니다 (예: 010-2345-5678)")
    private String phone;



    /* DTO --> Entity 변환 메서드
    *   - Service 레이어에서 호출하여 Entity로 변환 후 Repository에 전달
    * */
    public Customer toEntity() {
        return Customer.builder()
                .username(this.username)
                .password(this.password)
                .customerName(this.customerName)
                .age(this.age)
                .rating(RatingType.BRONZE)
                .occupation(this.occupation)
                .build();
    }
}
