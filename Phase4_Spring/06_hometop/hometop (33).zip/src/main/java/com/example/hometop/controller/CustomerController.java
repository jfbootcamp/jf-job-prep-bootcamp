package com.example.hometop.controller;

import com.example.hometop.dto.CustomerRequestDto;
import com.example.hometop.dto.CustomerResponseDto;
import com.example.hometop.dto.CustomerUpdateDto;
import com.example.hometop.entity.Customer;
import com.example.hometop.enums.RatingType;
import com.example.hometop.service.CustomerService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

@Slf4j
@Controller
@RequestMapping("/customer")
@RequiredArgsConstructor
public class CustomerController {
    private final CustomerService customerService;

    // 회원 목록 페이지
    // GET /customer
    // GET /customer?searchType=xxx&keyword=yyy&sortBy=xxx&direction=asc|desc&page=N&size=N
    /*
    *    비검색 -> findAllCustomers(Pageable pageable)     -- 탈퇴 제외 + 페이지네이션 + 정렬
    *    검색 -> searchType 별 Page 반환                    -- 검색 결과에도 페이지네이션 적용
    * */
    @GetMapping
    public String index(Model model,
                        @RequestParam(required = false) String searchType,  // 검색 유형
                        @RequestParam(required = false) String keyword,      // 검색어
                        @RequestParam(required = false) String rating,       // 등급 파라미터
                        @RequestParam(required = false, defaultValue = "id") String sortBy,    // 정렬 기준: id | customerName | reserves | createdAt
                        @RequestParam(required = false, defaultValue = "desc") String direction,  // 정렬 방향: asc | desc
                        @PageableDefault(size = 10) Pageable pageable) {    // 기본 10건/페이지

        Page<CustomerResponseDto> page = null;  // 최종적으로 뷰에 전달할 회원 목록
        String searchResultMsg = null;  //검색 결과 요약 메시지

        // "asc" 외 모든 값은 DESC 처리
        Sort.Direction dir = "asc".equalsIgnoreCase(direction)
                ? Sort.Direction.ASC
                : Sort.Direction.DESC;

        // 정렬 허용 목록 컬럼명인데, 허용 목록에 없는 컬럼명은 "id"로 강제 변환
        String validSort =
                List.of("id", "customerName", "reserves", "createdAt").contains(sortBy)
                ? sortBy : "id";

        // @PageableDefault의 page/size + 위에서 결정한 정렬 기준을 합쳐 새 Pageable 생성
        Pageable sortedPageable =
                PageRequest.of(pageable.getPageNumber(), // @PageableDefault가 만들어준 page 번호
                        pageable.getPageSize(),  // @PageableDefault가 만들어준 size (기본10)
                        Sort.by(dir, validSort));  // 정렬은 새로 적용


        // 검색 유형 미선택 + 검색어 있음 -->  안내 메시지 표시 후 전체 목록
        // 서버 측 방어 로직 -- "클라이언트 검증은 UX, 서버 검증은 보안" 원칙
        boolean isSearchActive =
                (searchType != null || !searchType.isBlank()) && keyword != null
                        && !keyword.isBlank();   // searchType과 keyword 둘다 있을때만 검색 모드로 판단

        if (!isSearchActive) {          // 비검색 모드 - 탈퇴 회원 제외 + 페이지네이션 + 정렬 적용
            page = customerService.findAllCustomers(sortedPageable);

        } else if ((searchType == null || searchType.isBlank())
                && keyword != null && !keyword.isBlank()) {  // 검색 유형 미선택 + 검색어 있음
            page = customerService.findAllCustomers(sortedPageable);
            searchResultMsg =
                    "검색 유형을 먼저 선택해 주세요. (현재 전체 목록을 표시합니다.)";
        } else {
            // searchType에 따라 해당 쿼리 메서드 호출
            switch (searchType) {
                case "username" -> {
                    // 쿼리 메서드
                    page = customerService.findCustomersByUsernameContaining(keyword, sortedPageable);
                    searchResultMsg = "아이디 '"+keyword+"' 검색 결과 " + page.getTotalElements() + "건";
                    log.info("=== 쿼리 메서드 findByUsernameContaining === keyword={}, 결과={}건",
                                                        keyword, page.getTotalElements());
                }

                case "minReserves" -> {
                    // 쿼리 메서드 findByReservesGreaterThanEqual -> WHERE reserves >= ?
                    // keyword(String)를 int로 변환
                    try {
                        int reserves = Integer.parseInt(keyword.replaceAll(",", ""));  // "10,000" -> "10000"
                        page =
                                customerService.findCustomersByReservesGreaterThanEqual(reserves, sortedPageable);
                        searchResultMsg = "적립금 '"+reserves+"' 원 이상 검색 결과 " + page.getTotalElements() + "건";
                        log.info("=== 쿼리 메서드 findByReservesGreaterThanEqual === reserves={}, 결과={}건",
                                reserves, page.getTotalElements());
                    }catch (NumberFormatException e){
                        // 숫자가 아닌 값 입력 시 (예: "abc")
                        page = Page.empty(sortedPageable);
                        searchResultMsg = "적립금은 숫자로 입력해 주세요.(예: 10000)";
                        log.warn("==== 적립금 형식 오류 === keyword={}", keyword);
                    }
                }

                case "ratingAndMinReserves" -> {
                    try {
                        RatingType ratingType = RatingType.valueOf(rating.toUpperCase());   // "GOLD" -> RatinType.GOLD
                        int minReserves =
                                Integer.parseInt(keyword.replaceAll(",", ""));
                        page = customerService.findCustomersByRatingAndMinReserves(ratingType, minReserves, pageable);
                        searchResultMsg = "[JPQL @Query]" + ratingType +" 등급 + 적립금 " + minReserves +" 원 이상 결과: " + page.getTotalElements() + "건";
                        log.info("=== JPQL @Query findByRatingAndMinReserves  ===  rating={}, minReserves={}, 결과={}건", ratingType, minReserves, page.getTotalElements());
                    } catch (Exception e) {
                        page = Page.empty(pageable);
                        searchResultMsg = "등급과 적립금을 올바르게 입력해 주세요.";
                        log.warn("=== JPQL @Query 파라미터 오류  === rating={}, keyword={}", rating, keyword);
                    }

                }

                case "nameOrOccupation" -> {
                    customers = customerService.findCustomersByNameOrOccupation(keyword);
                    searchResultMsg = "[Native @Query] 이름/직업 '"+keyword+"' 검색 결과 " + customers.size() + "건";
                    log.info("=== 쿼리 메서드 findByNameOrOccupationLike === keyword={}, 결과={}건",
                                keyword, customers.size());
                }

                default -> customers = customerService.findAllCustomers();
            }
        }

        model.addAttribute("customers", customers);  // 회원 목록
        model.addAttribute("searchType", searchType);  // 현재 선택한 검색 유형
        model.addAttribute("keyword", keyword);        // 현재 입력한 검색어
        model.addAttribute("searchResultMsg", searchResultMsg);  // 검색 결과 요약 메시지
        model.addAttribute("rating", rating);   // @Query JPQL 전용 등급 파라미터 (select 복원용)
        model.addAttribute("ratingTypes", RatingType.values());

        return "customer/index";      // templates/customer/index.html
    }

    /* 회원 등록 폼 페이지
    *   GET /customer/register
    *       - 빈 CustomerRequestDto를 "customerForm" 이름으로 Model에 담아 뷰에 전달
    *       - 뷰의 th:object="${customerForm}" 이 이 객체와 바인딩되어 폼 필드를 구성함
    *       - POST 처리
    * */
    @GetMapping("/register")
    public String register(Model model) {
        // 빈 DTO를 Model에 담아 전달
        model.addAttribute("customerForm", new CustomerRequestDto());
        return "customer/register";   // templates/customer/register.html
    }

    /*
       회원 등록 처리
       POST /customer/register

        - @ModelAttribute: 폼에서 전송된 데이터를 CustomerRequestDto에 자동 바인딩
            -> Spring MVC가 빈 객체 생성 후, 각 필드를 Setter 로 채움
            -> 폼 input의 name 속성과 DTO 필드명이 일치해야 바인딩됨 (th:field가 자동으로 맞춰줌)

        - RedirectAttributes: POST 처리 후 redirect 시 데이터를 한 번만 전달하는 방법 (PRG 패턴)
            -> addFlashAttributes는 세션에 임시 저장 -> redirect 이후 한번 읽히고 자동 소멸

        PRG 패턴 (POST -> Redirect -> Get)
            POST /customer/register (데이터 저장)
             |
             |--> redirect:/customer (브라우저가 GET 요청으로 전환)
                     |
                     |--> GET /customer (목록 페이지 랜더링)
    * */
    @PostMapping("/register")
    public String register(@ModelAttribute("customerForm") CustomerRequestDto requestDto,
                           RedirectAttributes redirectAttributes) {
        // Service 위임 - DTO -> Entity --> save --> ResponseDTO 반환
        CustomerResponseDto saved = customerService.register(requestDto);

        log.info("회원 등록 완료 === id={}, username={}, name={}, rating={}",
                saved.getId(), saved.getUsername(), saved.getCustomerName(), saved.getRating());

        // Flash attribute -- redirect 이후  customer/index.html에서 한 번 읽히고 자동 소멸
        redirectAttributes.addFlashAttribute("savedCustomer", saved);   // 방금 등록된 회원 (테이블 하이라이트용)
        redirectAttributes.addFlashAttribute("successMessage",          // 성공 메시지 배너용
                " '  "+saved.getUsername()+"  '회원이 성공적으로 등록되었습니다. (등급: " + saved.getRating() + ")  ");

        return "redirect:/customer";   // PRG 패턴 -- POST 후 GET 목록 페이지로 이동
    }

    /*
    *   회원 상세 페이지
    *   GET /customer/{id}
    * */
    @GetMapping("/{id}")
    public String detail(@PathVariable Long id, Model model) {
        CustomerResponseDto customer = customerService.findCustomerById(id);
        log.info("== 회원 상세 조회 == id={}, username={}", customer.getId(), customer.getUsername());
        model.addAttribute("customer", customer);
        return "customer/detail";   // templates/customer/detail.html
    }

    /* 고객별 리뷰 목록 페이지
    *   GET /customer/{id}/reviews
    *
    *   Controller            Service                      View
    *      reviews() 호출 ->  findCustomerEntityById() ->  customer.reviews
    *                          Customer 엔티티 반환
    *                         [트랜잭션 종료]
    *     => Customer 엔티티 안의 reviews는 아직 DB에서 안 읽어온 상태(LAZY프록시)인데,
    *       트랜잭션이 끝나버려서 View에서 읽으려 하면 세션이 없어서 터짐
    * */
    @GetMapping("/{id}/reviews")
    public String reviews(@PathVariable Long id, Model model) {
           //Customer customer = customerService.findCustomerEntityById(id);
           //log.info("===고객 리뷰 페이지 === id={}, username={}", customer.getId(), customer.getUsername());
        CustomerResponseDto customer =
                customerService.findCustomerByIdWithReviews(id);
        model.addAttribute("customer", customer);
        return "customer/reviews";
    }

    /* 회원 삭제 처리
    *   - PRG 패턴 (Post -> Redirect -> Get)
    *   - POST /customer/3/delete (삭제 처리)
    *      -> redirect:/customer (브라우저가 GET 요청으로 전환)
    *           -> GET /customer (목록 페이지 랜더링)
    *   - 브라우저 새로고침 시 POST 중복 제출 방지
    * */
    @PostMapping("/{id}/delete")
    public String delete(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        // 삭제 전 username 미리 조회 (삭제 후에는 조회 불가)
        CustomerResponseDto customer = customerService.findCustomerById(id);
        String username = customer.getUsername();

        customerService.deleteCustomer(id);

        log.info("=== 회원 삭제 완료 === id={}, username={}", id, username);

        // Flash attribute - redirect 이후 customer/index.html에서 한번 읽히고 자동 소멸
        redirectAttributes.addFlashAttribute("successMessage",
                " '"+username+"' 회원이 성공적으로 삭제되었습니다.");

        return "redirect:/customer";  // PRG 패넌 -- POST 후 GET 목록 페이지로 이동

    }

    /* 회원 수정 폼 페이지
    *   GET     /customer/{id}/edit
    *
    *   Model에 객체를 공유
    *       - 수정 불가 필드를 폼 위에 보여주기 위해 사용
    *       - 폼 바인딩용 객체
    *           - 기존 값 전달 --> POST 제출 시 이 객체에 새 값이 담겨 옮
    * */
    @GetMapping("/{id}/edit")
    public String editForm(@PathVariable Long id, Model model) {
        // 기존 회원 정보 조회
        CustomerResponseDto customer = customerService.findCustomerById(id);

        // 수정 폼에 기존 값 -- 사용자가 기존 내용을 보고 수정할수 있도록
        CustomerUpdateDto updateForm = new CustomerUpdateDto();
        updateForm.setCustomerName(customer.getCustomerName());
        updateForm.setAge(customer.getAge());
        updateForm.setOccupation(customer.getOccupation());

        model.addAttribute("customer", customer); // 읽기 전용 정보 (id, username, rating 등)
        model.addAttribute("updateForm", updateForm); // 수정 폼 바인딩 객체

        return "customer/edit";   // templates/customer/edit.html
    }

    /* 회원 수정 처리
    *   POST    /customer/{id}/edit
    *
    *   PRG 패턴
    *     - POST /customer/3/edit (수정 처리)
    *        --> redirect:/customer/3 (브라우저가 GET 요청으로 전환)
    *           --> GET /customer/3 (상세 페이지 랜더링)
    * */
    @PostMapping("/{id}/edit")
    public String update(@PathVariable Long id,
                         @ModelAttribute("updateForm") CustomerUpdateDto updateDto,
                         RedirectAttributes redirectAttributes) {
        // Service에 위임 -> 더티 체킹으로 자동 UPDATE
        CustomerResponseDto updated = customerService.updateCustomer(id, updateDto);
        log.info("===회원 수정 완료=== id={}, username={}", updated.getId(), updated.getUsername() );

        redirectAttributes.addFlashAttribute("successMessage",
                " '"+updated.getUsername()+"' 회원 정보가 성공적으로 수정되었습니다. ");
        return "redirect:/customer/" + id;  // PRG 패턴 -- POST 후 상세 페이지로 이동
    }
}
