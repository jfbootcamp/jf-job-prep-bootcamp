package com.example.hometop.repository;

import com.example.hometop.entity.Customer;
import com.example.hometop.enums.RatingType;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface CustomerRepository extends JpaRepository<Customer, Long> {
    /*
        username으로 회원 단건 조회
            생성되는 SQL :
                SELECT * FROM customers where username = ?
    * */
    Optional<Customer> findByUsername(String username);

    /*
    *   username 부분 일치 검색 (관리자 회원 목록 검색용)
    *       생성되는 SQL :
    *          SELECT * FROM customers where username LIKE '%?%'
    * */
    List<Customer> findByUsernameContaining(String username);
    Page<Customer> findByUsernameContaining(String username, Pageable pageable);

    /*
        적립금이 기준 금액 이상인 회원 목록 조회
            생성되는 SQL :
                SELECT * FROM customers where reserves >= ?
            실무 활용
                - 쇼핑몰 이벤트 대상 선정 : 적립금 N원 이상 회원에게 쿠폰 발급
                - VIP  마케팅 캠페인 : 일정 금액 이상 회원에게 프로모션 안내
                - 포인트 소멸 안내 대상 : 일정 금액 이상 미사용 포인트 보유 회원 조회
           GreaterThanEqual 키워드
                - GreatenThan     -> reserves > ?
                - LessThan        -> reserves < ?
                - LessThanEqual   -> reserves <= ?
                - Between         -> reserves BETWEEN ? AND ?
    * */
    List<Customer> findByReservesGreaterThanEqual(int reserves);
    Page<Customer> findByReservesGreaterThanEqual(int reserves, Pageable pageable);

    /*
        @Query 어노테이션 (JPQL - Entity 기준)
            - JPQL은 테이블병/컬럼명이 아닌 클래스명/필드명을 사용
            - FROM Customer c  -> customers 테이블을 의미 (Entity 클래스명)
            - c.rating   ->  rating 컬럼을 의미 (Entity 필드명)
            - c.reserves
            - @Param("name")  -> JPQL의 :name 파라미터와 바인딩

            - 검색 예) GOLD 등급 중 적립금 10,000원 이상인 고객대상으로해서
                      VIP 이벤트 선정
    * */
    @Query("SELECT c FROM Customer c WHERE c.rating = :rating AND c.reserves >= :minReserves")
    List<Customer> findByRatingAndMinReserves(@Param("rating") RatingType rating,
                                              @Param("minReserves") int minReserves);

    @Query("SELECT c FROM Customer c WHERE c.rating = :rating AND c.reserves >= :minReserves")
    Page<Customer> findByRatingAndMinReserves(@Param("rating") RatingType rating,
                                              @Param("minReserves") int minReserves,
                                              Pageable pageable);

    /*
    *   @Query 어노테이션 (Native SQL - 테이블 기준)
    *   [Native SQL을 사용해야 하는 경우]
    *       - DB 전용 함수 (MySQL: DATE_FORMAT, GROUP_CONCAT 등)
    *       - 복잡한 서브쿼리로 JPQL로 표현이 불가능할 때
    *       - 실행 계획 (EXPLAIN)을 통해 SQL을 직접 튜닝해야 할 때
    *
    *   이름 또는 직업으로 회원 검색 (OR 조건)
    * */
    @Query(value = "SELECT * FROM customers WHERE customer_name LIKE ?1 OR occupation LIKE ?2",
            nativeQuery = true)
    List<Customer> findByNameOrOccupationLike(String nameLike, String occupationLike);

    /*
    *  전체 목록 페이지네이션 조회 - 탈퇴 회원 제외
    *  생성되는 SQL : SELECT * FROM customers WHERE deleted_at IS NULL
    * */
    List<Customer> findByDeletedAtIsNull();

    /*
    *  전체 목록 페이지네이션 조회 - 탈퇴 회원 제외 (Page 버전)
    *
    *   쿼리 메서드(Query Method) 명명 규칙
    *     : 메서드 이름만으로 sql을 자동 생성하는 Spring Data JPA 기능.
    *       Spring Data JPA가 메서드 이름을 파싱해서 런타임에 자동으로 SQL을 생성함.
    *      findBy +  DeletedAt + IsNull
    *        |
    *       \|/
    *       select   deleted_at   IS NULL 조건
    *
    *  생성되는 SQL : SELECT * FROM customers WHERE deleted_at IS NULL LIMIT ? OFFSET ?
     * */
    Page<Customer> findByDeletedAtIsNull(Pageable pageable);
}


