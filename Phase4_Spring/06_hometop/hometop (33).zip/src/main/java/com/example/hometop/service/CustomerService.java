package com.example.hometop.service;

import com.example.hometop.dto.CustomerRequestDto;
import com.example.hometop.dto.CustomerResponseDto;
import com.example.hometop.dto.CustomerUpdateDto;
import com.example.hometop.entity.Customer;
import com.example.hometop.enums.RatingType;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface CustomerService {
    //전체 회원 수 조회
    long countCustomers();

    //전체 회원 목록 조회
    List<CustomerResponseDto> findAllCustomers();

    //전체 회원 목록 페이지네이션 조회
    Page<CustomerResponseDto> findAllCustomers(Pageable pageable);

    /*회원 등록
    *   - 입력 : 클라이언트가 보낸 요청 데이터 (CustomerRequestDto)
    *   - 출력 : 저장 완료된 회원 정보 (CustomerResponseDto)--password등 민감 정보 제외
    * */
    CustomerResponseDto register(CustomerRequestDto requestDto);

    /* 특정 회원 한 명 조회
    *   URL 패턴과 파라미터 매핑
    *       - GET /customer/{id}
    *                  \|/ @PathVariable
    *         findCustomerById(Long id)
    * */
    CustomerResponseDto findCustomerById(long id);

    /* 회원 삭제
    *   - 해당 id의 회원을 DB에서 영구 삭제
    *   - 삭제 후 반환값 없음 (void)
    *   - 존재하지 않는 id 요청 시 NoSuchElementException 발생
    *
    *  왜 POST로 삭제하는가?
    *   - HTTP 규약에서 GET 요청은 부작용(Side effect)이 없어야 함
    *       - 웹 크롤러가 링크만 봐도 GET 요청 자동 전송 가능
    *       - 의도치 않게 데이터 삭제 위험
    *   - 데이터 변경(삭제 포함)은 반드시 POST 폼으로 처리
    *       - HTML 폼은 GET/POST만 지원하므로 POST /customer/{id}/delete 사용
    * */
    void deleteCustomer(Long id);

    /* 특정 회원 정보 수정
    *   - 수정 허용 필드 : customerName, age, occupation
    *   - 수정 불가 필드 : username, password, rating, reserves (각각 별도 프로세스 필요)
    *   - 더티 체킹(Dirty Checking) 활용 -> save() 호출 없이 자동 UPDATE
    * */
    CustomerResponseDto updateCustomer(Long id, CustomerUpdateDto updateDto);

    /*쿼리 메서드
    *   - username으로 회원 단건 조회
    * */
    List<CustomerResponseDto> findCustomerByUsername(String username);

    /*쿼리 메서드
        - username 부분 일치 검색
    * */
    List<CustomerResponseDto> findCustomersByUsernameContaining(String username);

    Page<CustomerResponseDto> findCustomersByUsernameContaining(String username, Pageable pageable);

    /*쿼리 메서드
        - 적립금이 기준 금액 이상인 회원 목록 조회
    * */
    List<CustomerResponseDto> findCustomersByReservesGreaterThanEqual(int reserves);
    Page<CustomerResponseDto> findCustomersByReservesGreaterThanEqual(int reserves, Pageable pageable);

    /*@Query JPQL
    *   - 등급 + 최소 적립금 복합 조건 조회
    * */
    List<CustomerResponseDto> findCustomersByRatingAndMinReserves(RatingType rating,
                                                                  int minReserves);
    Page<CustomerResponseDto> findCustomersByRatingAndMinReserves(RatingType rating,
                                                     int minReserves, Pageable pageable);

    /* Native Query
    * 이름 또는 직업으로 회원 통합 검색 */
    List<CustomerResponseDto> findCustomersByNameOrOccupation(String keyword);

    /* 엔티티를 반환하면 안 되는 이유
    *   - reviews는 LAZY -- 트랜잭션 내에서 아직 SELECT 하지 않은 상태
    *   - 메서드가 끝나면 트랜잭션 종료 -> 세션 닫힘
    *   - Controller가 이 엔티티를 View에 전달
    *   - View가 customer.reviews에 접근하는 순간 세션이 없어 터짐
    * */
    Customer findCustomerEntityById(long id);

    /*reviews 포함 DTO 반환 - 리뷰 페이지 전용 */
    CustomerResponseDto findCustomerByIdWithReviews(long id);

}
