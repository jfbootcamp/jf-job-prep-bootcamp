package com.example.hometop.controller;

import com.example.hometop.dto.CustomerRequestDto;
import com.example.hometop.dto.CustomerResponseDto;
import com.example.hometop.dto.CustomerUpdateDto;
import com.example.hometop.service.CustomerService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/*
    React(포트 5173) 전용 REST API
        - CustomerController와 역할 분리
            - CustomerController  -> @Controller  -> Thymeleaf HTML 반환 (기존유지)
            - CustomerRestController -> @RestController -> JSON 반환 (React 전용)

        - API 엔드 포인트
            - GET   /api/customers          -> 전체 회원 목록 JSON (탈퇴 회원 제외)

 */
@RestController
@RequestMapping("/api/customers")
@CrossOrigin(origins = "http://localhost:5173/")
@RequiredArgsConstructor
public class CustomerRestController {

    private final CustomerService customerService;

    @GetMapping
    public ResponseEntity<List<CustomerResponseDto>> getCustomers() {
        List<CustomerResponseDto> customers = customerService.findAllCustomers();
        return ResponseEntity.ok().body(customers);
    }

    /*
        PATCH   /api/customers/{id}
        회원 정보 일부 수정

        PUT -> 리소스 전체 교체 (전송 안 한 필드는 null 로 덮어씀)
        PATCH -> 전송된 필드만 수정 (나머지 필드는 기존 값 유지)

        React 전송 body
        {customerName, age, occupation, email, phone}

        @RequestBody : React가 JSON 으로 보낸 body를 CustomerResponseDto 로 변환
     */
    @PatchMapping("/{id}")
    public ResponseEntity<CustomerResponseDto> updateCustomer(
            @PathVariable Long id,
            @RequestBody CustomerUpdateDto updateDto) {
        CustomerResponseDto updated = customerService.updateCustomer(id, updateDto);
        return ResponseEntity.ok(updated);
    }


    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteCustomer(@PathVariable Long id) {
        customerService.deleteCustomer(id);
        return ResponseEntity.noContent().build();  // 204 No Content 반환
    }
}
