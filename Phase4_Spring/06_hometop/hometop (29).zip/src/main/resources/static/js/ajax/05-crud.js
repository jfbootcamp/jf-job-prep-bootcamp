/*
    currentEditId - 폼이 수정 모드인지 신규 등록 모드인지 구분하는 플래그
                  폼의 현재 모드를 결정하는 유일한 상태 변수
        null: 신규 등록 모드 (POST 요청) -> submitForm()
        true: 수정 모드 (PUT 요청)
 * */
let currentEditId = null;

/* submitForm() -- 폼 데이터를 서버에 전송 */
async function submitForm() {
    const payload = {
        name:       document.getElementById('fName').value.trim(),
        category:   document.getElementById('fCategory').value.trim(),
        price:      parseInt(document.getElementById('fPrice').value) || 0,
        quantity:   parseInt(document.getElementById('fQty').value) || 0,
    };

    if (!payload.name) {
        alert('이름을 입력하세요.');
        return;
    }

    const isEdit = currentEditId !== null;      /* null =  등록, 숫자 = 수정 */

    const url = isEdit ? `/api/items/${currentEditId}` : `/api/items`;      /*수정, 등록*/

    const result = document.getElementById('formResult');
    result.style.display = 'block';
    result.textContent = '저장 중...';

    try {
        const {data} = isEdit
            ? await axios.put(url, payload)         /* PUT /api/items/{id} - 수정 */
            : await axios.post(url, payload);       /* POST /api/items/ - 등록 */

        result.innerHTML =
            `<span>
                ${isEdit ? '200 수정 완료' : '200 등록 완료'}
             </span>
             ID: ${data.id} / ${data.name}    
            `;
        loadItems();

    } catch (e) {
        result.textContent = `오류: ${e.message}`;
    }
}

/* 아이템 목록 조회
*   encodeURIComponent(): 한글,특수문자를 URL-safe 문자열로 인코딩
* */
async function loadItems(keyword) {
    const url = keyword ? `/api/items?keyword=${encodeURIComponent(keyword)}`  /*검색어를 URL 인코딩 후 쿼리스트림에 추가*/
        : `/api/items`;     /*검색어 없으면 전체 목록 조회*/
    const tbody = document.getElementById('itemTbody');

    /*요청 중 로딩 테이블 본문에 표시*/
    tbody.innerHTML = `<tr><td colspan="6" style="text-align: center;"></td></tr>`;

    try {
        const {data: items} = await axios.get(url);
        renderTable(items);     /*파싱된 배열로 테이블 렌더링*/

    } catch (e) {
        tbody.innerHTML =
            `<tr><td colspan="6" style="text-align: center;">오류: ${e.message}</td></tr>`;
    }

}

function renderTable(items) {
    const tbody = document.getElementById('itemTbody');

    if (!items.length) {
        tbody.innerHTML =
            `<tr><td colspan="6" style="text-align: center;">
                                        검색 결과가 없습니다.</td></tr>`;
        return;
    }
    tbody.innerHTML = items.map((item) => `
        <tr>
            <td>${item.id}</td>
            <td>${item.name}</td>
            <td>${item.category}</td>
            <td>${item.price.toLocaleString()}원</td>
            <td>${item.quantity}</td>
            <td>
                <button onclick="startEdit(${item.id})">수정</button>
                <button onclick="deleteItem(${item.id})">삭제</button>
            </td>
        </tr>
    `).join('');        /*배열 --> 하나의 HTML 문자열로 병합*/
}

function searchItems() {

}

/*페이지 로드 시 전체 목록 조회*/
loadItems();
