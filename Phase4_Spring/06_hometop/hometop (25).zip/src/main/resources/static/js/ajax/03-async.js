/*
    fetchPost() - async/await 기본 패턴

        .then() 체이닝
            .then() -> 체이닝으로 연결, 들여쓰기 깊어짐
        async/await
            -> 동기 코드처럼 위에서 아래로 읽힘

    async 함수
        - 항상 Promise를 반환하는 함수
        - 호출부에서 await 또는 .then()으로 결과를 받을 수 있음.
    await
        - Promise가 완료(resolve)될 때까지 해당 줄에서 대기
        - async 함수 안에서만 사용 가능
* */
async function fetchPost() {
    const id = document.getElementById('postId').value || 1;
    const result = document.getElementById('postResult');

    result.innerHTML = `<span></span>요청 중....`;
    try {
        /*await fetch(url)
        *   fetch()는 즉시 Promise<Response>를 반환하고 백그라운에서 요청 전송
        *   await는 그 Promise가 완료될 때까지 이 줄에서 대기
        *   완료되면 Promise 객체를 response 변수에 담고 다음 줄로 이동
        *       - .then() 패턴과 동일하지만 들여쓰기 위->아래로 이동
        * */
        const response =
            await fetch(`https://jsonplaceholder.typicode.com/posts/${id}`);
        if (!response.ok) {
            /* fetch는 404, 500도 reject하지 않으므로 반드시 직접 확인
            *  throw하면 즉시 catch 블록으로 즉시 이동 */
            throw new Error(`HTTP 오류 - 상태코드: ${response.status}`);
        }
        /* response.json()도 Promise를 반환 -> await로 파싱 완료까지 대기
        *  완료되면 파싱된 JS 객체를 data 변수에 할당
        *  XHR의 JSON.parse(xhr.responseText)와 동일한 역할 */
        const data =  await response.json();

        result.innerHTML =
            `<span>200 ok</span><br><br>` +
            `<strong>ID:</strong> ${data.id}<br>` +         /*응답 객체의 id 필드*/
            `<strong>제목:</strong> ${data.title}<br>` +    /*응답 객체의 title 필드*/
            `<strong>내용:</strong> ${data.body}<br>`;     /*응답 객체의 body 필드*/
    } catch (error) {
        result.textContent = `오류: ${error.message}`;
    }
}

/*
*   fetchSequential() - 순차 실행 (느린 패턴)
*       await를 순서대로 두 번 사용하면
*       첫 번째 요청이 완전히 끝난 뒤에야 두 번째 요청이 시작됨
*       -> 총 소요 시간 = 요청1 시간 + 요청2 시간 (합산)
* */
async function fetchSequential() {
    const uid = document.getElementById('userId').value || 1;
    const result = document.getElementById('parallelResult');

    result.innerHTML = `<span></span>순차 실행 중....`;

    const start = Date.now();       /*요청 시작 시간 기록*/

    try {
        /* 순차 실행의 문제점
        *   - 첫번째 await: users 요청 전송 -> 응답 도착까지 대기
        * */
        const userRes =
            await fetch(`https://jsonplaceholder.typicode.com/users/${uid}`);
        const user = await userRes.json();  /* 파싱 완료까지 대기 -- 이 줄이 끝나야 아래로 이동*/
        /*  - 두번째 await: 위가 완전히 끝난 뒤에야 posts 요청 시작
        *     두 요청이 독립적임에도 불구하고 직렬로 처리됨 -> 비효율
        *  */
        const postsRes =
            await fetch(`https://jsonplaceholder.typicode.com/posts/?userId=${uid}`);
        const posts = await postsRes.json();   /*총 소요 시간 = 요청1 + 요청2*/

        const elapsed = Date.now() - start;     /*실제 소요 시간 계산 (ms)*/

        result.innerHTML =
            `<strong>순차 실행 결과: </strong><br>` +
            `사용자: ${user.name} / 게시물: ${posts.length}건<br>` +
            `<strong>소요 시간: ${elapsed}ms</strong>` +
            `<small style="color: red">두 요청을 하나씩 기다림 - 비효율적!</small>`
    } catch (error) {
        result.textContent = `오류: ${error.message}`;
    }
}

/*
* fetchParallel() - 병렬 실행 (빠른 패턴)
*   Promise.all([p1, p2]) : 배열 안의 모든 Promise를 동시에 시작
*       -> 총 소요 시간 = max(요청1 시간, 요청2 시간) <-- 합산이 아닌 최댓값
*       -> 하나라도 reject되면 전체가 즉시 catch로 이동
* */
async function fetchParallel() {

}