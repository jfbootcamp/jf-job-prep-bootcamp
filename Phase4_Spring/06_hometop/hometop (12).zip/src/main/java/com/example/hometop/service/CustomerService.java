package com.example.hometop.service;

import com.example.hometop.dto.CustomerRequestDto;
import com.example.hometop.dto.CustomerResponseDto;

import java.util.List;

public interface CustomerService {
    //전체 회원 수 조회
    long countCustomers();

    //전체 회원 목록 조회
    List<CustomerResponseDto> findAllCustomers();

    /*회원 등록
    *   - 입력 : 클라이언트가 보낸 요청 데이터 (CustomerRequestDto)
    *   - 출력 : 저장 완료된 회원 정보 (CustomerResponseDto)--password등 민감 정보 제외
    * */
    CustomerResponseDto register(CustomerRequestDto requestDto);

    /* 특정 회원 한 명 조회
    *   URL 패턴과 파라미터 매핑
    *       - GET /customer/{id}
    *                  \|/ @PathVariable
    *         findCustomerById(Long id)
    * */
    CustomerResponseDto findCustomerById(long id);

    /* 회원 삭제
    *   - 해당 id의 회원을 DB에서 영구 삭제
    *   - 삭제 후 반환값 없음 (void)
    *   - 존재하지 않는 id 요청 시 NoSuchElementException 발생
    *
    *  왜 POST로 삭제하는가?
    *   - HTTP 규약에서 GET 요청은 부작용(Side effect)이 없어야 함
    *       - 웹 크롤러가 링크만 봐도 GET 요청 자동 전송 가능
    *       - 의도치 않게 데이터 삭제 위험
    *   - 데이터 변경(삭제 포함)은 반드시 POST 폼으로 처리
    *       - HTML 폼은 GET/POST만 지원하므로 POST /customer/{id}/delete 사용
    * */
    void deleteCustomer(Long id);
}
