package com.example.hometop.config;

/*
*   개발용 시드 데이터 초기화 클래스
*       - CommandLineRunner: 앱 구동 완료 후 자동 실행
*       - @ConditionalOnProperty: application-dev.yaml의 플래그가 true일 때만 Bean 등록
*           -> false면 이 클래스 자체가 Spring 켄텍스트에 로드되지 않음 (비활성화 상태)
* */

import com.example.hometop.entity.Book;
import com.example.hometop.repository.BookRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

import java.util.List;

@Slf4j
@Component
@ConditionalOnProperty(name = "app.data.init.enabled", havingValue = "true")
@RequiredArgsConstructor
public class DataInitializer implements CommandLineRunner {

    private final BookRepository bookRepository;

    @Override
    public void run(String... args) throws Exception {
        // 이미 데이터가 있으면 중복 삽입하지 않음
        if (bookRepository.count() > 0) {
            log.info("[DataInitializer]이미 도서 데이터가 존재합니다. 시드 데이터 삽입을 건너뜁니다.");
            return;
        }

        // 샘플 도서 데이터 - Book.builder() 사용
        List<Book> sampleBooks = List.of(
                Book.builder()
                        .title("이게 되네? 제미나이 완전 미친 활용법 81제")
                        .author("오힘찬")
                        .price(21600)
                        .page(340)
                        .build(),
                Book.builder()
                        .title("혼자 공부하는 바이브 코딩 with 클로드 코드")
                        .author("조태호")
                        .price(27000)
                        .page(384)
                        .build(),
                Book.builder()
                        .title("제미나이 주식투자")
                        .author("조성호")
                        .price(18000)
                        .page(300)
                        .build(),
                Book.builder()
                        .title("AI, 신의 탄생 인간의 종말")
                        .author("엘리에저 유드코스키")
                        .price(19800)
                        .page(440)
                        .build(),
                Book.builder()
                        .title("클로드 코드를 활용한 바이브 코딩 완벽 입문")
                        .author("히라카와 토모히데")
                        .price(23400)
                        .page(324)
                        .build()
        );

        bookRepository.saveAll(sampleBooks);
        log.info("샘플 도서 {}권 삽입 완료.", sampleBooks.size());
    }
}
