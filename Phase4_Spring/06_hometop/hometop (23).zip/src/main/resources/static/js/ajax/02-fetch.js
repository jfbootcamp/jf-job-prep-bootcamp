/*
*   fetchOne() -- fetch() + .then() 체이닝으로 단건 조회
*
*   Promise 체이닝 순서
*      fetch(url)       -> Promise<Response> 반환
*       .then(response => ....)    -> HTTP 응답 객체 처리
*       .then(data => ....)        -> JSON 파싱 완료 후 데이터 사용
*       .catch(error => ....)      -> 네트워크 오류 또는 throw 처리
* */
function fetchOne() {
    const id = document.getElementById('singleId').value || 1;
    const result = document.getElementById('singleResult');  /*결과를 출력할 DOM 요소*/

    result.textContent = '요청 중....';

    fetch(`https://jsonplaceholder.typicode.com/posts/${id}`)
        /* 첫 번째 .then: HTTP 응답 객체(Response) 수신
        *  - 이 시점에서는 아직 body(JSON)가 파싱되지 않은 상태
        *  - response.ok: status 200~299이면 true 그외 false */
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP 오류 -- 상태코드: ${response.status}`); /* throw -> .catch()로 이동 */
            }
            return response.json(); /* body를 JSON으로 파싱 -> 또 다른 Promse 반환 */
        })
        .then(data => {
            result.innerHTML =
                `<span>200 OK</span><br><br>` +
                `<strong>ID:</strong> ${data.id}<br>` +
                `<strong>제목:</strong> ${data.title}<br>` +
                `<strong>내용:</strong> ${data.body}`;
        })
        .catch(error => {
            result.textContent = `오류: ${error.message}`;

        })
}