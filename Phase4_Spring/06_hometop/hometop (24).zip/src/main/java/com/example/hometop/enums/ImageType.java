package com.example.hometop.enums;

public enum ImageType {
    THUMBNAIL,    // 썸네일 이미지 - 목록/검색 결과에 노출되는 대표 이미지
    DETAIL,       // 상세 이미지 - 책 상세 페이지에 노출되는 본문 이미지
    BANNER        // 배너 이미지 - 메인 페이지 등 프로모션용 이미지
    // 이미지 유형이 추가되면 여기에 값을 추가함. 명칭으로 관리되므로 가독성,유지보수 유리함.
}
