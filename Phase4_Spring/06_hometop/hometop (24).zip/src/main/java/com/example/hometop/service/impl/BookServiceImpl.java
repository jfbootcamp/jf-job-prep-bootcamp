package com.example.hometop.service.impl;

import com.example.hometop.dto.BookResponseDto;
import com.example.hometop.entity.Book;
import com.example.hometop.repository.BookRepository;
import com.example.hometop.service.BookService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class BookServiceImpl implements BookService {

    // 도서 관련 DB 접근을 담당하는 Repository
    private final BookRepository bookRepository;

    /*
    *      bookRepository.findAll()
    *           --> List<Book> : DB에서 전체 도서 조회 (Entity 목록)
    *      .stream()
    *           --> Stream<Book> : 리스트를 스트림으로 변환 (파이프라인 처리 시작)
    *      .map(book -> BookResponseDto.from(book)) 으로 변환
    *      .map(BookResponseDto::from)
    *
    *      .collect(Collectors.toList())
    *
    * */
    @Override
    @Transactional(readOnly = true)   // 읽기 전용 트랜잭션 -> Hibernate 더티 체킹(변경 감지) 생략으로 성능 향상
    public List<BookResponseDto> findAllBooks() {
        return bookRepository.findAll() // DB 전체 조회 -> List<Book>
                .stream()  // 스트림 변환
                .map(BookResponseDto::from)  // Entity -> DTO 변환 (LAZY 컬렉션 접근 없음)
                .collect(Collectors.toList()); // 리스트로 수집 -> List<BookResponseDto>
    }
}
