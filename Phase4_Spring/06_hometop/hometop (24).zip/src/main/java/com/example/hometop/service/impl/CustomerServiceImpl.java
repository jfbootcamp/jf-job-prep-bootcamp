package com.example.hometop.service.impl;

import com.example.hometop.dto.CustomerRequestDto;
import com.example.hometop.dto.CustomerResponseDto;
import com.example.hometop.dto.CustomerUpdateDto;
import com.example.hometop.entity.Customer;
import com.example.hometop.enums.RatingType;
import com.example.hometop.repository.CustomerRepository;
import com.example.hometop.service.CustomerService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class CustomerServiceImpl implements CustomerService {

    // 회원 관련 DB 접근을 담당하는 Repository
    private final CustomerRepository customerRepository;

    @Override
    @Transactional(readOnly = true)
    public long countCustomers() {
        return customerRepository.count();
    }

    /* 전체 회원 목록 조회 */
    @Override
    @Transactional(readOnly = true)
    public List<CustomerResponseDto> findAllCustomers() {
        return customerRepository.findAll().stream() // List<CustomerResponseDto> -> Stream<CustomerResponseDto>
                .map(CustomerResponseDto::from)     // Customer --> CustomerResponseDto (from 메서드 레퍼런스)
                .collect(Collectors.toList());      // Stream<CustomerResponseDto> --> List<CustomerResponseDto>
    }

    @Override
    public CustomerResponseDto register(CustomerRequestDto requestDto) {
        // 1. DTO -> Entity (rating=BRONZE 고정, id는 DB가 자동 생성)
        Customer customer = requestDto.toEntity();
        // 2. DB 저장 (save() --> INSERT SQL 실행, 반환된 saved에 id가 채워짐
        Customer saved = customerRepository.save(customer);
        // 3. Entity -> ResponseDto (Password 등 민감 정보 제외하고 반환)
        return CustomerResponseDto.from(saved);
    }

    /*
    *    특정 회원 한 명 조회
    *       - 처리 흐름
    *
    *       Controller                  Service                 Repository
    *
    *       @PathVariable Long id ----> findCustomerById(id) ---> findById(id)
    *                                        |
    *                                        |
    *                                  Optional<Customer>
                                        orElseThrow(예외) <-- id 없으면 여기서 예외 발생
    * */
    @Override
    @Transactional(readOnly = true)
    public CustomerResponseDto findCustomerById(long id) {
        Customer customer = customerRepository.findById(id)
                .orElseThrow(() ->
                        new NoSuchElementException("회원을 찾을 수 없습니다. id= " + id));
        return CustomerResponseDto.from(customer);
    }

    /* 회원 삭제
    *   - deleteById(id) vs delete()
    *       - deleteById(id)
    *           - id만 넘기면 내부에서 findById() 후 delete() 호출
    * */
    @Override
    @Transactional
    public void deleteCustomer(Long id) {
        // 1) 존재 여부 확인
        Customer customer = customerRepository.findById(id)
                .orElseThrow(() -> new NoSuchElementException(
                        "회원을 찾을 수 없습니다. id=" + id));
        // 2) 삭제 -- @Transactional 커밋 시 DELETE SQL 실행
        customerRepository.delete(customer);
    }

    /* 특정 회원 정보 수정
    *   - 등록(register)과의 차이
    *       - 등록 : save()를 명시적으로 호출해야 INSERT 실행
    *       - 수정 : 영속 상태 Entity를 변경하면 커밋 시 자동 UPDATE (더디 채킹)
    *  */
    @Override
    @Transactional      // readOnly = false(기본값) --> 쓰기 트랜잭션
    public CustomerResponseDto updateCustomer(Long id, CustomerUpdateDto updateDto) {
        // 1) 영속성 컨텍스트에 Entity 로딩 (없으면 예외)
        Customer customer = customerRepository.findById(id)
                .orElseThrow(() ->
                     new NoSuchElementException("회원을 찾을 수 없습니다. id=" + id));
        // 2) Entity 필드 변경 -- save() 호출 없음
        customer.updateProfile(updateDto.getCustomerName(),
                                updateDto.getAge(),
                                updateDto.getOccupation());
        // 3) 메서드 종료시 @Transactional 커밋 -> JPA 더티 체킹 -> UPDATE 자동 실행
        return CustomerResponseDto.from(customer);
    }

    /* username으로 회원 단건 조회 */
    @Override
    @Transactional(readOnly = true)
    public List<CustomerResponseDto> findCustomerByUsername(String username) {
        return customerRepository.findByUsername(username) // Optional<Customer>
                .map(CustomerResponseDto::from) // Customer -> ResponseDto (값 있을 때만)
                .map(List::of)                  // ResponseDto -> List<ResponseDto> (1건짜리 리스트)
                .orElse(List.of());             // 값 없으면 -> 빈 리스트 반환

    }

    /* username 부분 일치 검색  */
    @Override
    public List<CustomerResponseDto> findCustomersByUsernameContaining(String username) {
        return customerRepository.findByUsernameContaining(username)
                .stream()
                .map(CustomerResponseDto::from)
                .collect(Collectors.toList());
    }

    /*
    *   적립금이 기준 금액 이상인 회원 목록 조회
    *       findByReservesGreaterThanEqual() 은 List<Customer> 반환
    *        --> stream()으로 순회하여 각 Customer를 CustomerResponseDto로 변환
    *        --> collect(toList())로 List<CustomerResponseDto> 수집
    * */
    @Override
    public List<CustomerResponseDto> findCustomersByReservesGreaterThanEqual(int reserves) {
        return customerRepository.findByReservesGreaterThanEqual(reserves)
                .stream()
                .map(CustomerResponseDto::from)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public List<CustomerResponseDto> findCustomersByRatingAndMinReserves(RatingType rating, int minReserves) {
        return customerRepository.findByRatingAndMinReserves(rating, minReserves)
                .stream()
                .map(CustomerResponseDto::from)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)     // 읽기 전용 트랜젝션
    public List<CustomerResponseDto> findCustomersByNameOrOccupation(String keyword) {
        String like = "%" + keyword + "%";
        return customerRepository.findByNameOrOccupationLike(like, like)
                .stream()
                .map(CustomerResponseDto::from)
                .collect(Collectors.toList());
    }

    /*  엔티티 반환
    * */
    @Override
    @Transactional(readOnly = true)
    public Customer findCustomerEntityById(long id) {
        return customerRepository.findById(id)
                .orElseThrow(() ->
                        new NoSuchElementException("회원을 찾을 수 없습니다. id =" + id));
    }

    @Override
    @Transactional(readOnly = true)
    public CustomerResponseDto findCustomerByIdWithReviews(long id) {
        Customer customer = customerRepository.findById(id)
                .orElseThrow(() -> new NoSuchElementException("회원을 찾을 수 없습니다. id=" + id));
        return CustomerResponseDto.fromWithReviews(customer);
    }
}
