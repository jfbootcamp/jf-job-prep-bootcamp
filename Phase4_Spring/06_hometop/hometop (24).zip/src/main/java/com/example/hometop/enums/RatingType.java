package com.example.hometop.enums;

public enum RatingType {
    BRONZE,         //일반 회원
    SILVER,         // 실버 회원
    GOLD,           // 골드 등급
    PLATINUM,       // 플래티넘 등급
    VIP             // 최우수 고객
}
