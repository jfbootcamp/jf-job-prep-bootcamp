package com.example.hometop.dto;

/*
    회원 수정 요청 Dto -- "수정 입력" 역할
       - Client --> [CustomerUpdateDto] --> Service --> Entity.updateProfile() --> DB
* */

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/*
*   Spring MVC의 @ModelAttribute 바인딩 동작 순서
*       1) @NoArgsConstructor로 빈 객체 생성
*       2) 폼에서 전송된 각 필드를 Setter로 채움
* */
@Getter
@Setter
@NoArgsConstructor
public class CustomerUpdateDto {
    private String customerName;
    private Integer age;
    private String occupation;
}
