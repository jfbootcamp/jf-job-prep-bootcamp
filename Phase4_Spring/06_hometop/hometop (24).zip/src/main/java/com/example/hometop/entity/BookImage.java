package com.example.hometop.entity;

import com.example.hometop.enums.ImageType;
import jakarta.persistence.*;
import lombok.*;

@Getter
@NoArgsConstructor(access = AccessLevel.PROTECTED)
@AllArgsConstructor(access = AccessLevel.PRIVATE)
@Builder
@Entity
@Table(name = "book_images")  // 테이블 명시. 복수형 사용 - 실무 관례
public class BookImage {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Enumerated(EnumType.STRING) // DB dp "THUMBNAIL" 같은 문자열로 저장함.
    @Column(nullable = false)
    private ImageType type;

    @Column(nullable = false)
    private String path;  // 이미지 파일 경로 또는 URL

    // 변경 메서드
    public void updateImage(ImageType type, String path){ //이미지 타입 및 경로 수정
        this.type = type;
        this.path = path;
    }

    // 이미지(N) : 책(1)
    @ManyToOne(fetch = FetchType.LAZY) // 기본값은 EAGER(즉시 로딩)임. EAGER 사용 시 BookImage 조회마다 Book까지 항상 조인 -> N + 1 문제 발생 위험. LAZY로 명시하여 실제 사용 시점에만 로딩함.
    @JoinColumn(name = "book_id", referencedColumnName = "id", nullable = false)  // FK
    private Book book;
}
