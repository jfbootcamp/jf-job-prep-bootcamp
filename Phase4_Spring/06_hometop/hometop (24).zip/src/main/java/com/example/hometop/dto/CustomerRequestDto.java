package com.example.hometop.dto;

import com.example.hometop.entity.Customer;
import com.example.hometop.enums.RatingType;
import lombok.*;

/*
*   회원 등록 요청 DTO -- "입력" 역할
*       Client --> CustomerRequestDto --> Service --> Entity --> DB
*
* */
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CustomerRequestDto {
    private String username;
    private String password;
    private String customerName;
    private Integer age;
    private String occupation;

    /* DTO --> Entity 변환 메서드
    *   - Service 레이어에서 호출하여 Entity로 변환 후 Repository에 전달
    * */
    public Customer toEntity() {
        return Customer.builder()
                .username(this.username)
                .password(this.password)
                .customerName(this.customerName)
                .age(this.age)
                .rating(RatingType.BRONZE)
                .occupation(this.occupation)
                .build();
    }
}
