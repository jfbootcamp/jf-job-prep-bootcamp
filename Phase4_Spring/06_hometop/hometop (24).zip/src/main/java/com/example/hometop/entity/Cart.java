package com.example.hometop.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;

@Getter
@NoArgsConstructor(access = AccessLevel.PROTECTED)
@AllArgsConstructor(access = AccessLevel.PRIVATE)
@Builder
@Entity
@Table(name = "carts")
public class Cart {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private Integer quantity;

    @Column(nullable = false, updatable = false)  // updatable = false <--- 장바구니 담은 시각은 최초 저장 후 변경 불가하도록 DB레벨에서 차단함.
    private LocalDateTime cartDate = LocalDateTime.now();

    public void updateQuantity(Integer quantity) {
        this.quantity = quantity;
    }

    //장바구니(N) : 고객(1)
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "customer_id", referencedColumnName = "id",
            nullable = false)
    private Customer customer;

    //장바구니(N) : 책(1)
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "book_id", referencedColumnName = "id", nullable = false)
    private Book book;
}
