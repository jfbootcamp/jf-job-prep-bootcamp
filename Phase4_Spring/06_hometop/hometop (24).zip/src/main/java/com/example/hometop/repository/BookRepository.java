package com.example.hometop.repository;

import com.example.hometop.entity.Book;
import org.springframework.data.jpa.repository.JpaRepository;

/*
*   도서관련 DB 접근을 담당하는 Repository
*   Book 엔티티, PK 타입 Long
*   - 기본 제공 메서드 : save() -> INSERT / UPDATE, findeAll() -> SELECT, findByid() -> SELECT by PK, delete() 등
*   - 커스텀 쿼리가 필요하면 @Query 추가, 명명 규칙 등
* */
public interface BookRepository extends JpaRepository<Book, Long> {
}
