package com.example.hometop.entity;


import jakarta.persistence.*;
import lombok.*;

import java.util.List;

@Getter
@NoArgsConstructor(access = AccessLevel.PROTECTED)      // JPA 스펙 상 기본 생성자 필수, PROTECTED로 외부 직접 생성 차단함.
@AllArgsConstructor(access = AccessLevel.PRIVATE)       // @Builder 내부 동작용 전체 생성자, PRIVATE으로 외부 노출 차단함.
@Builder  // id를 제외하고 필요한 필드만 선택적으로 주입 가능함. 예: Book.builder().title("AI의 미래").price(30000).build()
@Entity
@Table(name = "books")  // 테이블명 명시. 생략 시 클래스명 기반 자동 지정됨. 테이블명은 복수형 사용.
public class Book {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true, length = 45) // 필수값, 중복 불가-동일 제목의 책이 중복되는것을 방지함.
    private String title;

    @Column(nullable = false)
    private Integer price;

    @Column(nullable = false)
    private String author;

    @Column(nullable = false)
    private Integer page;

    // 변경 메서드. 메서드명에서 변경 목적이 명확히 드러남
    // 책 기본 정보 수정
    public void updateBookInfo(String title, Integer price, String author, Integer page) {
        this.title = title;
        this.price = price;
        this.author = author;
        this.page = page;
    }

    // 책(1) : 이미지(N)
    /*
        orphanRemoval = true
        [CascadeType.ALL]
          book 자체 삭제 시            -> image도 DB에서 삭제
          리스트에서만 제거할 때         -> image는 DB에 그대로 남음 (고아 데이터 발생)
        [orphanRemoval = true 추가 시]
          book 자체 삭제 시            -> image도 DB에서 삭제
          리스트에서만 제거할 때         -> image도 DB에서 삭제 (고아 데이터 방지)
     */
    // 책(1) : 이미지(N)
    @OneToMany(mappedBy = "book", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.LAZY)
    private List<BookImage> bookImages;

    // 책(1) : 리뷰(N)
    @OneToMany(mappedBy = "book", cascade = CascadeType.ALL, orphanRemoval = true,
                    fetch = FetchType.LAZY)
    private List<Review> reviews;

    // 책(1) : 장바구니(N)
    @OneToMany(mappedBy = "book", cascade = CascadeType.ALL, orphanRemoval = true,
                    fetch = FetchType.LAZY)
    private List<Cart> carts;


}
