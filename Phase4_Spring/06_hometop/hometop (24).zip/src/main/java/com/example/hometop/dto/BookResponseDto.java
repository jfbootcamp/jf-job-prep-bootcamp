package com.example.hometop.dto;

/*  포함 필드 선택 기준
        - 포함 O : id, title, author, price, page
            --> book/index.html 에서 실제로 사용하는 필드만 포함
        - 포함 X : reviews, bookImages, carts
            --> LAZY 컬렉션 -- 노출 시 LazyInitializationException 위험
            --> 도서 목록 화면에서 불필요한 데이터
*
* */

import com.example.hometop.entity.Book;
import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public class BookResponseDto {
    private Long id;
    private String title;
    private String author;
    private Integer price;
    private Integer page;

    /*  Entity --> DTO 변환 메서드 (정적 팩토리 메서드) */
    public static BookResponseDto from(Book book) {
        return BookResponseDto.builder()
                .id(book.getId())
                .title(book.getTitle())
                .author(book.getAuthor())
                .price(book.getPrice())
                .page(book.getPage())
                .build();
    }
}
