package com.example.hometop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HometopApplication {

	public static void main(String[] args) {
		SpringApplication.run(HometopApplication.class, args);
	}

}
