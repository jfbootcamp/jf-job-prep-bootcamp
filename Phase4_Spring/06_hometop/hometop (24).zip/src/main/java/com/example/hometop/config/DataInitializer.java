package com.example.hometop.config;

/*
*   개발용 시드 데이터 초기화 클래스
*       - CommandLineRunner: 앱 구동 완료 후 자동 실행
*       - @ConditionalOnProperty: application-dev.yaml의 플래그가 true일 때만 Bean 등록
*           -> false면 이 클래스 자체가 Spring 켄텍스트에 로드되지 않음 (비활성화 상태)
* */

import com.example.hometop.entity.Book;
import com.example.hometop.entity.Customer;
import com.example.hometop.entity.Review;
import com.example.hometop.enums.RatingType;
import com.example.hometop.repository.BookRepository;
import com.example.hometop.repository.CartRepository;
import com.example.hometop.repository.CustomerRepository;
import com.example.hometop.repository.ReviewRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

import java.util.List;

@Slf4j
@Component
@ConditionalOnProperty(name = "app.data.init.enabled", havingValue = "true")
@RequiredArgsConstructor
public class DataInitializer implements CommandLineRunner {

    private final BookRepository bookRepository;
    private final CustomerRepository customerRepository;
    private final CartRepository cartRepository;
    private final ReviewRepository reviewRepository;

    @Override
    public void run(String... args) throws Exception {
        initBooks();
        initCustomers();
        initReviewsAndCarts();  // 도서,회원 저장 완료 후 실행

    }

    private void initReviewsAndCarts() {
        // 이미 데이터가 있으면 중복 삽입하지 않음
        if (reviewRepository.count() > 0) {
            log.info("[DataInitializer]이미 리뷰 데이터가 존재합니다. 시드 데이터 삽입을 건너뜁니다.");
            return;
        }

        // 회원 조회 (FK 참조용)
        Customer hong = customerRepository.findByUsername("hong-gildong").orElseThrow();
        Customer choi = customerRepository.findByUsername("choi_minjun").orElseThrow();
        Customer kang = customerRepository.findByUsername("kang_daeun").orElseThrow();
        Customer yoon = customerRepository.findByUsername("yoon_sunho").orElseThrow();
        Customer vip = customerRepository.findByUsername("vip_master").orElseThrow();

        // 도서 조회 (FK 참조용)
        Book handsOn = bookRepository.findAll().stream().filter(b -> b.getTitle().equals("핸즈온 머신러닝")).findFirst().orElseThrow();
        Book dlScratch1 = bookRepository.findAll().stream().filter(b -> b.getTitle().equals("밑바닥부터 시작하는 딥러닝")).findFirst().orElseThrow();
        Book pythonML = bookRepository.findAll().stream().filter(b -> b.getTitle().equals("파이썬 머신러닝 완벽 가이드")).findFirst().orElseThrow();
        Book dlScratch2 = bookRepository.findAll().stream().filter(b -> b.getTitle().equals("밑바닥부터 시작하는 딥러닝 2")).findFirst().orElseThrow();
        Book keras = bookRepository.findAll().stream().filter(b -> b.getTitle().equals("케라스 창시자에게 배우는 딥러닝")).findFirst().orElseThrow();

        // 리뷰 시드 데이터
        /*
            핸즈온 머신러닝 - 3명 리뷰
            밑바닥부터 시작하는 딥러닝 - 2명 리뷰
            파이썬 머신러닝 완벽 가이드 - 3명 리뷰
            케라스 창시자에게 배우는 딥러닝 - 2명 리뷰
         */
        List<Review> reviews = List.of(
                // 핸즈온 머신러닝 (3건)
                Review.builder().cost(65000).content("머신러닝 전반을 가장 체계적으로 다룬 책입니다.").customer(hong).book(handsOn).build(),
                Review.builder().cost(65000).content("이론과 실습의 균형이 완벽합니다.").customer(hong).book(handsOn).build(),
                Review.builder().cost(65000).content("사이컷런과 텐서플로를 함께 배울 수 있어 좋습니다.").customer(hong).book(handsOn).build(),

                // 밑바닥부터 시작하는 딥러닝 (2건)
                Review.builder().cost(65000).content("수식 없이도 딥러닝 원리를 이해할 수 있습니다.").customer(choi).book(dlScratch1).build(),
                Review.builder().cost(65000).content("입문자에게 강력 추천하는 딥러닝 입문서입니다.").customer(choi).book(dlScratch1).build(),

                // 파이썬 머신러닝 완벽 가이드 (3건)
                Review.builder().cost(65000).content("캐글 실전 예제가 많아 실력 향상에 도움됩니다.").customer(kang).book(pythonML).build(),
                Review.builder().cost(65000).content("사이킷런 API를 가장 꼼꼼하게 설명한 책입니다.").customer(kang).book(pythonML).build(),
                Review.builder().cost(65000).content("데이터 전처리부터 모델 평가까지 완벽 커버합니다.").customer(kang).book(pythonML).build(),

                // 밑바닥부터 시작하는 딥러닝2 (2건)
                Review.builder().cost(65000).content("RNN과 어텐션 매키니즘을 직접 구현하며 배웁니다.").customer(yoon).book(dlScratch2).build(),
                Review.builder().cost(65000).content("1편보다 더 심층적인 내용을 다룹니다.").customer(yoon).book(dlScratch2).build(),

                // 케라스 창시자에게 배우는 딥러닝 (2건)
                Review.builder().cost(65000).content("카라스 창시자가 직접 쓴 만큼 설명이 명확합니다.").customer(vip).book(keras).build(),
                Review.builder().cost(65000).content("실용적인 딥러닝 프로젝트 예제가 풍부합니다.").customer(vip).book(keras).build()
                );
        reviewRepository.saveAll(reviews);
        log.info("[DataInitializer] 샘퓰 리뷰 {}건 삽입 완료", reviews.size());

    }

    private void initCustomers() {
        // 이미 데이터가 있으면 중복 삽입하지 않음
        if (customerRepository.count() > 0) {
            log.info("[DataInitializer]이미 회원 데이터가 존재합니다. 시드 데이터 삽입을 건너뜁니다.");
            return;
        }
        // BRONZE (6명) - 신규,일반 회원
        List<Customer> customers = List.of(

        Customer.builder()
                .username("hong-gildong")
                .password("pass1234")
                .customerName("홍길동")
                .age(28)
                .occupation("개발자")
                .rating(RatingType.BRONZE)
                .reserves(0)
                .build(),
        Customer.builder()
                .username("kim-jisu")
                .password("pass1234")
                .customerName("김지수")
                .age(22)
                .occupation("학생")
                .rating(RatingType.BRONZE)
                .reserves(500)
                .build(),
        Customer.builder()
                .username("park_young")
                .password("pass1234")
                .customerName("박영희")
                .age(35)
                .occupation("마케터")
                .rating(RatingType.BRONZE)
                .reserves(3000)
                .build(),
        Customer.builder()              // 선택 필드 전부 null - 최소정보로 가입한 케이스
                .username("newbie_01")
                .password("pass1234")
                .customerName(null)
                .age(null)
                .occupation(null)
                .rating(RatingType.BRONZE)
                .reserves(0)
                .build(),
        Customer.builder()
                .username("song_minji")
                .password("pass1234")
                .customerName("송민지")
                .age(19)
                .occupation("학생")
                .rating(RatingType.BRONZE)
                .reserves(1200)
                .build(),
        Customer.builder()
                .username("hong-sungil")
                .password("pass1234")
                .customerName("홍성일")
                .age(24)
                .occupation("대학원생")
                .rating(RatingType.BRONZE)
                .reserves(800)
                .build(),
        // SILVER (4명) - 중간 활동 회원
        Customer.builder()
                .username("lee_eungi")
                .password("pass1234")
                .customerName("이은지")
                .age(31)
                .occupation("디자이너")
                .rating(RatingType.SILVER)
                .reserves(18000)
                .build(),
        Customer.builder()
                .username("choi_minjun")
                .password("pass1234")
                .customerName("최민준")
                .age(29)
                .occupation("개발자")
                .rating(RatingType.SILVER)
                .reserves(32000)
                .build(),
        Customer.builder()
                .username("jang_teacher")
                .password("pass1234")
                .customerName("장수현")
                .age(42)
                .occupation("교사")
                .rating(RatingType.SILVER)
                .reserves(25000)
                .build(),
        Customer.builder()
                .username("anon_silver")
                .password("pass1234")
                .customerName(null)
                .age(38)
                .occupation("회사원")
                .rating(RatingType.SILVER)
                .reserves(11000)
                .build(),
        // GOLD (3명) - 우수 회원
        Customer.builder()
                .username("kang_daeun")
                .password("pass1234")
                .customerName("강다은")
                .age(38)
                .occupation("의사")
                .rating(RatingType.GOLD)
                .reserves(75000)
                .build(),
        Customer.builder()
                .username("yoon_sunho")
                .password("pass1234")
                .customerName("윤성호")
                .age(45)
                .occupation("자영업자")
                .rating(RatingType.GOLD)
                .reserves(120000)
                .build(),
        Customer.builder()
                .username("oh_jimin")
                .password("pass1234")
                .customerName("오지민")
                .age(33)
                .occupation("작가")
                .rating(RatingType.GOLD)
                .reserves(55000)
                .build(),
        // PLATINUM (2명) - 고급 회원
        Customer.builder()
                .username("seo_hajin")
                .password("pass1234")
                .customerName("서하준")
                .age(51)
                .occupation("변호사")
                .rating(RatingType.PLATINUM)
                .reserves(280000)
                .build(),
        Customer.builder()
                .username("lim_chaewon")
                .password("pass1234")
                .customerName("임채원")
                .age(44)
                .occupation("CTO")
                .rating(RatingType.PLATINUM)
                .reserves(450000)
                .build(),
        // VIP (1명) - 최우수 회원
        Customer.builder()
                .username("vip_master")
                .password("pass1234")
                .customerName("정우성")
                .age(48)
                .occupation("CEO")
                .rating(RatingType.VIP)
                .reserves(1500000)
                .build()
        );

        customerRepository.saveAll(customers);
        log.info("[DataInitializer] 샘플 회원 {}명 삽입 완료.", customers.size());
    }

    private void initBooks() {
        // 이미 데이터가 있으면 중복 삽입하지 않음
        if (bookRepository.count() > 0) {
            log.info("[DataInitializer]이미 도서 데이터가 존재합니다. 시드 데이터 삽입을 건너뜁니다.");
            return;
        }

        // 샘플 도서 데이터 - Book.builder() 사용
        List<Book> sampleBooks = List.of(
                Book.builder()
                        .title("핸즈온 머신러닝")
                        .author("오힘찬")
                        .price(21600)
                        .page(340)
                        .build(),
                Book.builder()
                        .title("밑바닥부터 시작하는 딥러닝")
                        .author("조태호")
                        .price(27000)
                        .page(384)
                        .build(),
                Book.builder()
                        .title("파이썬 머신러닝 완벽 가이드")
                        .author("조성호")
                        .price(18000)
                        .page(300)
                        .build(),
                Book.builder()
                        .title("케라스 창시자에게 배우는 딥러닝")
                        .author("엘리에저 유드코스키")
                        .price(19800)
                        .page(440)
                        .build(),
                Book.builder()
                        .title("밑바닥부터 시작하는 딥러닝 2")
                        .author("히라카와 토모히데")
                        .price(23400)
                        .page(324)
                        .build()
        );

        bookRepository.saveAll(sampleBooks);
        log.info("샘플 도서 {}권 삽입 완료.", sampleBooks.size());
    }
}
