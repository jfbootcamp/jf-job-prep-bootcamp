package com.example.hometop.dto;

import com.example.hometop.entity.Review;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;

@Getter
@Builder
public class ReviewResponseDto {
    private Long id;
    private Integer cost;       // 리뷰 작성 시 도서 가격
    private String content;     // 리뷰 본문
    private LocalDateTime createdAt;    // 리뷰 작성 시각
    private String customerName;        // 작성자 이름
    private String bookTitle;           // 도서 제목 - Book.title에서 추출
    private String bookAuthor;          // 도서 저자 - Book.author에서 추출

    public static ReviewResponseDto from(Review review) {
        String name = review.getCustomer().getCustomerName();
        if (name == null) {
            name = review.getCustomer().getUsername();
        }

        return ReviewResponseDto.builder()
                .id(review.getId())
                .cost(review.getCost())
                .content(review.getContent())
                .createdAt(review.getCreatedAt())
                .customerName(name)
                .bookTitle(review.getBook().getTitle())
                .bookAuthor(review.getBook().getAuthor())
                .build();
    }
}
