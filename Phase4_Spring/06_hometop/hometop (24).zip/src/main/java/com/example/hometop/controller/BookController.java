package com.example.hometop.controller;

import com.example.hometop.service.BookService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/book")
@RequiredArgsConstructor
public class BookController {

    // BookService 인터페이스 주입 -- Spring이 BookServiceImpl 빈을 자동 연결
    private final BookService bookService;

    // 도서 목록 페이지
    @GetMapping
    public String index(Model model) {
        model.addAttribute("books", bookService.findAllBooks());
        return "book/index";
    }
}
