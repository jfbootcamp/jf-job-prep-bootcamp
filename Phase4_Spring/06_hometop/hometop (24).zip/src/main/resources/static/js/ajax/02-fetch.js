/*
*   fetchOne() -- fetch() + .then() 체이닝으로 단건 조회
*
*   Promise 체이닝 순서
*      fetch(url)       -> Promise<Response> 반환
*       .then(response => ....)    -> HTTP 응답 객체 처리
*       .then(data => ....)        -> JSON 파싱 완료 후 데이터 사용
*       .catch(error => ....)      -> 네트워크 오류 또는 throw 처리
* */
function fetchOne() {
    const id = document.getElementById('singleId').value || 1;
    const result = document.getElementById('singleResult');  /*결과를 출력할 DOM 요소*/

    result.textContent = '요청 중....';

    /* fetch(url)
        - 브라우저 내장 함수, Promise<Response>를 반환
        - url: 요청할 엔드포인트
        - XHR과 달리 open()/send() 분리 없이 한 줄로 요청 전송
        - 반환값은 Promise -> .then()으로 체이닝하거나 대기
        - fetch는 네트워크 오류가 아닌 이상 404,500도 reject하지 않음
          -> 반드시 response.ok 또는 response.status를 직접 확인해야함.
    * */
    fetch(`https://jsonplaceholder.typicode.com/posts/${id}`)
        /* 첫 번째 .then: HTTP 응답 객체(Response) 수신
        *  - 이 시점에서는 아직 body(JSON)가 파싱되지 않은 상태
        *  - response.ok: status 200~299이면 true 그외 false */
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP 오류 -- 상태코드: ${response.status}`); /* throw -> .catch()로 이동 */
            }
            return response.json(); /* body를 JSON으로 파싱 -> 또 다른 Promse 반환 */
        })
        /* 두 번째 .then: 파싱 완료된 JS 객체 사용 */
        .then(data => {
            result.innerHTML =
                `<span>200 OK</span><br><br>` +
                `<strong>ID:</strong> ${data.id}<br>` +
                `<strong>제목:</strong> ${data.title}<br>` +
                `<strong>내용:</strong> ${data.body}`;
        })
        .catch(error => {
            result.textContent = `오류: ${error.message}`;

        })
}

/*
*   fetchList() -- 목록 조회
* */
function fetchList() {
    const result = document.getElementById('listResult');   /*결과를 출력할 DOM 요소*/

    fetch('http://jsonplaceholder.typicode.com/posts')
        .then(response => {
            if (!response.ok) throw new Error(`HTTP ${response.status}`);
            return response.json();
        })
        .then(data => {
            const top5 = data.slice(0, 5);  /*Array.slice(0, 5) - 배열 앞에서 5개만 추출*/
            result.innerHTML = top5.map(p =>
                `<div style="margin-bottom: 8px;padding-bottom: 8px;border-bottom: 1px solid #e2e8f0">
                    <strong>#${p.id}</strong>${p.title}
                </div>`
            ).join('') + `<small style="color: blue">전체 ${data.length}건 중 총 5건 표시</small>`
        })
        .catch(error => {
            result.textContent = `오류: ${error.message}`;
        });
}

