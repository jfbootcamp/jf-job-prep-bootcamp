/*
*   readyState 이름 매핑 배열
*   인덱스 = readyState 값 (0~4)
*   화면에 숫자 대신 의미 있는 이름으로 표시하기 위해 사용
* */
const STATE_NAMES = ['UNSENT', 'OPENED', 'HEADERS_RECEIVED', 'LOADING', 'DONE']
/* open() 호출전, open() 호출 완료,  응답 헤더 수신, 응답 body 수신 중, 완료  */
/*
*   XMLHttpRequest로 데이터 조회
*       - XHR 사용 순서
*           - 1. new XMLHttpRequest()           객체 생성
*           - 2. xhr.open()                     요청 설정 (메서드, URL,비동기 여부)
*           - 3. onreadystatechange             상태 변화 콜백 등록
*           - 4. xhr.send()                     요청 전송
* */
function fetchWithXHR() {
    const id = document.getElementById('postId').value || 1;        /*입력값이 없으면 기본값 1 사용*/
    const url = `https://jsonplaceholder.typicode.com/posts/${id}`  /*서버 주소*/
    const stateLog = document.getElementById('stateLog');   /*readyState 변화 로그를 출력할 요소*/
    const result = document.getElementById('xhrResult');    /*최종 응답 데이터를 출력할 요소*/

    /*이전 결과 초기화*/
    stateLog.textContent = '';          /*이전 readyState 로그 지우기*/
    result.textContent = '요청 중...';

    /*Step 1: XHR 객체 생성*/
    const xhr = new XMLHttpRequest();       /* HTTP 요청을 만들고 전송하는 브라우저 내장객체
                                                     - responseText : 서버가 보낸 응답 문자열  */
    /*Step 2: 상태 변화 콜백 등록 */
    xhr.onreadystatechange = function () {
        const line = `readyState ${xhr.readyState} -> ${STATE_NAMES[xhr.readyState]}\n`;
        stateLog.textContent += line;

        /*readState === 4 : 요청 완료 */
        if (xhr.readyState === 4) {
            if (xhr.status === 200) {
                const data = JSON.parse(xhr.responseText);  // responseText(문자열) -> JS 객체로 변환
                result.innerHTML =
                    `<strong>ID: </strong> ${data.id}<br>` +
                    `<strong>제목: </strong> ${data.title}<br>` +
                    `<strong>내용: </strong> ${data.body}`
            } else {
                /*요청 실패 (404, 500등)*/
                result.textContent = `오류 발생 - HTTP ${xhr.status}`;
            }
        }
    };

    xhr.onerror = function () {
        result.textContent = '네트워크 오류 - 인터넷 연결을 확인하세요.';
    }

    /*Step 3: 요청 설정
    * open(메서드, url, 비동기여부)
    *   - 세번째 인자 true = 비동기
    * */
    xhr.open('GET', url, true);

    /*Step 4: 요청 전송
    *   GET 요청이므로 body 없음 --> send() 에 인자 없음
    *   POST라면 send(JSON.stringify(data)) 처럼 body 전달
    * */
    xhr.send();
}