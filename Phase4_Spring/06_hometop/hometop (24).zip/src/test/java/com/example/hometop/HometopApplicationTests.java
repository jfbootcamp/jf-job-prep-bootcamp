package com.example.hometop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HometopApplicationTests {

	@Test
	void contextLoads() {
	}

}
