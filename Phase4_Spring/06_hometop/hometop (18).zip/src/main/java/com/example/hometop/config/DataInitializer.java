package com.example.hometop.config;

/*
*   개발용 시드 데이터 초기화 클래스
*       - CommandLineRunner: 앱 구동 완료 후 자동 실행
*       - @ConditionalOnProperty: application-dev.yaml의 플래그가 true일 때만 Bean 등록
*           -> false면 이 클래스 자체가 Spring 켄텍스트에 로드되지 않음 (비활성화 상태)
* */

import com.example.hometop.entity.Book;
import com.example.hometop.entity.Customer;
import com.example.hometop.enums.RatingType;
import com.example.hometop.repository.BookRepository;
import com.example.hometop.repository.CartRepository;
import com.example.hometop.repository.CustomerRepository;
import com.example.hometop.repository.ReviewRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

import java.util.List;

@Slf4j
@Component
@ConditionalOnProperty(name = "app.data.init.enabled", havingValue = "true")
@RequiredArgsConstructor
public class DataInitializer implements CommandLineRunner {

    private final BookRepository bookRepository;
    private final CustomerRepository customerRepository;
    private final CartRepository cartRepository;
    private final ReviewRepository reviewRepository;

    @Override
    public void run(String... args) throws Exception {
        initBooks();
        initCustomers();
        initReviewsAndCarts();  // 도서,회원 저장 완료 후 실행

    }

    private void initReviewsAndCarts() {
        // 이미 데이터가 있으면 중복 삽입하지 않음
        if (reviewRepository.count() > 0) {
            log.info("[DataInitializer]이미 리뷰 데이터가 존재합니다. 시드 데이터 삽입을 건너뜁니다.");
            return;
        }

        // 회원 조회 (FK 참조용)
        Customer hong = customerRepository.findByUsername("hong-gildong").orElseThrow();
        Customer choi = customerRepository.findByUsername("choi_minjun").orElseThrow();
        Customer kang = customerRepository.findByUsername("kang_daeun").orElseThrow();
        Customer yoon = customerRepository.findByUsername("yoon_sunho").orElseThrow();
        Customer vip = customerRepository.findByUsername("vip_master").orElseThrow();

        // 리뷰 시드 데이터

    }

    private void initCustomers() {
        // 이미 데이터가 있으면 중복 삽입하지 않음
        if (customerRepository.count() > 0) {
            log.info("[DataInitializer]이미 회원 데이터가 존재합니다. 시드 데이터 삽입을 건너뜁니다.");
            return;
        }
        // BRONZE (6명) - 신규,일반 회원
        List<Customer> customers = List.of(

        Customer.builder()
                .username("hong-gildong")
                .password("pass1234")
                .customerName("홍길동")
                .age(28)
                .occupation("개발자")
                .rating(RatingType.BRONZE)
                .reserves(0)
                .build(),
        Customer.builder()
                .username("kim-jisu")
                .password("pass1234")
                .customerName("김지수")
                .age(22)
                .occupation("학생")
                .rating(RatingType.BRONZE)
                .reserves(500)
                .build(),
        Customer.builder()
                .username("park_young")
                .password("pass1234")
                .customerName("박영희")
                .age(35)
                .occupation("마케터")
                .rating(RatingType.BRONZE)
                .reserves(3000)
                .build(),
        Customer.builder()              // 선택 필드 전부 null - 최소정보로 가입한 케이스
                .username("newbie_01")
                .password("pass1234")
                .customerName(null)
                .age(null)
                .occupation(null)
                .rating(RatingType.BRONZE)
                .reserves(0)
                .build(),
        Customer.builder()
                .username("song_minji")
                .password("pass1234")
                .customerName("송민지")
                .age(19)
                .occupation("학생")
                .rating(RatingType.BRONZE)
                .reserves(1200)
                .build(),
        Customer.builder()
                .username("hong-sungil")
                .password("pass1234")
                .customerName("홍성일")
                .age(24)
                .occupation("대학원생")
                .rating(RatingType.BRONZE)
                .reserves(800)
                .build(),
        // SILVER (4명) - 중간 활동 회원
        Customer.builder()
                .username("lee_eungi")
                .password("pass1234")
                .customerName("이은지")
                .age(31)
                .occupation("디자이너")
                .rating(RatingType.SILVER)
                .reserves(18000)
                .build(),
        Customer.builder()
                .username("choi_minjun")
                .password("pass1234")
                .customerName("최민준")
                .age(29)
                .occupation("개발자")
                .rating(RatingType.SILVER)
                .reserves(32000)
                .build(),
        Customer.builder()
                .username("jang_teacher")
                .password("pass1234")
                .customerName("장수현")
                .age(42)
                .occupation("교사")
                .rating(RatingType.SILVER)
                .reserves(25000)
                .build(),
        Customer.builder()
                .username("anon_silver")
                .password("pass1234")
                .customerName(null)
                .age(38)
                .occupation("회사원")
                .rating(RatingType.SILVER)
                .reserves(11000)
                .build(),
        // GOLD (3명) - 우수 회원
        Customer.builder()
                .username("kang_daeun")
                .password("pass1234")
                .customerName("강다은")
                .age(38)
                .occupation("의사")
                .rating(RatingType.GOLD)
                .reserves(75000)
                .build(),
        Customer.builder()
                .username("yoon_sunho")
                .password("pass1234")
                .customerName("윤성호")
                .age(45)
                .occupation("자영업자")
                .rating(RatingType.GOLD)
                .reserves(120000)
                .build(),
        Customer.builder()
                .username("oh_jimin")
                .password("pass1234")
                .customerName("오지민")
                .age(33)
                .occupation("작가")
                .rating(RatingType.GOLD)
                .reserves(55000)
                .build(),
        // PLATINUM (2명) - 고급 회원
        Customer.builder()
                .username("seo_hajin")
                .password("pass1234")
                .customerName("서하준")
                .age(51)
                .occupation("변호사")
                .rating(RatingType.PLATINUM)
                .reserves(280000)
                .build(),
        Customer.builder()
                .username("lim_chaewon")
                .password("pass1234")
                .customerName("임채원")
                .age(44)
                .occupation("CTO")
                .rating(RatingType.PLATINUM)
                .reserves(450000)
                .build(),
        // VIP (1명) - 최우수 회원
        Customer.builder()
                .username("vip_master")
                .password("pass1234")
                .customerName("정우성")
                .age(48)
                .occupation("CEO")
                .rating(RatingType.VIP)
                .reserves(1500000)
                .build()
        );

        customerRepository.saveAll(customers);
        log.info("[DataInitializer] 샘플 회원 {}명 삽입 완료.", customers.size());
    }

    private void initBooks() {
        // 이미 데이터가 있으면 중복 삽입하지 않음
        if (bookRepository.count() > 0) {
            log.info("[DataInitializer]이미 도서 데이터가 존재합니다. 시드 데이터 삽입을 건너뜁니다.");
            return;
        }

        // 샘플 도서 데이터 - Book.builder() 사용
        List<Book> sampleBooks = List.of(
                Book.builder()
                        .title("이게 되네? 제미나이 완전 미친 활용법 81제")
                        .author("오힘찬")
                        .price(21600)
                        .page(340)
                        .build(),
                Book.builder()
                        .title("혼자 공부하는 바이브 코딩 with 클로드 코드")
                        .author("조태호")
                        .price(27000)
                        .page(384)
                        .build(),
                Book.builder()
                        .title("제미나이 주식투자")
                        .author("조성호")
                        .price(18000)
                        .page(300)
                        .build(),
                Book.builder()
                        .title("AI, 신의 탄생 인간의 종말")
                        .author("엘리에저 유드코스키")
                        .price(19800)
                        .page(440)
                        .build(),
                Book.builder()
                        .title("클로드 코드를 활용한 바이브 코딩 완벽 입문")
                        .author("히라카와 토모히데")
                        .price(23400)
                        .page(324)
                        .build()
        );

        bookRepository.saveAll(sampleBooks);
        log.info("샘플 도서 {}권 삽입 완료.", sampleBooks.size());
    }
}
