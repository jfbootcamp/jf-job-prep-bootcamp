/*
*   회원 목록 - 검색 폼 제어
*       - searchForm 이 없는 페이지(홈) 에서는 동작하지 않음(null 체크)
* */
const searchForm = document.getElementById('searchForm');
const searchType = document.getElementById('searchType');  // 검색 유형 select
const ratingSelect = document.getElementById('ratingSelect'); // 등급 select
const keywordInput = document.getElementById('keywordInput');  // 검색어 input

/* 검색 유형별 placeholder 안내 메시지 */
const placeholderMap = {
    ''                      : '예) 아이디: hong',
    'username'              : '예) hong (부분 일치 - 쿼리 메서드)',
    'minReserves'           : '예) 10000 (이 금액 이상 - 쿼리 메서드)',
    'ratingAndMinReserves'  : '예) 10000 (등급 선택 + 최소 적립금 - JPQL @Query)',
}

function onSearchTypeChange() {
    const type = searchType.value;

    // searchType이 ratingAndMinReserves로 바뀔 때 inline-block으로 표시,
    // 다른 유형으로 바뀌면 다시 none으로 숨김
    if (ratingSelect) {
        ratingSelect.style.display = (type === 'ratingAndMinReserves') ?
            'inline-block' : 'none';
    }

    // placeholder 동적 변경 - 선택 유형에 맞는 안내 메시지로 교체
    if (keywordInput) {
        keywordInput.placeholder = placeholderMap[type] || placeholderMap[''];
    }
}

if (searchType) {
    onSearchTypeChange();
    // 검색 유형 변경 시 - select 표시/숨김, placeholder 변경
    searchType.addEventListener('change', onSearchTypeChange);
}

/* 검색 폼 유효성 검사 */
console.log('[searchForm 찾기]', searchForm);
if (searchForm) {
    searchForm.addEventListener('submit', function(event) {
        const type = searchType ? searchType.value : '';
        const kw = keywordInput ? keywordInput.value.trim() : '';
        console.log(`[submit 발생] type: `, type);

        // ratingAndMinReserves - 등급 select + keyword 둘 다 필요
        if (type === 'ratingAndMinReserves') {
            if (kw === '') {
                alert('최소 적립금을 입력해 주세요. (예: 10000)');
                event.preventDefault(); // 폼 제출 중단 -- 서버에 GET 요청을 보내지 않음
            }
            return;     // 등급은 select이므로 항상 선택값 존재
        }

        // 공통 유효성 검사
        if (type === '' && kw === '') {
            alert('검색 유형과 검색어를 입력해 주세요.');
            event.preventDefault();     // 폼 제출 중단 -- 서버에 GET 요청을 보내지 않음
        } else if (type === '' && kw !== '') {
            alert('검색 유형을 먼저 선택해 주세요.');
            event.preventDefault();
        } else if (type !== '' && kw === '') {
            alert('검색어를 입력해 주세요.')
            event.preventDefault();
        }

    });


}