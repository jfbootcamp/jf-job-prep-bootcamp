package com.example.hometop.entity;

import com.example.hometop.enums.RatingType;
import jakarta.persistence.*;
import lombok.*;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;

import java.time.LocalDateTime;
import java.util.List;

@Getter
@NoArgsConstructor(access = AccessLevel.PROTECTED)
@AllArgsConstructor(access = AccessLevel.PRIVATE)
@Builder
@Entity
@Table(name = "customers")  // 테이블명은 복수형 사용
public class Customer {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true)
    private String username;

    @Column(nullable = false)
    private String password;

    private String customerName;

    private Integer age;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private RatingType rating = RatingType.BRONZE;  // 신규 가입시 최하위 등급으로 시작

    private String occupation;

    private Integer reserves = 0;

    @Column(unique = true)  // 이메일 중복 방지 -- 다른 회원이 동일 이메일 사용 불가
    private String email;

    private String phone;

    /* soft delete field
    *   deletedAt = null            -> 정상 회원 (조회 대상)
    *   deletedAt = 탈퇴 시각        -> 탈퇴 회원 (일반 조회에서 제외)
    *       - DB에서 행(row)을 실제로 지우지 않아 탈퇴 이력 보존, 복구 가능
    * */
    private LocalDateTime deletedAt;

    // 회원 등록 시각 (최초 INSERT 시 자동 저장, 이후 변경 불가)
    @CreatedDate
    @Column(updatable = false)  // updatable = false : Update시 이 컬럼은 절대 변경 안됨
    private  LocalDateTime createdAt;

    // 마지막 수정 시각 (INSERT/UPDATE 시마다 자동 갱신)
    @LastModifiedDate       // INSERT/UPDATE 시마다 현재 시각으로 자동 갱신
    private LocalDateTime updatedAt;

    // 변경 메서드
    public void changePassword(String endcodedPassword) {
        this.password = endcodedPassword;
    }

    public void updateProfile(String customerName, Integer age, String occupation,
                              String email, String phone) {
        this.customerName = customerName;
        this.age = age;
        this.occupation = occupation;
        this.email = email;
        this.phone = phone;
    }

    public void updateRating(RatingType rating) {
        this.rating = rating;
    }

    public void addReserves(Integer amount) {
        this.reserves += amount;
    }

    // 소프트 딜리트 메서드
    /* 탈퇴 처리 - deletedAt에 현재 시각 설정 */
    public void delete() {
        this.deletedAt = LocalDateTime.now();
    }

    /*복구 처리
    *   - 탈퇴 회원을 다시 정상 회원으로 전환 (관리자용)*/
    public void restore() {
        this.deletedAt = null;
    }

    // 고객(1) : 장바구니(N)
    @OneToMany(mappedBy = "customer", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.LAZY)
    private List<Cart> carts;

    // 고객(1) : 리뷰(N)
    @OneToMany(mappedBy = "customer", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.LAZY)
    private List<Review> reviews;

}
