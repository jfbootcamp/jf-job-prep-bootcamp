package com.example.hometop.dto;

/*
*   회원 응답 DTO -- "출력" 역할
*       -    Client   <-- [CustomerResponseDto]    <--  Service   <--  Entity   <--  DB
*       - Entity를 그대로 반환하면 엔티티 필드들까지 직렬화될 수 있으므로
*         응답 전용 DTO로 분리함.
*       - from() 정적 팩토리 메서드로 Entity -> DTO 변환 (내부에 캡슐화)
* */

import com.example.hometop.entity.Customer;
import com.example.hometop.enums.RatingType;
import lombok.Builder;
import lombok.Getter;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Getter
@Builder
public class CustomerResponseDto {

    private Long id;
    private String username;
    private String customerName;
    private Integer age;
    private RatingType rating;
    private String occupation;
    private Integer reserves;

    // 감사(Audit) 필드
    /* 누가, 언제 데이터를 건드렸는지 기록을 남김
    *  개발자가 직접 코드를 작성할 필요 없음 */
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    private String email;
    private String phone;

    // reviews 필드 추가
    private List<ReviewResponseDto> reviews;

    /* Entity --> DTO 변환 메서드 (정적 팩토리 메서드) */
    public static CustomerResponseDto from(Customer customer) {
        return CustomerResponseDto.builder()
                .id(customer.getId())
                .username(customer.getUsername())
                .customerName(customer.getCustomerName())
                .age(customer.getAge())
                .rating(customer.getRating())
                .occupation(customer.getOccupation())
                // null 방어: DB에 NULL 저장된 경우 0으로 기본값 처리
                .reserves(customer.getReserves() != null ? customer.getReserves() : 0)
                .createdAt(customer.getCreatedAt())
                .updatedAt(customer.getUpdatedAt())
                .email(customer.getEmail())
                .phone(customer.getPhone())
                .build();

    }

    /* reviews 포함 변환 -- 리뷰 페이지 전용 */
    public static CustomerResponseDto fromWithReviews(Customer customer) {
        return CustomerResponseDto.builder()
                .id(customer.getId())
                .username(customer.getUsername())
                .customerName(customer.getCustomerName())
                .age(customer.getAge())
                .rating(customer.getRating())
                .occupation(customer.getOccupation())
                .reserves(customer.getReserves())
                .reviews(customer.getReviews().stream()
                        .map(ReviewResponseDto::from)
                        .collect(Collectors.toList()))
                .build();
    }
}
