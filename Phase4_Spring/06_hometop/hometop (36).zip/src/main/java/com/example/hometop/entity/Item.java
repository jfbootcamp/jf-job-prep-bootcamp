package com.example.hometop.entity;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Item {
    private Long id;
    private String name;
    private int quantity;
    private int price;
    private String category;
    private String description;
}
