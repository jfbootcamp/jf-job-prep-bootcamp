package com.example.hometop.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

/*
    메인(인트로) 페이지 (/)
     - 서비스 소개 화면만 반환 -> DB 조회 불필요
     - 도서 목록은 BookController가 담당
 */
@Controller
@RequestMapping("/")
public class MainController {

    @GetMapping
    public String index() {
        // 조회할 데이터 없음 -- Model 파라미터도 불필요
        return "index";
    }

    @GetMapping("/ajax")
    public String ajaxHub() {
        return "ajax/hub";
    }

    @GetMapping("/ajax/01")
    public String ajax01() {
        return "ajax/01-xhr";
    }

    @GetMapping("/ajax/02")
    public String ajax02() {
        return "ajax/02-fetch";
    }

    @GetMapping("/ajax/03")
    public String ajax03() {
        return "ajax/03-async";
    }

    @GetMapping("/ajax/04")
    public String ajax04() {
        return "ajax/04-axios";
    }

    @GetMapping("/ajax/05")
    public String ajax05() {
        return "ajax/05-crud";
    }
}
