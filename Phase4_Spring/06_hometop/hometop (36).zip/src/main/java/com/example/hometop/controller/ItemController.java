package com.example.hometop.controller;

import com.example.hometop.entity.Item;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/items")
public class ItemController {
    /*인메모리 저장소 - DB 대신 JVM 메모리 안의 List를 사용*/
    private static final List<Item> items = new ArrayList<>();
    private static long nextId = 1L;

    static {
        items.add(new Item(nextId++, "사과", 50, 1500,
                "과일", "국내 사과, 아삭하고 달콤합니다."));
        items.add(new Item(nextId++, "바나나", 30, 800,
                "과일", "수입 바나나, 당도가 높습니다."));
        items.add(new Item(nextId++, "오렌지", 20, 2000,
                "과일", "미국산 네이블 오렌지입니다."));
        items.add(new Item(nextId++, "우유", 40, 2500,
                "과일", "서울우유 1L 팩입니다."));
        items.add(new Item(nextId++, "식빵", 25, 3200,
                "과일", "부드러운 식빵, 유통기한 3일."));
    }

    /*
    *   전체 조회 - GET /api/items
    * */
    @GetMapping
    public ResponseEntity<List<Item>> getAll(
            @RequestParam(required = false) String keyword
    ) {
        if (keyword != null && !keyword.isBlank()) {
            // 대소문자 구분 없이 검색하기 위해 양쪽을 모두 소문자로 변환
            String kw = keyword.toLowerCase();

            /*Strean.filter() : 람다식 조건에 맞는 아이템만 남김 */
            List<Item> filtered = items.stream()
                    .filter(i -> i.getName().toLowerCase().contains(kw)
                            || i.getCategory().toLowerCase().contains(kw))
                    .collect(Collectors.toList());
            return ResponseEntity.ok(filtered);     // 200 ok + 필터링된 목록
        }
        return ResponseEntity.ok(new ArrayList<>(items));
    }

    /*
    *   단건 조회 - GET /api/items/{id}
    * */
    @GetMapping("/{id}")
    public ResponseEntity<Item> getById(@PathVariable Long id) {
        return items.stream()
                .filter(i -> i.getId().equals(id))  // ID가 일치하는 아이템 필터링
                .findFirst()            // Optional<Item> - 첫번째 일치 항목
                .map(ResponseEntity::ok)    // 있으면: 200 ok + 아이템
                .orElse(ResponseEntity.notFound().build());  // 없으면 : 404 Not Found (body 없음)

    }


    /*등록 - POST /api/items -> 201 Created 반환 */
    @PostMapping
    public ResponseEntity<Item> create(@RequestBody Item item) {   // JSON -> Item 파싱
        item.setId(nextId++);       // 서버에서 ID 부여
        items.add(item);
        return ResponseEntity.status(HttpStatus.CREATED).body(item);  // 201 Created + 생성된 아이템
    }

    /*
        수정 - PUT /api/items/{id}  --> 존재하지 않으면 404

            PUT     : 리소스 전체 교체 -- 보내지 않은 필드는 null/기본값 덮어씀
                      여기서는 폼의 모든 필드를 한 번에 전송하므로 PUT 사용
            PATCH   : 리소스 일부 수정 -- 보낸 필드만 업데이트
    * */
    @PutMapping({"/{id}"})
    public ResponseEntity<Item> update(@PathVariable Long id,
                                       @RequestBody Item updated) { // 수정할 데이터 (JSON -> Item)
        for (int i = 0; i < items.size(); i++) {
            if (items.get(i).getId().equals(id)) {  // ID로 위치 탐색
                updated.setId(id);      // URL 경로의 id로 강제 설정
                items.set(i, updated);  // 해당 위치의 아이템을 새 객체로 교체
                return ResponseEntity.ok(updated);  // 수정된 아이템 200 ok
            }
        }
        return ResponseEntity.notFound().build();   // 404 Not Found - 해당 ID 없음
    }

    /*
    *   삭제 - DELETE /api/items/{id}
    *       - 성공시 204 No Content, 없으면 404
    *   List.removeIf()
    *       - 조건에 맞는 요소를 List에서 직접 제거
    *       - 전통적인 for 루프 +  remove(i) 방식보다 간결
    *   ResponseEntity<Void>
            - Void: 응답 body가 없음 명시하는 타입
            * 204 No Content : body를 포함하지 않는 것
    * */
    @DeleteMapping("{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        boolean removed = items.removeIf(i -> i.getId().equals(id));
        return removed
                ? ResponseEntity.noContent().build()        // 204 - 삭제 성공
                : ResponseEntity.notFound().build();        // 404 - 해당 ID 없음
    }
}
