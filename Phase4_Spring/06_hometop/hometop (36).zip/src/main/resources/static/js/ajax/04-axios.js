/*
*   axiosGet() -- axios.get()으로 단건 조회
* */
async function axiosGet() {
    const id = document.getElementById('postId').value || 1;
    const result = document.getElementById('getResult');

    result.innerHTML = `<span></span>요청 중....`;

    try {
        /*axios.get(url)  -- get 요청
            - 내부적 fetch 또는 XHR을 래핑한 라이브러리
            - 반환값: Promise<AxiosResponse>
            - 구조분해: {data, status} 로 필요한 필드만 추출
                - data : 서버 응답 body가 자동으로 JS 객체로 파싱된 결과
                - status : HTTP 상태 코드 숫자 (예: 200)
        *
        * */
        const { data, status } =
            await axios.get(`https://jsonplaceholder.typicode.com/posts/${id}`);

        result.innerHTML =
            `<span>${status} ok</span><br><br>` +
            `<strong>ID:</strong> ${data.id}<br>` +         /* axios 응답 객체의 id 필드*/
            `<strong>제목:</strong> ${data.title}<br>` +    /*axios 응답 객체의 title 필드*/
            `<strong>내용:</strong> ${data.body}<br>`;     /*axios 응답 객체의 body 필드*/
    } catch (error) {
        result.textContent = `오류: ${error.message}`;
    }
}

/*
*    axiosPost() -- axios.post()로 데이터 전송
*       fetch  -> headers에 Content-Type 직접 설정 필요
*                 body를 JSON.stringify()로 직접 변환 필요
*       axios -> 두번째 인자(객체)를 자동으로 JSON 직렬화
*                Content-Type: application/json 자동 설정
* */
async function axiosPost() {
    const title = document.getElementById('postTitle').value || '(제목 없음)';
    const body = document.getElementById('postBody').value || '(내용 없음)';
    const result = document.getElementById('postResult');

    result.innerHTML = `<span></span>전송 중....`;

    try {
        /*
        *   axios.post(url, data) - POST 요청
        *       - 첫 번째 인자: 요청 URL
        *       - 두 번째 인자: 요청 body (JS 객체를 그대로 전달)
        *           -> axios가 내부에서 JSON.stringify() 처리
        *           -> Content-Type: application/json 헤더로 자동 설정
        * */
        const { data, status } = await axios.post(
            `https://jsonplaceholder.typicode.com/posts`,
            {title, body, userId: 1 },              /*단축 프로퍼티 -  title: title, body: body*/
        );

        result.innerHTML =
            `<span>${status} Created</span><br><br>` +
            `<strong>서버에서 부여한 ID:</strong> ${data.id}<br>` +         /* axios 응답 객체의 id 필드*/
            `<strong>제목:</strong> ${data.title}<br>` +    /*axios 응답 객체의 title 필드*/
            `<strong>내용:</strong> ${data.body}<br>`;     /*axios 응답 객체의 body 필드*/

    } catch (error) {
        result.textContent = `오류: ${error.message}`;
    }
}

/*
    axiosError() - axion의 자동 에러 처리 확인하기
        fetch vs axios 차이
            fetch -> 404여도 .then()으로 들어옴 -> response.ok 직접 확인 필요
            axios -> 404면 자동으로 reject -> catch 블록에서 바로 처리
* */
async function axiosError() {
    const result = document.getElementById('errorResult');

    result.innerHTML = `<span></span>요청 중....`;

    try {
        /*  존재하지 않는 ID(99999) -> jsonplaceholder는 404 반환
            axios는 404를 받는 즉시 Promise를 reject -> catch 이동

            fetch였다면:
                const response = await fetch(url)
                -> 404여도 여기까지 정상 실행됨 (reject 안됨)
                -> response.ok === false를 직접 확인해야 에러를 감지할수 있음
        * */
        await axios.get('https://jsonplaceholder.typicode.com/posts/99999');
    } catch (error) {
        /*
        *   error.response -- 서버가 응답을 보낸 경우에만 존재
        *       옵셔널 체이닝(?.)으로 접근 - 네트워크 오류 시 error.response가 undefined일 수 있음
        *   error.response.status - 서버가 반환한 HTTP 상태 코드 (여기서는 404)
        *   error.message - axios가 자동 생성한 메시지
        * */
        result.innerHTML =
            `<strong>Axios가 자동으로 catch로 보냄</strong><br><br>` +
            `<span>${error.response?.status || '네트워크 오류'}</span><br><br>` +
            `<strong>error.message:</strong>${error.message}`
    }
}