package com.example.hometop.service.impl;

import com.example.hometop.dto.CustomerRequestDto;
import com.example.hometop.dto.CustomerResponseDto;
import com.example.hometop.entity.Customer;
import com.example.hometop.repository.CustomerRepository;
import com.example.hometop.service.CustomerService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class CustomerServiceImpl implements CustomerService {

    // 회원 관련 DB 접근을 담당하는 Repository
    private final CustomerRepository customerRepository;

    @Override
    @Transactional(readOnly = true)
    public long countCustomers() {
        return customerRepository.count();
    }

    /* 전체 회원 목록 조회 */
    @Override
    @Transactional(readOnly = true)
    public List<CustomerResponseDto> findAllCustomers() {
        return customerRepository.findAll().stream() // List<CustomerResponseDto> -> Stream<CustomerResponseDto>
                .map(CustomerResponseDto::from)     // Customer --> CustomerResponseDto (from 메서드 레퍼런스)
                .collect(Collectors.toList());      // Stream<CustomerResponseDto> --> List<CustomerResponseDto>
    }

    @Override
    public CustomerResponseDto register(CustomerRequestDto requestDto) {
        // 1. DTO -> Entity (rating=BRONZE 고정, id는 DB가 자동 생성)
        Customer customer = requestDto.toEntity();
        // 2. DB 저장 (save() --> INSERT SQL 실행, 반환된 saved에 id가 채워짐
        Customer saved = customerRepository.save(customer);
        // 3. Entity -> ResponseDto (Password 등 민감 정보 제외하고 반환)
        return CustomerResponseDto.from(saved);
    }
}
