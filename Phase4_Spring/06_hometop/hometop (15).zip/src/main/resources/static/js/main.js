/*
*   회원 목록 - 검색 폼 제어
*       - searchForm 이 없는 페이지(홈) 에서는 동작하지 않음(null 체크)
* */
const searchForm = document.getElementById('searchForm');
const searchType = document.getElementById('searchType');  // 검색 유형 select
const keywordInput = document.getElementById('keywordInput');  // 검색어 input

/* 검색 유형별 placeholder 안내 메시지 */
const placeholderMap = {
    ''                      : '예) 아이디: hong',
    'username'              : '예) hong (부분 일치 - 쿼리 메서드)'
}

function onSearchTypeChange() {
    const type = searchType.value;
    // placeholder 동적 변경 - 선택 유형에 맞는 안내 메시지로 교체
    if (keywordInput) {
        keywordInput.placeholder = placeholderMap[type] || placeholderMap[''];
    }
}

if (searchType) {
    onSearchTypeChange();
    // 검색 유형 변경 시 - select 표시/숨김, placeholder 변경
    searchType.addEventListener('change', onSearchTypeChange);
}

/* 검색 폼 유효성 검사 */
console.log('[searchForm 찾기]', searchForm);
