package com.example.hometop.controller;

import com.example.hometop.dto.CustomerRequestDto;
import com.example.hometop.dto.CustomerResponseDto;
import com.example.hometop.dto.CustomerUpdateDto;
import com.example.hometop.service.CustomerService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Slf4j
@Controller
@RequestMapping("/customer")
@RequiredArgsConstructor
public class CustomerController {
    private final CustomerService customerService;

    // 회원 목록 페이지
    // GET /customer
    @GetMapping
    public String index(Model model) {
        // 전체 회원 목록 조회 --> 뷰에서 th:each로 테이블 랜더링
        model.addAttribute("customers", customerService.findAllCustomers());
        return "customer/index";      // templates/customer/index.html
    }

    /* 회원 등록 폼 페이지
    *   GET /customer/register
    *       - 빈 CustomerRequestDto를 "customerForm" 이름으로 Model에 담아 뷰에 전달
    *       - 뷰의 th:object="${customerForm}" 이 이 객체와 바인딩되어 폼 필드를 구성함
    *       - POST 처리
    * */
    @GetMapping("/register")
    public String register(Model model) {
        // 빈 DTO를 Model에 담아 전달
        model.addAttribute("customerForm", new CustomerRequestDto());
        return "customer/register";   // templates/customer/register.html
    }

    /*
       회원 등록 처리
       POST /customer/register

        - @ModelAttribute: 폼에서 전송된 데이터를 CustomerRequestDto에 자동 바인딩
            -> Spring MVC가 빈 객체 생성 후, 각 필드를 Setter 로 채움
            -> 폼 input의 name 속성과 DTO 필드명이 일치해야 바인딩됨 (th:field가 자동으로 맞춰줌)

        - RedirectAttributes: POST 처리 후 redirect 시 데이터를 한 번만 전달하는 방법 (PRG 패턴)
            -> addFlashAttributes는 세션에 임시 저장 -> redirect 이후 한번 읽히고 자동 소멸

        PRG 패턴 (POST -> Redirect -> Get)
            POST /customer/register (데이터 저장)
             |
             |--> redirect:/customer (브라우저가 GET 요청으로 전환)
                     |
                     |--> GET /customer (목록 페이지 랜더링)
    * */
    @PostMapping("/register")
    public String register(@ModelAttribute("customerForm") CustomerRequestDto requestDto,
                           RedirectAttributes redirectAttributes) {
        // Service 위임 - DTO -> Entity --> save --> ResponseDTO 반환
        CustomerResponseDto saved = customerService.register(requestDto);

        log.info("회원 등록 완료 === id={}, username={}, name={}, rating={}",
                saved.getId(), saved.getUsername(), saved.getCustomerName(), saved.getRating());

        // Flash attribute -- redirect 이후  customer/index.html에서 한 번 읽히고 자동 소멸
        redirectAttributes.addFlashAttribute("savedCustomer", saved);   // 방금 등록된 회원 (테이블 하이라이트용)
        redirectAttributes.addFlashAttribute("successMessage",          // 성공 메시지 배너용
                " '  "+saved.getUsername()+"  '회원이 성공적으로 등록되었습니다. (등급: " + saved.getRating() + ")  ");

        return "redirect:/customer";   // PRG 패턴 -- POST 후 GET 목록 페이지로 이동
    }

    /*
    *   회원 상세 페이지
    *   GET /customer/{id}
    * */
    @GetMapping("/{id}")
    public String detail(@PathVariable Long id, Model model) {
        CustomerResponseDto customer = customerService.findCustomerById(id);
        log.info("== 회원 상세 조회 == id={}, username={}", customer.getId(), customer.getUsername());
        model.addAttribute("customer", customer);
        return "customer/detail";   // templates/customer/detail.html
    }

    /* 회원 삭제 처리
    *   - PRG 패턴 (Post -> Redirect -> Get)
    *   - POST /customer/3/delete (삭제 처리)
    *      -> redirect:/customer (브라우저가 GET 요청으로 전환)
    *           -> GET /customer (목록 페이지 랜더링)
    *   - 브라우저 새로고침 시 POST 중복 제출 방지
    * */
    @PostMapping("/{id}/delete")
    public String delete(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        // 삭제 전 username 미리 조회 (삭제 후에는 조회 불가)
        CustomerResponseDto customer = customerService.findCustomerById(id);
        String username = customer.getUsername();

        customerService.deleteCustomer(id);

        log.info("=== 회원 삭제 완료 === id={}, username={}", id, username);

        // Flash attribute - redirect 이후 customer/index.html에서 한번 읽히고 자동 소멸
        redirectAttributes.addFlashAttribute("successMessage",
                " '"+username+"' 회원이 성공적으로 삭제되었습니다.");

        return "redirect:/customer";  // PRG 패넌 -- POST 후 GET 목록 페이지로 이동

    }

    /* 회원 수정 폼 페이지
    *   GET     /customer/{id}/edit
    *
    *   Model에 객체를 공유
    *       - 수정 불가 필드를 폼 위에 보여주기 위해 사용
    *       - 폼 바인딩용 객체
    *           - 기존 값 전달 --> POST 제출 시 이 객체에 새 값이 담겨 옮
    * */
    @GetMapping("/{id}/edit")
    public String editForm(@PathVariable Long id, Model model) {
        // 기존 회원 정보 조회
        CustomerResponseDto customer = customerService.findCustomerById(id);

        // 수정 폼에 기존 값 -- 사용자가 기존 내용을 보고 수정할수 있도록
        CustomerUpdateDto updateForm = new CustomerUpdateDto();
        updateForm.setCustomerName(customer.getCustomerName());
        updateForm.setAge(customer.getAge());
        updateForm.setOccupation(customer.getOccupation());

        model.addAttribute("customer", customer); // 읽기 전용 정보 (id, username, rating 등)
        model.addAttribute("updateForm", updateForm); // 수정 폼 바인딩 객체

        return "customer/edit";   // templates/customer/edit.html
    }

    /* 회원 수정 처리
    *   POST    /customer/{id}/edit
    *
    *   PRG 패턴
    *     - POST /customer/3/edit (수정 처리)
    *        --> redirect:/customer/3 (브라우저가 GET 요청으로 전환)
    *           --> GET /customer/3 (상세 페이지 랜더링)
    * */
    @PostMapping("/{id}/edit")
    public String update(@PathVariable Long id,
                         @ModelAttribute("updateForm") CustomerUpdateDto updateDto,
                         RedirectAttributes redirectAttributes) {
        // Service에 위임 -> 더티 체킹으로 자동 UPDATE
        CustomerResponseDto updated = customerService.updateCustomer(id, updateDto);
        log.info("===회원 수정 완료=== id={}, username={}", updated.getId(), updated.getUsername() );

        redirectAttributes.addFlashAttribute("successMessage",
                " '"+updated.getUsername()+"' 회원 정보가 성공적으로 수정되었습니다. ");
        return "redirect:/customer/" + id;  // PRG 패턴 -- POST 후 상세 페이지로 이동
    }
}
