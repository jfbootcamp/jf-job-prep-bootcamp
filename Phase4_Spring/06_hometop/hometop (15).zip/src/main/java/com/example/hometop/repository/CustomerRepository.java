package com.example.hometop.repository;

import com.example.hometop.entity.Customer;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface CustomerRepository extends JpaRepository<Customer, Long> {
    /*
        username으로 회원 단건 조회
            생성되는 SQL :
                SELECT * FROM customers where username = ?
    * */
    Optional<Customer> findByUsername(String username);

    /*
    *   username 부분 일치 검색 (관리자 회원 목록 검색용)
    *       생성되는 SQL :
    *          SELECT * FROM customers where username LIKE '%?%'
    * */
    List<Customer> findByUsernameContaining(String username);
}


