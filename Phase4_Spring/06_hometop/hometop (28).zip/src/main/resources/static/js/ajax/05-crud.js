/*
    editMode - 폼이 수정 모드인지 신규 등록 모드인지 구분하는 플래그
        false: 신규 등록 모드 (POST 요청)
        true: 수정 모드 (PUT 요청)
 * */
let editMode = false;

/* 아이템 목록 조회
*   encodeURIComponent(): 한글,특수문자를 URL-safe 문자열로 인코딩
* */
async function loadItems(keyword) {
    const url = keyword ? `/api/items?keyword=${encodeURIComponent(keyword)}`  /*검색어를 URL 인코딩 후 쿼리스트림에 추가*/
        : `/api/items`;     /*검색어 없으면 전체 목록 조회*/
    const tbody = document.getElementById('itemTbody');

    /*요청 중 로딩 테이블 본문에 표시*/
    tbody.innerHTML = `<tr><td colspan="6" style="text-align: center;"></td></tr>`;

    try {
        const {data: items} = await axios.get(url);
        renderTable(items);     /*파싱된 배열로 테이블 렌더링*/

    } catch (e) {
        tbody.innerHTML =
            `<tr><td colspan="6" style="text-align: center;">오류: ${e.message}</td></tr>`;
    }

}

function renderTable(items) {
    const tbody = document.getElementById('itemTbody');

    if (!items.length) {
        tbody.innerHTML =
            `<tr><td colspan="6" style="text-align: center;">
                                        검색 결과가 없습니다.</td></tr>`;
        return;
    }
    tbody.innerHTML = items.map((item) => `
        <tr>
            <td>${item.id}</td>
            
        </tr>
    `).join('');        /*배열 --> 하나의 HTML 문자열로 병합*/
}

function searchItems() {

}

/*페이지 로드 시 전체 목록 조회*/
loadItems();
