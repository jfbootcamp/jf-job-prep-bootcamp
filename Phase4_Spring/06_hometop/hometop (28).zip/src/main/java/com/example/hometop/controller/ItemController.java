package com.example.hometop.controller;

import com.example.hometop.entity.Item;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/items")
public class ItemController {
    /*인메모리 저장소 - DB 대신 JVM 메모리 안의 List를 사용*/
    private static final List<Item> items = new ArrayList<>();
    private static long nextId = 1L;

    static {
        items.add(new Item(nextId++, "사과", 50, 1500,
                "과일", "국내 사과, 아삭하고 달콤합니다."));
        items.add(new Item(nextId++, "바나나", 30, 800,
                "과일", "수입 바나나, 당도가 높습니다."));
        items.add(new Item(nextId++, "오렌지", 20, 2000,
                "과일", "미국산 네이블 오렌지입니다."));
        items.add(new Item(nextId++, "우유", 40, 2500,
                "과일", "서울우유 1L 팩입니다."));
        items.add(new Item(nextId++, "식빵", 25, 3200,
                "과일", "부드러운 식빵, 유통기한 3일."));
    }

    @GetMapping
    public ResponseEntity<List<Item>> getAll(
            @RequestParam(required = false) String keyword
    ) {
        if (keyword != null && !keyword.isBlank()) {
            // 대소문자 구분 없이 검색하기 위해 양쪽을 모두 소문자로 변환
            String kw = keyword.toLowerCase();

            /*Strean.filter() : 람다식 조건에 맞는 아이템만 남김 */
            List<Item> filtered = items.stream()
                    .filter(i -> i.getName().toLowerCase().contains(kw)
                            || i.getCategory().toLowerCase().contains(kw))
                    .collect(Collectors.toList());
            return ResponseEntity.ok(filtered);     // 200 ok + 필터링된 목록
        }
        return ResponseEntity.ok(new ArrayList<>(items));
    }
}
