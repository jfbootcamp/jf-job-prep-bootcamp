package com.example.hometop.service;

import com.example.hometop.entity.Book;

import java.util.List;

public interface BookService {
    List<Book> findAllBooks();  // 전체 도서 목록 조회
}
