package com.example.hometop.service.impl;

import com.example.hometop.repository.CustomerRepository;
import com.example.hometop.service.CustomerService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class CustomerServiceImpl implements CustomerService {

    // 회원 관련 DB 접근을 담당하는 Repository
    private final CustomerRepository customerRepository;

    @Override
    @Transactional(readOnly = true)
    public long countCustomers() {
        return customerRepository.count();
    }
}
