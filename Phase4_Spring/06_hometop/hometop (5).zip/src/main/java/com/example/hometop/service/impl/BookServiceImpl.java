package com.example.hometop.service.impl;

import com.example.hometop.entity.Book;
import com.example.hometop.repository.BookRepository;
import com.example.hometop.service.BookService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
public class BookServiceImpl implements BookService {

    // 도서 관련 DB 접근을 담당하는 Repository
    private final BookRepository bookRepository;

    @Override
    @Transactional(readOnly = true)   // 읽기 전용 트랜잭션 -> Hibernate 더티 체킹(변경 감지) 생략으로 성능 향상
    public List<Book> findAllBooks() {
        return bookRepository.findAll();
    }
}
