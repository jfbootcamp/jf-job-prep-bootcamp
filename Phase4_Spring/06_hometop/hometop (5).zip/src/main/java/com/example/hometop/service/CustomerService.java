package com.example.hometop.service;

public interface CustomerService {
    //전체 회원 수 조회
    long countCustomers();
}
