package com.example.hometop.repository;

import com.example.hometop.entity.Customer;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface CustomerRepository extends JpaRepository<Customer, Long> {
    /*
        username으로 회원 단건 조회
            생성되는 SQL :
                SELECT * FROM customers where username = ?
    * */
    Optional<Customer> findByUsername(String username);

    /*
    *   username 부분 일치 검색 (관리자 회원 목록 검색용)
    *       생성되는 SQL :
    *          SELECT * FROM customers where username LIKE '%?%'
    * */
    List<Customer> findByUsernameContaining(String username);

    /*
        적립금이 기준 금액 이상인 회원 목록 조회
            생성되는 SQL :
                SELECT * FROM customers where reserves >= ?
            실무 활용
                - 쇼핑몰 이벤트 대상 선정 : 적립금 N원 이상 회원에게 쿠폰 발급
                - VIP  마케팅 캠페인 : 일정 금액 이상 회원에게 프로모션 안내
                - 포인트 소멸 안내 대상 : 일정 금액 이상 미사용 포인트 보유 회원 조회
           GreaterThanEqual 키워드
                - GreatenThan     -> reserves > ?
                - LessThan        -> reserves < ?
                - LessThanEqual   -> reserves <= ?
                - Between         -> reserves BETWEEN ? AND ?
    * */
    List<Customer> findByReservesGreaterThanEqual(int reserves);
}


