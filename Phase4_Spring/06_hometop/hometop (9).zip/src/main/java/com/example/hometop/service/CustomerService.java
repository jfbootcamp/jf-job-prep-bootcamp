package com.example.hometop.service;

import com.example.hometop.dto.CustomerRequestDto;
import com.example.hometop.dto.CustomerResponseDto;

import java.util.List;

public interface CustomerService {
    //전체 회원 수 조회
    long countCustomers();

    //전체 회원 목록 조회
    List<CustomerResponseDto> findAllCustomers();

    /*회원 등록
    *   - 입력 : 클라이언트가 보낸 요청 데이터 (CustomerRequestDto)
    *   - 출력 : 저장 완료된 회원 정보 (CustomerResponseDto)--password등 민감 정보 제외
    * */
    CustomerResponseDto register(CustomerRequestDto requestDto);
}
