package com.example.hometop.dto;

/*
*   회원 응답 DTO -- "출력" 역할
*       -    Client   <-- [CustomerResponseDto]    <--  Service   <--  Entity   <--  DB
*       - Entity를 그대로 반환하면 엔티티 필드들까지 직렬화될 수 있으므로
*         응답 전용 DTO로 분리함.
*       - from() 정적 팩토리 메서드로 Entity -> DTO 변환 (내부에 캡슐화)
* */

import com.example.hometop.entity.Customer;
import com.example.hometop.enums.RatingType;
import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public class CustomerResponseDto {

    private Long id;
    private String username;
    private String customerName;
    private Integer age;
    private RatingType rating;
    private String occupation;
    private Integer reserves;

    /* Entity --> DTO 변환 메서드 (정적 팩토리 메서드) */
    public static CustomerResponseDto from(Customer customer) {
        return CustomerResponseDto.builder()
                .id(customer.getId())
                .username(customer.getUsername())
                .customerName(customer.getCustomerName())
                .age(customer.getAge())
                .rating(customer.getRating())
                .occupation(customer.getOccupation())
                .reserves(customer.getReserves())
                .build();

    }
}
