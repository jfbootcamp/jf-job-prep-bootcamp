package com.example.hometop.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/*
    전역 CORS 설정
        - CORS (Cross-Origin Resource Sharing)
            - 브라우저는 보안상 다른 출처(Origin)의 요청을 기본으로 차단함
            - Origin = 프로토콜 + 도메인 + 포트

            - React :   http://localhost:5173/   <---- Origin A
              Spring :  http://localhost:8085/   <---- Origin B  <-- 포트 다름 --> 차단!

        - 이 설정으로 허용된 Origin의 요청을 통과시킴
 */
@Configuration
public class CorsConfig {

    @Bean
    public WebMvcConfigurer corsConfigurer() {
        return new WebMvcConfigurer() {
            @Override
            public void addCorsMappings(CorsRegistry registry) {
                registry.addMapping("/api/**")      // /api/ 로 시작하는 모든 경로에 CORS 정책 적용
                        .allowedOrigins(
                                "http://localhost:5173/",     // React 기본 개발서버(Vite)
                                "http://localhost:3000/"      // React 초기 개발서버 (CRA)
                        )
                        .allowedMethods("GET", "POST", "PUT", "DELETE", "PATCH", "OPTIONS")
                        .allowedHeaders("*")        // 모든 요청 헤더 허용
                        .allowCredentials(false);    // 쿠키,인증 헤더 전송 비허용 -- JWT 사용 시 true로 변경 필요
            }
        };
    }
}
