package com.example.hometop.entity;

import com.example.hometop.enums.RatingType;
import jakarta.persistence.*;
import lombok.*;

@Getter
@NoArgsConstructor(access = AccessLevel.PROTECTED)
@AllArgsConstructor(access = AccessLevel.PRIVATE)
@Builder
@Entity
@Table(name = "customers")  // 테이블명은 복수형 사용
public class Customer {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true)
    private String username;

    @Column(nullable = false)
    private String password;

    private String cutomerName;

    private Integer age;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private RatingType rating = RatingType.BRONZE;  // 신규 가입시 최하위 등급으로 시작

    private String occupation;

    private Integer reserves = 0;

    // 변경 메서드
    public void changePassword(String endcodedPassword) {
        this.password = endcodedPassword;
    }

    public void updateProfile(String customerName, Integer age, String occupation) {
        this.cutomerName = customerName;
        this.age = age;
        this.occupation = occupation;
    }

    public void updateRating(RatingType rating) {
        this.rating = rating;
    }

    public void addReserves(Integer amount) {
        this.reserves += amount;
    }

}
