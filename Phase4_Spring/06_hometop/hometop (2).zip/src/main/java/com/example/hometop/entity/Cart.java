package com.example.hometop.entity;

import jakarta.persistence.*;

import java.time.LocalDateTime;

@Entity
@Table(name = "carts")
public class Cart {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private Integer quantity;

    @Column(nullable = false, updatable = false)  // updatable = false <--- 장바구니 담은 시각은 최초 저장 후 변경 불가하도록 DB레벨에서 차단함.
    private LocalDateTime cartDate = LocalDateTime.now();

    public void updateQuantity(Integer quantity) {
        this.quantity = quantity;
    }
}
