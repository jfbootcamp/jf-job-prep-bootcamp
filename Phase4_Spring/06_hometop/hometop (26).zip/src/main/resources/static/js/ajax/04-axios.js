/*
*   axiosGet() -- axios.get()으로 단건 조회
* */
async function axiosGet() {
    const id = document.getElementById('postId').value || 1;
    const result = document.getElementById('getResult');

    result.innerHTML = `<span></span>요청 중....`;

    try {
        /*axios.get(url)  -- get 요청
            - 내부적 fetch 또는 XHR을 래핑한 라이브러리
            - 반환값: Promise<AxiosResponse>
            - 구조분해: {data, status} 로 필요한 필드만 추출
                - data : 서버 응답 body가 자동으로 JS 객체로 파싱된 결과
                - status : HTTP 상태 코드 숫자 (예: 200)
        *
        * */
        const { data, status } =
            await axios.get(`https://jsonplaceholder.typicode.com/posts/${id}`);

        result.innerHTML =
            `<span>${status} ok</span><br><br>` +
            `<strong>ID:</strong> ${data.id}<br>` +         /* axios 응답 객체의 id 필드*/
            `<strong>제목:</strong> ${data.title}<br>` +    /*axios 응답 객체의 title 필드*/
            `<strong>내용:</strong> ${data.body}<br>`;     /*axios 응답 객체의 body 필드*/
    } catch (error) {
        result.textContent = `오류: ${error.message}`;
    }
}