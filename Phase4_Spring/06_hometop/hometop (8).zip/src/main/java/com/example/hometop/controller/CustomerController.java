package com.example.hometop.controller;

import com.example.hometop.dto.CustomerRequestDto;
import com.example.hometop.service.CustomerService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Slf4j
@Controller
@RequestMapping("/customer")
@RequiredArgsConstructor
public class CustomerController {
    private final CustomerService customerService;

    // 회원 목록 페이지
    // GET /customer
    @GetMapping
    public String index(Model model) {
        return "customer/index";
    }

    /* 회원 등록 폼 페이지
    *   GET /customer/register
    *       - 빈 CustomerRequestDto를 "customerForm" 이름으로 Model에 담아 뷰에 전달
    *       - 뷰의 th:object="${customerForm}" 이 이 객체와 바인딩되어 폼 필드를 구성함
    *       - POST 처리
    * */
    @GetMapping("/register")
    public String register(Model model) {
        // 빈 DTO를 Model에 담아 전달
        model.addAttribute("customerForm", new CustomerRequestDto());
        return "customer/register";   // templates/customer/register.html
    }
}
